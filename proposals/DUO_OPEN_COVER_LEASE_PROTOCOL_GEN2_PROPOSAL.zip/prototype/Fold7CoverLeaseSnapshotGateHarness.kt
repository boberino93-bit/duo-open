package rnd.fold7

import rnd.fold7.Fold7CoverLeaseSnapshotGateGen2.ShellSnapshot

private fun checkThat(condition: Boolean, message: String) {
    if (!condition) error(message)
}

private data class TestResult(val name: String, val passed: Boolean, val detail: String = "")

private fun snapshot(session: Long, rev: Long, owner: Long, lease: Long = 1, epoch: Long = 1, state: String = "HELD") =
    ShellSnapshot(session, rev, owner, lease, epoch, state)

private fun permutations(values: List<Int>): List<List<Int>> {
    if (values.size <= 1) return listOf(values)
    val out = mutableListOf<List<Int>>()
    for (i in values.indices) {
        val rest = values.toMutableList()
        val head = rest.removeAt(i)
        for (tail in permutations(rest)) out += listOf(head) + tail
    }
    return out
}

fun main() {
    val results = mutableListOf<TestResult>()
    fun test(name: String, block: () -> Unit) {
        try {
            block()
            results += TestResult(name, true)
        } catch (t: Throwable) {
            results += TestResult(name, false, t.message ?: t.javaClass.simpleName)
        }
    }

    test("baseline can roll owner backward on out-of-order app completion") {
        val b = BaselineCoverLeaseSnapshotClient()
        b.complete(BaselineCoverLeaseSnapshotClient.Snapshot(20, "HELD"))
        b.complete(BaselineCoverLeaseSnapshotClient.Snapshot(10, "HELD"))
        checkThat(b.ownerGeneration == 10L, "baseline did not reproduce stale overwrite")
    }

    test("gen2 rejects older shell revision delivered late") {
        val g = Fold7CoverLeaseSnapshotGateGen2()
        val c = g.captureConnectionEpoch()
        checkThat(g.accept(c, snapshot(99, 2, 20)), "newer snapshot rejected")
        checkThat(!g.accept(c, snapshot(99, 1, 10)), "older revision incorrectly accepted")
        checkThat(g.state().ownerGeneration == 20L, "owner rolled backward")
        checkThat(g.state().lastShellRevision == 2L, "revision rolled backward")
    }

    test("all 720 delivery permutations converge to highest shell revision") {
        val order = permutations(listOf(0, 1, 2, 3, 4, 5))
        checkThat(order.size == 720, "unexpected permutation count")
        val snapshots = (0..5).map { i -> snapshot(1234, (i + 1).toLong(), (i + 100).toLong()) }
        for (p in order) {
            val g = Fold7CoverLeaseSnapshotGateGen2()
            val c = g.captureConnectionEpoch()
            for (idx in p) g.accept(c, snapshots[idx])
            checkThat(g.state().lastShellRevision == 6L, "did not converge: $p")
            checkThat(g.state().ownerGeneration == 105L, "wrong owner after $p")
        }
    }

    test("IDLE at highest revision wins over stale HELD result") {
        val g = Fold7CoverLeaseSnapshotGateGen2()
        val c = g.captureConnectionEpoch()
        checkThat(g.accept(c, snapshot(7, 9, -1, state = "IDLE")), "IDLE rejected")
        checkThat(!g.accept(c, snapshot(7, 8, 44, state = "HELD")), "stale HELD accepted")
        checkThat(g.state().ownerGeneration == -1L, "released ownership resurrected")
        checkThat(g.state().leaseState == "IDLE", "state resurrected")
    }

    test("privileged loss clears cached owner immediately") {
        val g = Fold7CoverLeaseSnapshotGateGen2()
        val c = g.captureConnectionEpoch()
        g.accept(c, snapshot(1, 1, 55))
        checkThat(g.state().ownerGeneration == 55L, "setup failed")
        g.onPrivilegedUnavailable()
        checkThat(g.state().ownerGeneration == -1L, "owner survived daemon loss")
        checkThat(g.state().resyncRequired, "resync not required")
    }

    test("old-connection completion cannot mutate new connection") {
        val g = Fold7CoverLeaseSnapshotGateGen2()
        val oldEpoch = g.captureConnectionEpoch()
        g.accept(oldEpoch, snapshot(10, 1, 60))
        g.onPrivilegedUnavailable()
        val newEpoch = g.captureConnectionEpoch()
        checkThat(g.accept(newEpoch, snapshot(11, 1, 70)), "new shell snapshot rejected")
        checkThat(!g.accept(oldEpoch, snapshot(10, 999, 999)), "old connection resurrected")
        checkThat(g.state().ownerGeneration == 70L, "old completion mutated new owner")
    }

    test("unexpected shell-session change fails closed") {
        val g = Fold7CoverLeaseSnapshotGateGen2()
        val c = g.captureConnectionEpoch()
        g.accept(c, snapshot(100, 1, 80))
        checkThat(!g.accept(c, snapshot(101, 1, 81)), "unexpected new shell session accepted")
        checkThat(g.state().ownerGeneration == -1L, "owner retained across unexplained shell change")
        checkThat(g.state().resyncRequired, "resync not requested")
    }

    test("stale reassert completion cannot clear reconnect-era ticket") {
        val g = Fold7CoverLeaseSnapshotGateGen2()
        var c = g.captureConnectionEpoch()
        g.accept(c, snapshot(1, 1, 90))
        val oldTicket = g.beginReassert() ?: error("old ticket missing")
        g.onPrivilegedUnavailable()
        c = g.captureConnectionEpoch()
        g.accept(c, snapshot(2, 1, 91))
        val newTicket = g.beginReassert() ?: error("new ticket missing")
        checkThat(!g.completeReassert(oldTicket, snapshot(1, 2, 90)), "old result unexpectedly accepted")
        checkThat(g.state().reassertInFlight == newTicket, "old result cleared new in-flight ticket")
    }

    test("matching reassert completion clears exact ticket and advances revision") {
        val g = Fold7CoverLeaseSnapshotGateGen2()
        val c = g.captureConnectionEpoch()
        g.accept(c, snapshot(5, 1, 101))
        val ticket = g.beginReassert() ?: error("ticket missing")
        checkThat(g.completeReassert(ticket, snapshot(5, 2, 101)), "matching completion rejected")
        checkThat(g.state().reassertInFlight == null, "ticket not cleared")
        checkThat(g.state().lastShellRevision == 2L, "revision not advanced")
    }

    test("lower revision cannot resurrect owner after release under callback burst") {
        val g = Fold7CoverLeaseSnapshotGateGen2()
        val c = g.captureConnectionEpoch()
        val burst = listOf(
            snapshot(88, 4, 204, lease = 4, epoch = 9, state = "HELD"),
            snapshot(88, 7, -1, lease = 4, epoch = 11, state = "IDLE"),
            snapshot(88, 5, 204, lease = 4, epoch = 9, state = "RELEASE_PENDING"),
            snapshot(88, 6, 204, lease = 4, epoch = 10, state = "RELEASING"),
            snapshot(88, 3, 203, lease = 4, epoch = 8, state = "HELD"),
        )
        for (s in burst) g.accept(c, s)
        checkThat(g.state().lastShellRevision == 7L, "did not retain latest revision")
        checkThat(g.state().ownerGeneration == -1L, "released owner resurrected")
        checkThat(g.state().leaseState == "IDLE", "released state resurrected")
    }

    val passed = results.count { it.passed }
    val failed = results.size - passed
    for (r in results) {
        println("${if (r.passed) "PASS" else "FAIL"} | ${r.name}${if (r.detail.isNotBlank()) " | ${r.detail}" else ""}")
    }
    println("SUMMARY tests=${results.size} passed=$passed failed=$failed")
    if (failed != 0) error("$failed test(s) failed")
}
