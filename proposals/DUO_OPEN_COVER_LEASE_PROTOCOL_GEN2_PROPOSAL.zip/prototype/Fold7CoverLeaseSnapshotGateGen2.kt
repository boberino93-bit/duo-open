package rnd.fold7

/**
 * Pure Kotlin R&D model for fencing cover-lease snapshots returned from the
 * privileged shell. It deliberately models only observation/acceptance order;
 * physical panel mutation remains owned by the existing Fold7CoverPanelLease.
 */
class Fold7CoverLeaseSnapshotGateGen2 {
    data class ShellSnapshot(
        val shellSession: Long,
        val shellRevision: Long,
        val ownerGeneration: Long,
        val leaseId: Long,
        val leaseEpoch: Long,
        val leaseState: String,
    )

    data class ReassertTicket(
        val connectionEpoch: Long,
        val localSequence: Long,
    )

    data class State(
        val connectionEpoch: Long,
        val shellSession: Long?,
        val lastShellRevision: Long,
        val ownerGeneration: Long,
        val leaseId: Long,
        val leaseEpoch: Long,
        val leaseState: String,
        val reassertInFlight: ReassertTicket?,
        val resyncRequired: Boolean,
    )

    private var connectionEpoch = 1L
    private var shellSession: Long? = null
    private var lastShellRevision = -1L
    private var ownerGeneration = -1L
    private var leaseId = -1L
    private var leaseEpoch = -1L
    private var leaseState = "UNKNOWN"
    private var localSequence = 0L
    private var reassertInFlight: ReassertTicket? = null
    private var resyncRequired = false

    fun state(): State = State(
        connectionEpoch = connectionEpoch,
        shellSession = shellSession,
        lastShellRevision = lastShellRevision,
        ownerGeneration = ownerGeneration,
        leaseId = leaseId,
        leaseEpoch = leaseEpoch,
        leaseState = leaseState,
        reassertInFlight = reassertInFlight,
        resyncRequired = resyncRequired,
    )

    /**
     * Called immediately when Shizuku/privileged service becomes unavailable.
     * Local ownership is intentionally discarded: a new daemon has no proof
     * that it inherited the old in-memory lease.
     */
    fun onPrivilegedUnavailable() {
        connectionEpoch += 1L
        shellSession = null
        lastShellRevision = -1L
        ownerGeneration = -1L
        leaseId = -1L
        leaseEpoch = -1L
        leaseState = "UNKNOWN"
        reassertInFlight = null
        resyncRequired = true
    }

    fun captureConnectionEpoch(): Long = connectionEpoch

    fun beginReassert(): ReassertTicket? {
        if (reassertInFlight != null || ownerGeneration < 0L || resyncRequired) return null
        return ReassertTicket(connectionEpoch, ++localSequence).also {
            reassertInFlight = it
        }
    }

    /**
     * A completion may clear only the exact in-flight ticket that created it.
     * This prevents an old coroutine from clearing a newer reconnect-era
     * reassert after onPrivilegedUnavailable() resets the client.
     */
    fun completeReassert(ticket: ReassertTicket, snapshot: ShellSnapshot?): Boolean {
        val current = reassertInFlight
        if (current == ticket) {
            reassertInFlight = null
        }
        return if (snapshot == null) false else accept(ticket.connectionEpoch, snapshot)
    }

    /**
     * Apply only snapshots from the current connection epoch, current shell
     * session, and monotonically non-decreasing shell execution revision.
     * A session change without an explicit reconnect edge is fail-closed.
     */
    fun accept(capturedConnectionEpoch: Long, snapshot: ShellSnapshot): Boolean {
        if (capturedConnectionEpoch != connectionEpoch) return false
        if (snapshot.shellRevision < 0L) return false

        val currentSession = shellSession
        if (currentSession == null) {
            shellSession = snapshot.shellSession
            lastShellRevision = -1L
        } else if (currentSession != snapshot.shellSession) {
            ownerGeneration = -1L
            leaseId = -1L
            leaseEpoch = -1L
            leaseState = "UNKNOWN"
            reassertInFlight = null
            resyncRequired = true
            return false
        }

        if (snapshot.shellRevision < lastShellRevision) return false

        lastShellRevision = snapshot.shellRevision
        ownerGeneration = if (snapshot.leaseState == "IDLE") -1L else snapshot.ownerGeneration
        leaseId = snapshot.leaseId
        leaseEpoch = snapshot.leaseEpoch
        leaseState = snapshot.leaseState
        resyncRequired = false
        return true
    }
}

/** Current-main observation behavior reduced to the relevant semantics. */
class BaselineCoverLeaseSnapshotClient {
    data class Snapshot(val ownerGeneration: Long, val leaseState: String)

    var ownerGeneration: Long = -1L
        private set
    var reassertInFlight: Boolean = false
        private set

    fun beginReassert(): Boolean {
        if (reassertInFlight || ownerGeneration < 0L) return false
        reassertInFlight = true
        return true
    }

    fun onPrivilegedUnavailable() {
        // Mirrors current source: the in-flight flag is cleared but cached
        // coverLeaseOwnerGeneration is not.
        reassertInFlight = false
    }

    fun complete(snapshot: Snapshot) {
        reassertInFlight = false
        ownerGeneration = if (snapshot.leaseState == "IDLE") -1L else snapshot.ownerGeneration
    }
}
