package rnd.fold7

/** Reduced model of current-main cover IPC authorization. */
class BaselineOwnerGenerationAuthority(
    private var ownerGeneration: Long,
) {
    var mutations = 0
        private set

    fun ensureHeld(requestOwnerGeneration: Long): Boolean {
        if (requestOwnerGeneration != ownerGeneration) return false
        mutations++
        return true
    }

    fun release(requestOwnerGeneration: Long): Boolean {
        if (requestOwnerGeneration != ownerGeneration) return false
        mutations++
        ownerGeneration = -1L
        return true
    }
}

/**
 * Gen2 model: mutation authority is an opaque end-to-end token, not a service-
 * local controller generation by itself.
 */
class Gen2LeaseTokenAuthority(
    shellSession: Long,
    leaseId: Long,
    leaseEpoch: Long,
    ownerGeneration: Long,
) {
    data class Token(
        val shellSession: Long,
        val leaseId: Long,
        val leaseEpoch: Long,
        val ownerGeneration: Long,
    )

    private var token = Token(shellSession, leaseId, leaseEpoch, ownerGeneration)
    var mutations = 0
        private set

    fun currentToken(): Token = token

    fun adoptNewGeneration(newGeneration: Long) {
        token = token.copy(
            leaseEpoch = token.leaseEpoch + 1,
            ownerGeneration = newGeneration,
        )
    }

    fun rotateLease(newLeaseId: Long, newGeneration: Long) {
        token = token.copy(
            leaseId = newLeaseId,
            leaseEpoch = token.leaseEpoch + 1,
            ownerGeneration = newGeneration,
        )
    }

    fun restartShell(newShellSession: Long) {
        token = Token(newShellSession, token.leaseId + 1, token.leaseEpoch + 1, -1)
    }

    fun ensureHeld(request: Token): Boolean {
        if (request != token) return false
        mutations++
        return true
    }

    fun release(request: Token): Boolean {
        if (request != token) return false
        mutations++
        token = token.copy(leaseEpoch = token.leaseEpoch + 1, ownerGeneration = -1)
        return true
    }
}
