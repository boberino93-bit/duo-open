package rnd.fold7

private fun must(condition: Boolean, message: String) { if (!condition) error(message) }

fun main() {
    var pass = 0
    var fail = 0
    fun test(name: String, block: () -> Unit) {
        try {
            block(); pass++; println("PASS | $name")
        } catch (t: Throwable) {
            fail++; println("FAIL | $name | ${t.message}")
        }
    }

    test("baseline ownerGeneration can collide across app-service lifetimes") {
        val shell = BaselineOwnerGenerationAuthority(ownerGeneration = 5)
        // A restarted coordinator can eventually produce generation=5 again.
        must(shell.release(5), "collision did not authorize")
        must(shell.mutations == 1, "expected unintended mutation")
    }

    test("gen2 stale leaseId cannot mutate a newer lease with same generation") {
        val shell = Gen2LeaseTokenAuthority(10, 100, 7, 5)
        val old = shell.currentToken()
        shell.rotateLease(newLeaseId = 101, newGeneration = 5)
        must(!shell.ensureHeld(old), "old lease token authorized")
        must(shell.mutations == 0, "stale token mutated shell")
    }

    test("gen2 stale epoch cannot release re-adopted lease") {
        val shell = Gen2LeaseTokenAuthority(10, 200, 9, 20)
        val old = shell.currentToken()
        shell.adoptNewGeneration(21)
        must(!shell.release(old), "stale epoch authorized release")
        must(shell.currentToken().ownerGeneration == 21L, "new owner damaged")
    }

    test("gen2 stale shell-session token cannot mutate restarted daemon") {
        val shell = Gen2LeaseTokenAuthority(10, 300, 1, 30)
        val old = shell.currentToken()
        shell.restartShell(11)
        must(!shell.ensureHeld(old), "old daemon token authorized")
        must(shell.mutations == 0, "stale daemon token mutated")
    }

    test("gen2 exact token authorizes intended mutation") {
        val shell = Gen2LeaseTokenAuthority(12, 400, 2, 40)
        val exact = shell.currentToken()
        must(shell.ensureHeld(exact), "exact token rejected")
        must(shell.mutations == 1, "intended mutation missing")
    }

    println("SUMMARY tests=${pass + fail} passed=$pass failed=$fail")
    if (fail != 0) error("$fail test(s) failed")
}
