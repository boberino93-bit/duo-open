package rnd.fold7

import kotlin.random.Random
import rnd.fold7.Fold7CoverLeaseSnapshotGateGen2.ShellSnapshot

fun main() {
    val rng = Random(0xC0F7A7)
    var deliveries = 0L
    repeat(5_000) { round ->
        val gate = Fold7CoverLeaseSnapshotGateGen2()
        val conn = gate.captureConnectionEpoch()
        val session = 10_000L + round
        val snapshots = (1L..20L).map { rev ->
            val idle = rev == 20L && round % 3 == 0
            ShellSnapshot(
                shellSession = session,
                shellRevision = rev,
                ownerGeneration = if (idle) -1L else rev + 1_000L,
                leaseId = 100L + round,
                leaseEpoch = rev / 3L,
                leaseState = if (idle) "IDLE" else "HELD",
            )
        }
        val delivery = (snapshots + snapshots.shuffled(rng).take(5)).shuffled(rng)
        for (s in delivery) {
            gate.accept(conn, s)
            deliveries++
        }
        val st = gate.state()
        check(st.lastShellRevision == 20L) { "round=$round revision=${st.lastShellRevision}" }
        val expectedOwner = if (round % 3 == 0) -1L else 1020L
        check(st.ownerGeneration == expectedOwner) { "round=$round owner=${st.ownerGeneration} expected=$expectedOwner" }
    }
    println("FUZZ PASS rounds=5000 deliveries=$deliveries")
}
