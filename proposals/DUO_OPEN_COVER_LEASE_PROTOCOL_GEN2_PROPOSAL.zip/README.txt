DUO OPEN — COVER LEASE PROTOCOL GEN2 — R&D PROPOSAL PACKAGE

PURPOSE
Provide the primary supervising agent with a self-contained, evidence-driven R&D package for a proposed Cover Lease Protocol V3. The proposal hardens app↔privileged-shell cover lease identity, reply ordering, and reconnect fencing without modifying production source in this R&D silo.

BASELINE SHA
926fd4ec81a7f45fba832717e4758e03875da61c

FINAL CHECKED MAIN SHA
8f844ba8aadd8417a92ec8b568288fd0dd9e06e3
Final main re-fetched immediately before package freeze and remained at this SHA.

FILES INCLUDED
- DUO_OPEN_COVER_LEASE_PROTOCOL_GEN2_RND_HANDOFF.txt
- README.txt
- BASELINE-SHA.txt
- FINAL-MAIN-SHA.txt
- SHA256SUMS.txt
- PROPOSED_INTEGRATION_NOTES.txt
- prototype/Fold7CoverLeaseSnapshotGateGen2.kt
- prototype/Fold7CoverLeaseSnapshotGateHarness.kt
- prototype/Fold7CoverLeaseSnapshotGateFuzz.kt
- prototype/Fold7CoverLeaseProtocolIdentityModel.kt
- prototype/Fold7CoverLeaseProtocolIdentityHarness.kt

HOW TO REPRODUCE TESTS
Requires a local Kotlin/JVM compiler. Commands used in this R&D session:

cd prototype

kotlinc Fold7CoverLeaseSnapshotGateGen2.kt Fold7CoverLeaseSnapshotGateHarness.kt \
  -include-runtime -d cover-gate-rnd.jar
java -jar cover-gate-rnd.jar
Expected: SUMMARY tests=10 passed=10 failed=0

kotlinc Fold7CoverLeaseSnapshotGateGen2.kt Fold7CoverLeaseSnapshotGateFuzz.kt \
  -include-runtime -d cover-gate-fuzz.jar
java -jar cover-gate-fuzz.jar
Expected: FUZZ PASS rounds=5000 deliveries=125000

kotlinc Fold7CoverLeaseProtocolIdentityModel.kt Fold7CoverLeaseProtocolIdentityHarness.kt \
  -include-runtime -d cover-identity-rnd.jar
java -jar cover-identity-rnd.jar
Expected: SUMMARY tests=5 passed=5 failed=0

The generated JARs are intentionally not included in this package.

INTEGRATION INTENT
Manual architectural integration only. Prefer a versioned COVER_PANEL_LEASE_V3 path with shellSession, shellRevision, exact lease token authorization, and a coordinator snapshot acceptance gate. Preserve current Fold7 route validation, panel-power safety, task placement, geometry, thresholds, Transition Lab instrumentation, 1.3.29 deterministic-frame behavior, and 1.3.29 early-wake behavior.

KNOWN RISKS
- V3 token acceptance can become overly strict if adoption/epoch updates are integrated incorrectly.
- Fail-closed reconnect behavior can briefly delay Duo-owned continuity until status/resync succeeds.
- Equal shellRevision with conflicting payload requires an explicit fail-closed rule before production integration.
- Real Fold7 occurrence/frequency of stale reply ordering has not been established by this R&D.
- Current main can change again; re-fetch before integration.

PRODUCTION STATUS=R&D ONLY
MANUAL REVIEW REQUIRED=YES
INSTALLATION AUTHORIZED=NO
