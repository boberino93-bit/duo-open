#!/usr/bin/env python3
"""Source-derived timing model for Fold7 cover readiness R&D.
All outputs are MODELED, not device measurements.
"""
from dataclasses import dataclass

DISPLAY_SYNC_DEBOUNCE_MS = 24
POST_REASSERT_SETTLE_MS = 32
PREWARM_RETRY_MS = 180
SHELL_ROUTE_POLL_ATTEMPTS = 6
SHELL_ROUTE_POLL_SLEEP_MS = 8
SHELL_MAX_WAIT_MS = (SHELL_ROUTE_POLL_ATTEMPTS - 1) * SHELL_ROUTE_POLL_SLEEP_MS  # 40
ANGLE_POLL_ASSUMPTION_MS = 8  # model assumption for next controller opportunity, not source guarantee

@dataclass
class Row:
    scenario: str
    current_ms: str
    gen2_ms: str
    delta: str
    note: str

rows=[]
rows.append(Row(
    "single DisplayManager callback to continuity observation",
    str(DISPLAY_SYNC_DEBOUNCE_MS),
    "0 fixed delay",
    f"-{DISPLAY_SYNC_DEBOUNCE_MS} ms fixed",
    "Current source posts one resettable 24 ms runnable; Gen2 fast lane evaluates immediately on callback. Queue time remains UNKNOWN."
))
rows.append(Row(
    "successful ensure return to scheduled mirror retry",
    str(POST_REASSERT_SETTLE_MS),
    "0 fixed delay",
    f"-{POST_REASSERT_SETTLE_MS} ms fixed",
    "Current source posts a fixed 32 ms retry after ok; Gen2 re-snapshots immediately and otherwise waits for authoritative topology callback."
))
rows.append(Row(
    "route-loss callback + successful ensure + scheduled retry (excluding Binder/framework)",
    str(DISPLAY_SYNC_DEBOUNCE_MS + POST_REASSERT_SETTLE_MS),
    "0 fixed delay",
    f"-{DISPLAY_SYNC_DEBOUNCE_MS + POST_REASSERT_SETTLE_MS} ms fixed",
    "This isolates only explicit software sleeps/debounces visible in source; it is not end-to-end latency."
))

# Route appears after shell's bounded initial route publication window. Current prewarm fails at ~40 ms,
# then controller imposes 180 ms retry-after. Assume an 8 ms controller opportunity cadence only to make the model finite.
for route_at in (48, 80, 120, 200):
    failure_at = SHELL_MAX_WAIT_MS
    eligible = failure_at + PREWARM_RETRY_MS
    # first modeled 8ms opportunity >= eligible
    current_retry = ((eligible + ANGLE_POLL_ASSUMPTION_MS - 1)//ANGLE_POLL_ASSUMPTION_MS)*ANGLE_POLL_ASSUMPTION_MS
    gen2_react = route_at  # immediate callback idealized; queue/Binder unknown
    rows.append(Row(
        f"logical route first available at {route_at} ms after prewarm start",
        str(current_retry),
        str(gen2_react),
        f"{current_retry-gen2_react} ms earlier modeled eligibility",
        "Current: physical lease may be HELD but activation false is fed to controller as prewarm failure; 180 ms backoff applies. Gen2: retain POWER_HELD_WAITING_ROUTE and react to fresh route event."
    ))

# Storm: callback every 10 ms for duration; current runnable fires 24 ms after last callback.
for duration in (50, 100, 500, 1000):
    last = (duration//10)*10
    current = last + DISPLAY_SYNC_DEBOUNCE_MS
    rows.append(Row(
        f"display callback burst every 10 ms through {duration} ms",
        str(current),
        "each callback immediate; mutation coalesced by one in-flight ticket",
        f"continuity observation not postponed to {current} ms",
        "Current debounce is reset by every callback. Continuous storms can postpone sync without a finite bound; Gen2 coalesces privileged mutation rather than topology observation."
    ))

print("TIMING MODEL — ALL NUMBERS MODELED/SOURCE-DERIVED, NOT FOLD7 MEASUREMENTS")
print(f"Source constants: display debounce={DISPLAY_SYNC_DEBOUNCE_MS} ms; post-reassert settle={POST_REASSERT_SETTLE_MS} ms; retry={PREWARM_RETRY_MS} ms; shell route wait<={SHELL_MAX_WAIT_MS} ms")
for r in rows:
    print(f"SCENARIO: {r.scenario}")
    print(f"  CURRENT_MAIN={r.current_ms}")
    print(f"  GEN2={r.gen2_ms}")
    print(f"  DELTA={r.delta}")
    print(f"  NOTE={r.note}")
