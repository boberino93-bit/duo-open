package rnd.fold7

/**
 * Pure R&D model for Fold7 cover presentation readiness.
 *
 * It deliberately does not own hinge thresholds, physical panel OFF, task placement,
 * or logical display identity. Logical ids are diagnostic only; readiness is always
 * corroborated from a fresh topology snapshot and the lease-owned physical id.
 */
class Fold7CoverReadinessGen2 {
    enum class Phase {
        IDLE,
        POWER_HELD_WAITING_ROUTE,
        ENSURE_IN_FLIGHT,
        READY_HIDDEN,
        VISIBLE,
        NATIVE_COVER,
        PRIVILEGE_UNAVAILABLE,
    }

    data class Lease(
        val transitionGeneration: Long,
        val ownerGeneration: Long,
        val leaseId: Long,
        val physicalId: Long,
        val epoch: Long,
    )

    data class Topology(
        val innerIsDefault: Boolean,
        val innerActive: Boolean,
        val coverActive: Boolean,
        val coverIsDefault: Boolean,
        val coverLogicalId: Int?,
        val coverPhysicalId: Long?,
    ) {
        val nativeCover: Boolean
            get() = coverActive && coverIsDefault && !innerActive
    }

    data class Ticket(
        val transitionGeneration: Long,
        val ownerGeneration: Long,
        val leaseId: Long,
        val epoch: Long,
        val requestSequence: Long,
    )

    data class RetryKey(
        val transitionGeneration: Long,
        val ownerGeneration: Long,
        val leaseId: Long,
        val epoch: Long,
    )

    sealed interface Action {
        data class EnsureHeld(val ticket: Ticket) : Action
        data class ScheduleMutationRetry(val key: RetryKey) : Action
        data class ShowMirror(val transitionGeneration: Long) : Action
        data class HideMirror(val transitionGeneration: Long) : Action
    }

    data class Snapshot(
        val phase: Phase,
        val lease: Lease?,
        val visualDemand: Boolean,
        val inFlight: Ticket?,
        val pendingEnsure: Boolean,
        val retryScheduled: Boolean,
        val requestSequence: Long,
    )

    private var phase = Phase.IDLE
    private var lease: Lease? = null
    private var visualDemand = false
    private var inFlight: Ticket? = null
    private var pendingEnsure = false
    private var retryScheduled = false
    private var requestSequence = 0L
    private var privilegedReady = true

    fun snapshot() = Snapshot(
        phase = phase,
        lease = lease,
        visualDemand = visualDemand,
        inFlight = inFlight,
        pendingEnsure = pendingEnsure,
        retryScheduled = retryScheduled,
        requestSequence = requestSequence,
    )

    /**
     * Establishes/adopts a physical cover lease. routeReady is intentionally NOT
     * accepted here: a command result cannot prove current framework readiness.
     */
    fun onPhysicalLeaseHeld(
        transitionGeneration: Long,
        ownerGeneration: Long,
        leaseId: Long,
        physicalId: Long,
    ): List<Action> {
        require(transitionGeneration >= 0)
        require(ownerGeneration >= 0)
        require(leaseId > 0)
        require(physicalId >= 0)

        val nextEpoch = (lease?.epoch ?: 0L) + 1L
        lease = Lease(
            transitionGeneration = transitionGeneration,
            ownerGeneration = ownerGeneration,
            leaseId = leaseId,
            physicalId = physicalId,
            epoch = nextEpoch,
        )
        inFlight = null
        pendingEnsure = false
        retryScheduled = false
        phase = if (privilegedReady) Phase.POWER_HELD_WAITING_ROUTE else Phase.PRIVILEGE_UNAVAILABLE
        return emptyList()
    }

    fun onVisualDemand(transitionGeneration: Long, topology: Topology): List<Action> {
        val current = lease ?: return emptyList()
        if (transitionGeneration != current.transitionGeneration) return emptyList()
        visualDemand = true
        return evaluateTopology(topology, allowEnsure = true)
    }

    /** A real DisplayManager/topology observation is allowed to trigger one ensure immediately. */
    fun onTopology(topology: Topology): List<Action> = evaluateTopology(topology, allowEnsure = true)

    fun onPrivilegedUnavailable(): List<Action> {
        privilegedReady = false
        inFlight = null
        pendingEnsure = lease != null && phase != Phase.NATIVE_COVER
        retryScheduled = false
        if (lease != null && phase != Phase.NATIVE_COVER) phase = Phase.PRIVILEGE_UNAVAILABLE
        return emptyList()
    }

    fun onPrivilegedReady(topology: Topology): List<Action> {
        privilegedReady = true
        if (lease == null) return emptyList()
        if (phase == Phase.PRIVILEGE_UNAVAILABLE) phase = Phase.POWER_HELD_WAITING_ROUTE
        return evaluateTopology(topology, allowEnsure = true)
    }

    /** Reversal/new opening generation: local visibility stops immediately. */
    fun onReleaseOrReversal(transitionGeneration: Long): List<Action> {
        val actions = mutableListOf<Action>()
        if (phase == Phase.VISIBLE) actions += Action.HideMirror(transitionGeneration)
        lease = null
        visualDemand = false
        inFlight = null
        pendingEnsure = false
        retryScheduled = false
        phase = Phase.IDLE
        return actions
    }

    /**
     * Completion only affects the exact current ticket. A stale completion cannot
     * clear a newer in-flight request, mark a newer lease ready, or consume pending work.
     *
     * Crucially, completion itself is NOT a topology event. If the route is still absent,
     * a successful command waits for the next real topology event instead of recursively
     * issuing privileged work. A transport/mutation failure requests one externally paced,
     * lease-scoped retry.
     */
    fun onEnsureResult(ticket: Ticket, commandAccepted: Boolean, topology: Topology): List<Action> {
        val currentLease = lease
        val currentTicket = inFlight
        if (currentLease == null || currentTicket != ticket || !ticketMatchesLease(ticket, currentLease)) {
            return emptyList()
        }

        val observedWhileInFlight = pendingEnsure
        inFlight = null
        pendingEnsure = false
        phase = Phase.POWER_HELD_WAITING_ROUTE

        val actions = mutableListOf<Action>()
        actions += evaluateTopology(topology, allowEnsure = false)

        if (lease == null || topology.nativeCover || isRouteReady(topology, requireNotNull(lease))) {
            retryScheduled = false
            return actions
        }

        if (!privilegedReady) {
            pendingEnsure = true
            return actions
        }

        if (!commandAccepted) {
            if (!retryScheduled) {
                retryScheduled = true
                actions += Action.ScheduleMutationRetry(retryKey(requireNotNull(lease)))
            }
            return actions
        }

        // A topology event that occurred while the command was in flight is new evidence.
        // Permit exactly one follow-up; its completion cannot recursively chain another.
        if (observedWhileInFlight && inFlight == null && !retryScheduled) {
            actions += startEnsure()
        }

        return actions
    }

    /** Called by an externally paced retry policy; the key fences old generations/leases. */
    fun onScheduledMutationRetry(key: RetryKey, topology: Topology): List<Action> {
        val current = lease ?: return emptyList()
        if (!retryScheduled || key != retryKey(current)) return emptyList()
        retryScheduled = false

        val observed = evaluateTopology(topology, allowEnsure = false)
        if (lease == null || topology.nativeCover || isRouteReady(topology, requireNotNull(lease))) {
            return observed
        }
        if (!privilegedReady || inFlight != null) {
            pendingEnsure = true
            return observed
        }
        return observed + startEnsure()
    }

    private fun evaluateTopology(topology: Topology, allowEnsure: Boolean): List<Action> {
        val current = lease ?: return emptyList()
        val actions = mutableListOf<Action>()

        if (topology.nativeCover) {
            if (phase == Phase.VISIBLE) actions += Action.HideMirror(current.transitionGeneration)
            phase = Phase.NATIVE_COVER
            inFlight = null
            pendingEnsure = false
            retryScheduled = false
            visualDemand = false
            lease = null
            return actions
        }

        if (isRouteReady(topology, current)) {
            pendingEnsure = false
            retryScheduled = false
            if (phase != Phase.VISIBLE) phase = Phase.READY_HIDDEN
            if (visualDemand && phase != Phase.VISIBLE) {
                phase = Phase.VISIBLE
                actions += Action.ShowMirror(current.transitionGeneration)
            }
            return actions
        }

        if (phase == Phase.VISIBLE) {
            phase = Phase.POWER_HELD_WAITING_ROUTE
            actions += Action.HideMirror(current.transitionGeneration)
        } else if (phase != Phase.PRIVILEGE_UNAVAILABLE && inFlight == null) {
            phase = Phase.POWER_HELD_WAITING_ROUTE
        }

        if (!privilegedReady) {
            pendingEnsure = true
            return actions
        }

        if (inFlight != null) {
            pendingEnsure = true
            return actions
        }

        if (!allowEnsure) return actions

        // A fresh topology event supersedes a timer: mutation can be attempted now.
        retryScheduled = false
        actions += startEnsure()
        return actions
    }

    private fun startEnsure(): Action.EnsureHeld {
        val current = requireNotNull(lease)
        requestSequence += 1L
        val ticket = Ticket(
            transitionGeneration = current.transitionGeneration,
            ownerGeneration = current.ownerGeneration,
            leaseId = current.leaseId,
            epoch = current.epoch,
            requestSequence = requestSequence,
        )
        inFlight = ticket
        phase = Phase.ENSURE_IN_FLIGHT
        return Action.EnsureHeld(ticket)
    }

    private fun isRouteReady(topology: Topology, current: Lease): Boolean =
        topology.innerIsDefault &&
            topology.coverActive &&
            !topology.coverIsDefault &&
            topology.coverLogicalId != null &&
            topology.coverPhysicalId == current.physicalId

    private fun ticketMatchesLease(ticket: Ticket, current: Lease): Boolean =
        ticket.transitionGeneration == current.transitionGeneration &&
            ticket.ownerGeneration == current.ownerGeneration &&
            ticket.leaseId == current.leaseId &&
            ticket.epoch == current.epoch

    private fun retryKey(current: Lease) = RetryKey(
        transitionGeneration = current.transitionGeneration,
        ownerGeneration = current.ownerGeneration,
        leaseId = current.leaseId,
        epoch = current.epoch,
    )
}

/** Source-faithful model of the current 24 ms resettable display-sync debounce. */
class CurrentMainDisplayDebounce(private val delayMs: Long = 24L) {
    private var dueAt: Long? = null
    fun onDisplayCallback(nowMs: Long) { dueAt = nowMs + delayMs }
    fun dueAtMs(): Long? = dueAt
    fun canRun(nowMs: Long): Boolean = dueAt?.let { nowMs >= it } == true
}
