package rnd.fold7

private class T {
    var passed = 0
    var failed = 0
    fun check(name: String, block: () -> Unit) {
        try {
            block(); passed++; println("PASS $name")
        } catch (t: Throwable) {
            failed++; println("FAIL $name :: ${t.message}")
        }
    }
}

private fun readyTopology(physical: Long = 222L, logical: Int = 7) =
    Fold7CoverReadinessGen2.Topology(
        innerIsDefault = true,
        innerActive = true,
        coverActive = true,
        coverIsDefault = false,
        coverLogicalId = logical,
        coverPhysicalId = physical,
    )

private fun missingRoute() =
    Fold7CoverReadinessGen2.Topology(
        innerIsDefault = true,
        innerActive = true,
        coverActive = false,
        coverIsDefault = false,
        coverLogicalId = null,
        coverPhysicalId = null,
    )

private fun nativeCover() =
    Fold7CoverReadinessGen2.Topology(
        innerIsDefault = false,
        innerActive = false,
        coverActive = true,
        coverIsDefault = true,
        coverLogicalId = 0,
        coverPhysicalId = 222L,
    )

private fun newModel(gen: Long = 10L): Fold7CoverReadinessGen2 =
    Fold7CoverReadinessGen2().also {
        it.onPhysicalLeaseHeld(gen, gen, 1L, 222L)
    }

fun main() {
    val t = T()

    t.check("current debounce imposes 24ms after last callback") {
        val d = CurrentMainDisplayDebounce()
        d.onDisplayCallback(0); check(d.dueAtMs() == 24L)
        d.onDisplayCallback(10); check(d.dueAtMs() == 34L)
        d.onDisplayCallback(20); check(d.dueAtMs() == 44L)
        check(!d.canRun(43)); check(d.canRun(44))
    }

    t.check("callback storm can extend current debounce indefinitely") {
        val d = CurrentMainDisplayDebounce()
        for (ms in 0L..990L step 10L) d.onDisplayCallback(ms)
        check(d.dueAtMs() == 1014L); check(!d.canRun(1000L))
    }

    t.check("gen2 first missing-route event immediately emits one ensure") {
        val m = newModel(); val a = m.onTopology(missingRoute())
        check(a.size == 1 && a.single() is Fold7CoverReadinessGen2.Action.EnsureHeld)
        check(m.snapshot().phase == Fold7CoverReadinessGen2.Phase.ENSURE_IN_FLIGHT)
    }

    t.check("duplicate callbacks do not duplicate ensure while in flight") {
        val m = newModel(); check(m.onTopology(missingRoute()).size == 1)
        repeat(100) { check(m.onTopology(missingRoute()).isEmpty()) }
        check(m.snapshot().pendingEnsure); check(m.snapshot().requestSequence == 1L)
    }

    t.check("route ready before visual remains hidden") {
        val m = newModel(); check(m.onTopology(readyTopology()).isEmpty())
        check(m.snapshot().phase == Fold7CoverReadinessGen2.Phase.READY_HIDDEN)
    }

    t.check("visual demand shows exactly when route is freshly ready") {
        val m = newModel()
        check(m.onVisualDemand(10L, missingRoute()).single() is Fold7CoverReadinessGen2.Action.EnsureHeld)
        val ticket = requireNotNull(m.snapshot().inFlight)
        val a = m.onEnsureResult(ticket, commandAccepted = true, topology = readyTopology())
        check(a.count { it is Fold7CoverReadinessGen2.Action.ShowMirror } == 1)
        check(m.snapshot().phase == Fold7CoverReadinessGen2.Phase.VISIBLE)
    }

    t.check("command acceptance without active route never shows or self-loops") {
        val m = newModel(); m.onVisualDemand(10L, missingRoute())
        val ticket = requireNotNull(m.snapshot().inFlight)
        val a = m.onEnsureResult(ticket, commandAccepted = true, topology = missingRoute())
        check(a.none { it is Fold7CoverReadinessGen2.Action.ShowMirror })
        check(a.none { it is Fold7CoverReadinessGen2.Action.EnsureHeld })
        check(m.snapshot().inFlight == null)
        check(m.snapshot().phase == Fold7CoverReadinessGen2.Phase.POWER_HELD_WAITING_ROUTE)
    }

    t.check("callback while ensure is in flight permits at most one follow-up") {
        val m = newModel(); m.onVisualDemand(10L, missingRoute())
        val first = requireNotNull(m.snapshot().inFlight)
        repeat(20) { m.onTopology(missingRoute()) }
        val a = m.onEnsureResult(first, commandAccepted = true, topology = missingRoute())
        check(a.count { it is Fold7CoverReadinessGen2.Action.EnsureHeld } == 1)
        val second = requireNotNull(m.snapshot().inFlight)
        val b = m.onEnsureResult(second, commandAccepted = true, topology = missingRoute())
        check(b.none { it is Fold7CoverReadinessGen2.Action.EnsureHeld })
        check(m.snapshot().inFlight == null)
    }

    t.check("route drop while visible hides then immediately reasserts") {
        val m = newModel(); m.onTopology(readyTopology())
        check(m.onVisualDemand(10L, readyTopology()).single() is Fold7CoverReadinessGen2.Action.ShowMirror)
        val a = m.onTopology(missingRoute())
        check(a.any { it is Fold7CoverReadinessGen2.Action.HideMirror })
        check(a.any { it is Fold7CoverReadinessGen2.Action.EnsureHeld })
    }

    t.check("physical mismatch is never considered ready") {
        val m = newModel(); val a = m.onVisualDemand(10L, readyTopology(physical = 999L))
        check(a.none { it is Fold7CoverReadinessGen2.Action.ShowMirror })
        check(a.any { it is Fold7CoverReadinessGen2.Action.EnsureHeld })
    }

    t.check("stale completion from prior owner cannot make new owner visible") {
        val m = newModel(gen = 10L); m.onVisualDemand(10L, missingRoute())
        val old = requireNotNull(m.snapshot().inFlight)
        m.onPhysicalLeaseHeld(20L, 20L, 2L, 222L); m.onVisualDemand(20L, missingRoute())
        val current = requireNotNull(m.snapshot().inFlight); check(current != old)
        check(m.onEnsureResult(old, true, readyTopology()).isEmpty())
        check(m.snapshot().inFlight == current)
    }

    t.check("reversal makes late completion inert") {
        val m = newModel(); m.onVisualDemand(10L, missingRoute())
        val ticket = requireNotNull(m.snapshot().inFlight); m.onReleaseOrReversal(11L)
        check(m.onEnsureResult(ticket, true, readyTopology()).isEmpty())
        check(m.snapshot().phase == Fold7CoverReadinessGen2.Phase.IDLE)
    }

    t.check("native cover takeover cancels Duo readiness ownership") {
        val m = newModel(); m.onVisualDemand(10L, missingRoute())
        val a = m.onTopology(nativeCover())
        check(a.none { it is Fold7CoverReadinessGen2.Action.ShowMirror })
        check(m.snapshot().phase == Fold7CoverReadinessGen2.Phase.NATIVE_COVER)
        check(m.snapshot().lease == null)
    }

    t.check("privilege loss degrades without mutation then recovers from topology") {
        val m = newModel(); m.onPrivilegedUnavailable(); check(m.onTopology(missingRoute()).isEmpty())
        check(m.onPrivilegedReady(missingRoute()).single() is Fold7CoverReadinessGen2.Action.EnsureHeld)
    }

    t.check("logical id remap with same physical cover stays ready") {
        val m = newModel(); m.onTopology(readyTopology(logical = 7)); m.onVisualDemand(10L, readyTopology(logical = 7))
        val a = m.onTopology(readyTopology(logical = 11))
        check(a.none { it is Fold7CoverReadinessGen2.Action.HideMirror })
        check(a.none { it is Fold7CoverReadinessGen2.Action.EnsureHeld })
        check(m.snapshot().phase == Fold7CoverReadinessGen2.Phase.VISIBLE)
    }

    t.check("same logical id remapped to wrong physical cover is rejected") {
        val m = newModel(); m.onTopology(readyTopology(logical = 7)); m.onVisualDemand(10L, readyTopology(logical = 7))
        val a = m.onTopology(readyTopology(physical = 999L, logical = 7))
        check(a.any { it is Fold7CoverReadinessGen2.Action.HideMirror })
        check(a.any { it is Fold7CoverReadinessGen2.Action.EnsureHeld })
    }

    t.check("failed mutation schedules one fenced retry instead of immediate loop") {
        val m = newModel(); m.onVisualDemand(10L, missingRoute())
        val first = requireNotNull(m.snapshot().inFlight)
        val a = m.onEnsureResult(first, commandAccepted = false, topology = missingRoute())
        check(a.count { it is Fold7CoverReadinessGen2.Action.ScheduleMutationRetry } == 1)
        check(a.none { it is Fold7CoverReadinessGen2.Action.EnsureHeld })
        check(m.snapshot().inFlight == null); check(m.snapshot().retryScheduled)
    }

    t.check("scheduled retry is fenced and starts one new ticket") {
        val m = newModel(); m.onVisualDemand(10L, missingRoute())
        val first = requireNotNull(m.snapshot().inFlight)
        val a = m.onEnsureResult(first, commandAccepted = false, topology = missingRoute())
        val key = (a.single { it is Fold7CoverReadinessGen2.Action.ScheduleMutationRetry } as Fold7CoverReadinessGen2.Action.ScheduleMutationRetry).key
        val b = m.onScheduledMutationRetry(key, missingRoute())
        check(b.count { it is Fold7CoverReadinessGen2.Action.EnsureHeld } == 1)
        check(requireNotNull(m.snapshot().inFlight).requestSequence > first.requestSequence)
    }

    t.check("stale scheduled retry after reversal is inert") {
        val m = newModel(); m.onVisualDemand(10L, missingRoute())
        val first = requireNotNull(m.snapshot().inFlight)
        val a = m.onEnsureResult(first, commandAccepted = false, topology = missingRoute())
        val key = (a.single() as Fold7CoverReadinessGen2.Action.ScheduleMutationRetry).key
        m.onReleaseOrReversal(11L)
        check(m.onScheduledMutationRetry(key, missingRoute()).isEmpty())
        check(m.snapshot().phase == Fold7CoverReadinessGen2.Phase.IDLE)
    }

    t.check("privilege reconnect with already-ready route needs no mutation") {
        val m = newModel(); m.onPrivilegedUnavailable(); val a = m.onPrivilegedReady(readyTopology())
        check(a.none { it is Fold7CoverReadinessGen2.Action.EnsureHeld })
        check(m.snapshot().phase == Fold7CoverReadinessGen2.Phase.READY_HIDDEN)
    }

    t.check("process restart can safely adopt recovered lease hidden") {
        val recovered = Fold7CoverReadinessGen2()
        recovered.onPhysicalLeaseHeld(77L, 77L, 9L, 222L)
        check(recovered.onTopology(readyTopology()).isEmpty())
        check(recovered.snapshot().phase == Fold7CoverReadinessGen2.Phase.READY_HIDDEN)
        check(!recovered.snapshot().visualDemand)
    }

    t.check("fixed-seed fuzz preserves core invariants") {
        val rnd = java.util.Random(0xF0177L)
        val m = Fold7CoverReadinessGen2(); var gen = 1L
        m.onPhysicalLeaseHeld(gen, gen, gen, 222L)
        repeat(100_000) {
            when (rnd.nextInt(9)) {
                0 -> m.onTopology(missingRoute())
                1 -> m.onTopology(readyTopology())
                2 -> m.onTopology(readyTopology(physical = 999L))
                3 -> m.onVisualDemand(gen, if (rnd.nextBoolean()) readyTopology() else missingRoute())
                4 -> m.snapshot().inFlight?.let { ticket -> m.onEnsureResult(ticket, rnd.nextBoolean(), if (rnd.nextBoolean()) readyTopology() else missingRoute()) }
                5 -> { m.onPrivilegedUnavailable(); if (rnd.nextBoolean()) m.onPrivilegedReady(missingRoute()) }
                6 -> if (rnd.nextInt(20) == 0) { gen++; m.onPhysicalLeaseHeld(gen, gen, gen, 222L) }
                7 -> if (rnd.nextInt(30) == 0) { m.onReleaseOrReversal(gen + 1); gen++; m.onPhysicalLeaseHeld(gen, gen, gen, 222L) }
                8 -> if (m.snapshot().retryScheduled) {
                    val l = requireNotNull(m.snapshot().lease)
                    m.onScheduledMutationRetry(Fold7CoverReadinessGen2.RetryKey(l.transitionGeneration,l.ownerGeneration,l.leaseId,l.epoch), missingRoute())
                }
            }
            val s = m.snapshot()
            if (s.phase == Fold7CoverReadinessGen2.Phase.VISIBLE) { check(s.visualDemand); check(s.lease != null) }
            if (s.inFlight != null) {
                check(s.lease != null); check(s.inFlight.leaseId == s.lease.leaseId)
                check(s.inFlight.epoch == s.lease.epoch); check(s.inFlight.transitionGeneration == s.lease.transitionGeneration)
            }
            if (s.retryScheduled) check(s.lease != null)
        }
    }

    println("RESULT passed=${t.passed} failed=${t.failed} total=${t.passed+t.failed}")
    if (t.failed != 0) error("test failures=${t.failed}")
}
