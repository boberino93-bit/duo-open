PURPOSE
R&D-only evidence package for the Duo Open Galaxy Z Fold7 cover presentation-readiness / topology-ingress subsystem. It is intended for direct import into the primary supervising agent (Root) for independent comparison against current main.

BASELINE SHA
926fd4ec81a7f45fba832717e4758e03875da61c

FINAL CHECKED MAIN SHA
8f844ba8aadd8417a92ec8b568288fd0dd9e06e3

FILES INCLUDED
- DUO_OPEN_COVER_READINESS_GEN2_RND_HANDOFF.txt
- Fold7CoverReadinessGen2.kt
- Fold7CoverReadinessGen2Test.kt
- timing_model.py
- TEST_OUTPUT.txt
- TIMING_MODEL_OUTPUT.txt
- README.txt
- BASELINE-SHA.txt
- FINAL-MAIN-SHA.txt
- SHA256SUMS.txt

HOW TO REPRODUCE TESTS
From a directory containing the two Kotlin files:
  kotlinc Fold7CoverReadinessGen2.kt Fold7CoverReadinessGen2Test.kt -include-runtime -d cover-readiness-gen2-tests.jar
  java -jar cover-readiness-gen2-tests.jar
Expected revised result:
  RESULT passed=22 failed=0 total=22

Timing model:
  python3 timing_model.py
All timing-model numbers are MODELED/source-derived, not Fold7 measurements.

INTEGRATION INTENT
Do not mechanically apply this package to production. Re-fetch main first, compare it to FINAL CHECKED MAIN SHA, inspect overlapping source changes, and manually integrate only the readiness-owner / fast-topology-lane invariants that remain valid. Preserve all current lease ownership, no-raw-OFF, logical-ID ephemerality, thresholds, Transition Lab, deterministic-frame and early-wake work.

KNOWN RISKS
- Samsung/Fold7 route publication and callback timing are not proven by AOSP.
- Strict readiness gating can be conservative if app-visible display state lags physical readiness.
- Immediate topology observation must remain cheap and must not pull heavy PanelEngine/screenshot/render work onto the main callback fast lane.
- Genuine privileged mutation retry needs pacing; route-not-ready must not be confused with mutation failure.
- Device field validation is mandatory before production conclusions.

PRODUCTION STATUS=R&D ONLY
MANUAL REVIEW REQUIRED
FOLD7 FIELD VALIDATION REQUIRED
