#!/usr/bin/env python3
"""Compile append-only Duo Open human-input observations into a qualitative model.

This is deliberately simple and inspectable: it counts project communication signals
and request types. It does not infer sensitive traits or claim statistical certainty.
"""
from __future__ import annotations
import argparse, json
from collections import Counter
from pathlib import Path
from datetime import datetime, timezone

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('observations', type=Path)
    ap.add_argument('-o','--output', type=Path, required=True)
    args=ap.parse_args()
    files=sorted(args.observations.glob('*.json')) if args.observations.is_dir() else [args.observations]
    obs=[]
    for f in files:
        x=json.loads(f.read_text(encoding='utf-8'))
        if x.get('schema')!='duoopen-human-input-observation/v1':
            continue
        obs.append((f,x))
    sig=Counter(); req=Counter(); nextq=Counter()
    for _,x in obs:
        req[x.get('request_type','other')]+=1
        sig.update(x.get('communication_signals',[]))
        if x.get('actual_next_request_archetype'): nextq[x['actual_next_request_archetype']]+=1
    out={
      'schema':'duoopen-human-interaction-model-compiled/v1',
      'created_utc':datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z'),
      'observation_count':len(obs),
      'request_type_counts':dict(req.most_common()),
      'communication_signal_counts':dict(sig.most_common()),
      'observed_next_request_archetypes':dict(nextq.most_common()),
      'evidence':[str(f) for f,_ in obs],
      'note':'Counts are descriptive project-communication evidence, not sensitive-trait inference or calibrated prediction.'
    }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2)+"\n",encoding='utf-8')
if __name__=='__main__': main()
