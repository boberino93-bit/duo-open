# Duo Open current state — canonical round-orchestration refresh

Cutoff: 2026-10-03T03:42:52Z

## Source / CI truth
- Application source baseline: `1cf46d7505ee74a8f4434be6d77a890ddce57ac1`.
- Gen7 Runtime Regression Beta2 workflow run `37091317521`: **SUCCESS**.
- App: `5.1.0-beta2-zfold7`, versionCode 43.
- Tested APK SHA-256: `68799fae68bc26e72efd2c3c3e27b503150be0377d0ec55491ded9bccc19643d`.
- Cumulative SP4.2 root-safe service-pack SHA-256: `898e3b40e40b79510711a2f9a93f89c074012573fe5a8a32f84b567d9ec2025e`.
- Physical Fold7 validation of the latest wake behavior remains incomplete; do not convert CI evidence to FIELD success.

## P0 field issue
The INNER screen (not the cover/rear screen) is still not becoming visibly useful until roughly 50-60 degrees while opening. The first opening animation crashes and attempts recovery. Once the inner display/system has fully established, later animations are smooth.

Current source/research evidence includes:
- Beta2's wake proof can stop on `topologyNow.innerActive`, weaker than first useful pixels.
- Shell `usefulReady` is physical+logical power, also weaker than useful presentation.
- Research found a concrete Beta2 privileged-wake fencing regression: queued wake work can outlive generation/connection supersession and retry lineage can hop to a newer controller generation. SOURCE evidence; FIELD causality not yet proven.
- First-open crash work shifted from invalid-display synchronous-throw toward recovered-state/route/teardown concurrency; causal trace still required.

## Orchestration state
Round Orchestration V1 is canonical communication/control context for successor agents. AgentBus controls round/ticket/session state with a hard max of 20 concurrent sessions. Physical autonomous creation of sibling ChatGPT chats is not yet a validated native capability, so the Spawn Adapter reports `MANUAL_FALLBACK` unless a later validated adapter supersedes it.

## Required startup behavior
1. Verify package and role.
2. Read packaged forum snapshot.
3. Reconcile live AgentBus messages newer than 2026-10-03T03:42:52Z.
4. Preserve INNER-screen P0 unless newer human/Primary direction supersedes it.
5. Use AgentBus tickets for role/assignment and keep help requests non-preemptive.
6. Preserve complete forum snapshots and orchestration contracts in successors.
