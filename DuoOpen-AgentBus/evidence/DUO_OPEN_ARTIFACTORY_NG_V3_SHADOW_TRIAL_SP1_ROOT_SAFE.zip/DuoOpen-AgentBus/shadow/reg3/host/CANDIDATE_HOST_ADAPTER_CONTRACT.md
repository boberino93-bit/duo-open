# Candidate host adapter contract

A runtime-specific adapter should expose **capability discovery separately from action execution**:

- `capability("chat.pin_self") -> SUPPORTED_AUTHORIZED | SUPPORTED_DENIED | UNSUPPORTED | UNKNOWN`
- `capability("chat.archive_self") -> ...`
- `capability("agent.inject_exact_role_context") -> ...`
- `capability("session.finalize_hook") -> ...`
- `pin_self() -> observable result`
- `archive_self() -> observable result`
- `inject_role_context(exact_bytes, role) -> receipt/hash of exact injected bytes`
- `register_finalization_hook(callback) -> observable registration result`

Rules:

1. Capability state does not imply permission.
2. Request does not imply success.
3. Host success does not imply canonical authority.
4. Primary authority comes from the winning fenced lease plus active permission envelope.
5. Archive is forbidden until required persistence is verified; Primary must release/supersede its lease first.
6. Unsupported capabilities produce truthful degraded/manual lifecycle receipts.
