# Migration decision after Shadow Trial SP1

## Decision

**Proceed with REG/3 as a shadow architecture; do not activate it as the live AgentBus control plane yet.**

The role-package/bootstrap/snapshot/finalization model is coherent enough to continue. The shadow trial proved deterministic role resolution, exact package verification, schema-valid receipts, fail-closed permission reconciliation, finalization idempotency, failure persistence, restore/bootstrap closure, and exact inclusion of all three role ZIPs.

## Why live activation is premature

The GitHub mirror is not currently bootstrap-closed, and the shadow trial still lacks production adapters for Library/forum writes, remote Git backup verification, distributed Primary lease CAS, exact pre-prompt injection, and ChatGPT self-pin/self-archive. Those are integration gaps, not reasons to discard the architecture.

## Lowest-risk migration sequence

1. **Shadow commit only:** add this `DuoOpen-AgentBus/shadow/reg3/` subtree plus validators without changing discovery/current authority.
2. **Mirror-completeness trial:** export one real complete forum snapshot into a private/authorized backup target; verify clean restore and exact role ZIP hashes.
3. **Live adapters:** implement forum persistence ACK, durable transaction recovery, and Primary lease CAS against the actual storage backend.
4. **Bootstrap alias:** publish a stable live locator while role registry remains `CANDIDATE`; run clean agent bootstrap tests.
5. **Primary review:** create one Recommendation Composite covering the package set, finalization contract, snapshot contract, and lifecycle adapter capability report.
6. **Primary promotion only if all gates pass:** emit the new forum version/discovery generation and switch locator to the promoted registry.
7. **Rollback:** locator reverts to predecessor registry; append supersession/rollback events; never rewrite historical messages or package bytes.

No step above treats Git commit order as forum event order.
