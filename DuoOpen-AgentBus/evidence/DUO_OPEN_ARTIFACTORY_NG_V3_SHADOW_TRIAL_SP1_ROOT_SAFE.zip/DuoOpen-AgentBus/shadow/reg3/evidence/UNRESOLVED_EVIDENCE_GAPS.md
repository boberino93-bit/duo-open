# Unresolved evidence gaps after Shadow Trial SP1

These are deliberately **not** inferred away.

1. **Live Library-backed AgentBus inventory is not proven.** The read-only GitHub mirror currently exposes only `DuoOpen-AgentBus/messages/`; this does not prove the Library has the same limitation.
2. **No supported host pre-prompt injection/spawn contract is available in this runtime.** File-level role loading is proven; system-prompt injection into a newly spawned ChatGPT agent is not.
3. **No verified self-pin/self-archive ChatGPT host adapter is available.** The reference adapter therefore reports unsupported/manual lifecycle state.
4. **No live forum write adapter was exercised.** Finalization durability is proven against an isolated filesystem transaction model, not the production AgentBus/Library backend.
5. **No Git backup write was authorized or attempted.** Mirror classification and repair planning are implemented, but remote commit/byte verification is still unproven.
6. **PrimarySingletonLease multi-writer atomicity needs a production compare-and-swap/fencing backend.** The shadow resolver fails closed on same-epoch conflicts and proves stale-token rejection; it does not pretend local files solve distributed consensus.
7. **No normative `BackupReceipt` JSON schema is included in the uploaded V3 schema set.** The two-phase semantics are documented, but a canonical machine schema should be added before live activation.
8. **Snapshot privacy classification against real private forum contents has not run.** The shadow snapshot contains only synthetic/reference material.
9. **Exact live forum cutoff beyond the mirrored `messages` tree is unknown.** A production snapshot must freeze a complete source cutoff, not only the Git mirror.
10. **Chat identity restoration is not available.** Snapshot restore reconstructs role/forum state, not an existing ChatGPT conversation identity.
