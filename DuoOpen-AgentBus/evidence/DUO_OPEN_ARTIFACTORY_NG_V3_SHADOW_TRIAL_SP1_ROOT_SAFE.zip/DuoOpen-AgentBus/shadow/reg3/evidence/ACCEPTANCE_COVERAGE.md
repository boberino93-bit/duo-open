# REG/3 Shadow Trial SP1 — acceptance coverage

| Area | Shadow result | Evidence | Remaining live gate |
|---|---|---|---|
| Exactly three role packages | PASS | `role-registry/ROLE_PACKAGE_REGISTRY.json` | Primary promotion of a live registry generation |
| Package digest + internal manifest | PASS | validator + 3 clean restore loads | none for reference bytes |
| Stable locator | PASS | `bootstrap/BOOTSTRAP_LOCATOR.json` hashes registry | choose/promote live locator path |
| Dynamic locator+role loading | PASS | clean restore for PRIMARY/MANAGER_REVIEWER/RESEARCH | host-native pre-prompt injection |
| Permission reconciliation | PASS | 3 shadow PermissionEnvelopes | bind to actual live destination permissions |
| No authority by package possession | PASS | shadow Primary explicitly denied live promotion/write grants | production enforcement backend |
| BootstrapReceipt before work | PASS | 3 schema-valid receipts | durable live forum write/ACK |
| Primary fencing | PARTIAL PASS | stale token rejected; same-epoch conflict fails closed | atomic distributed CAS/lease backend |
| Finalization success | PASS | schema-valid receipt + committed transaction | live AgentBus persistence adapter |
| Finalization failure | PASS | FAILED receipt still persisted | live AgentBus persistence adapter |
| Permission-denied finalization | PASS | PERMISSION_DENIED receipt | live AgentBus persistence adapter |
| Idempotent finalization | PASS | repeated same cutoff returns identical receipt | concurrent/live retry tests |
| Persistence failure archive gate | PASS | archive action remains NOT_REQUESTED | host archive adapter |
| Recommendation-only non-Primary change | PASS | composite remains `READY_FOR_PRIMARY` | Primary review/promotion |
| Snapshot includes 3 ZIPs | PASS | exact ZIP hash checks inside snapshot | real full forum snapshot |
| Clean restore/bootstrap | PASS all roles | `SHADOW_TEST_REPORT.json` | real private evidence graph restore |
| Git mirror staleness logic | PASS synthetic cases | FRESH/STALE/UNVERIFIED/CONFLICT tests | authorized remote verification |
| Git mirror repair execution | PLAN ONLY | `MIRROR_RECONCILIATION_PLAN.json` | private backup destination + write authority |
| Software domain profile | PASS | bootstrap + restore | live workload |
| Financial-goal profile portability | PASS | same Research ZIP hash under financial profile; external execution denied | live financial profile use if desired |
| Self-pin/self-archive | UNSUPPORTED, truthful | host capability/lifecycle receipts | supported host API/tool |
| Live activation | NOT RUN | non-mutation boundary | explicit Primary/user authority |
