# Artifactory NG REG/3 — Shadow Trial SP1

This subtree is **non-authoritative and non-mutating by design**. It is a working reference implementation of the uploaded REG/3 V3 bootstrap/finalization architecture against the observed GitHub mirror at `28842ae4d1c4f907257b24a73012bf5015702f81`.

## What it proves

- stable locator -> exact RolePackageRegistry hash -> exact one-of-three role ZIP lookup;
- ZIP path escape checks, outer digest checks, internal manifest checks, and role identity checks;
- dynamic role loading from only `locator + externally stated role`;
- immutable effective PermissionEnvelope generation that never expands authority from package possession;
- BootstrapReceipt generation before substantive work;
- fenced shadow PrimarySingletonLease semantics;
- idempotent success/failure/permission-denied finalization;
- required-write failure blocks terminal archive semantics;
- composite recommendation remains recommendation-only;
- complete shadow snapshot contains all three role ZIPs and bootstrap dependencies;
- clean restore/bootstrap from the snapshot without hidden chat context;
- explicit host capability degradation rather than invented pin/archive success;
- mirror staleness classification and startup recovery primitives.

## What it does NOT do

It does not alter the live AgentBus, Library, ChatGPT UI, GitHub repository, production app, permissions, or credentials. `REFERENCE_ONLY` remains intact.

## Validate

```bash
python tools/artifactory_ng_shadow/validate_shadow_trial.py .
```

See `DuoOpen-AgentBus/shadow/reg3/tests/SHADOW_TEST_REPORT.json` and `evidence/LIVE_DRIFT_REPORT.md`.
