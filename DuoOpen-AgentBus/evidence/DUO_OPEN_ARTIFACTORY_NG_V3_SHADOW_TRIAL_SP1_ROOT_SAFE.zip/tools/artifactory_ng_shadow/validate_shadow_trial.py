#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
import tempfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from shadow_runtime import (  # noqa: E402
    ROLE_ORDER,
    load_role,
    read_json,
    restore_bootstrap_test,
    sha256_file,
    validate_schema,
    verify_role_package,
)


def fail(msg: str) -> None:
    raise SystemExit(f"VALIDATION_FAILED: {msg}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("root", nargs="?", default=".")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    forum = root / "DuoOpen-AgentBus/shadow/reg3"
    if not forum.is_dir():
        fail(f"missing forum root {forum}")

    # Root checksum closure.
    sums = root / "SHA256SUMS.txt"
    if not sums.exists():
        fail("missing SHA256SUMS.txt")
    for line in sums.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, rel = line.split("  ", 1)
        p = root / rel
        if not p.is_file():
            fail(f"checksum target missing: {rel}")
        if sha256_file(p) != digest:
            fail(f"checksum mismatch: {rel}")

    locator = read_json(forum / "bootstrap/BOOTSTRAP_LOCATOR.json")
    registry_path = forum / locator["role_package_registry_ref"]
    if sha256_file(registry_path) != locator["role_package_registry_sha256"]:
        fail("locator -> registry digest mismatch")
    registry = read_json(registry_path)
    if set(registry["packages"]) != set(ROLE_ORDER):
        fail("registry must contain exactly PRIMARY, MANAGER_REVIEWER, RESEARCH")

    # JSON schemas.
    validate_schema(locator, forum / "schemas/v3/bootstrap-locator.schema.json")
    validate_schema(registry, forum / "schemas/v3/role-package-registry.schema.json")
    validate_schema(read_json(forum / "forum/FORUM_VERSION.json"), forum / "schemas/v3/forum-version.schema.json")
    validate_schema(read_json(forum / "snapshot/SNAPSHOT_EXPORT_BUNDLE.json"), forum / "schemas/v3/snapshot-export-bundle.schema.json")
    validate_schema(read_json(forum / "recommendations/RECOMMENDATION_COMPOSITE.json"), forum / "schemas/v2/recommendation-composite.schema.json")

    for p in (forum / "permissions").glob("*.json"):
        validate_schema(read_json(p), forum / "schemas/v2/permission-envelope.schema.json")
    for p in (forum / "receipts/bootstrap").glob("*.json"):
        validate_schema(read_json(p), forum / "schemas/v3/bootstrap-receipt.schema.json")
    for p in (forum / "receipts/finalization").glob("*.json"):
        validate_schema(read_json(p), forum / "schemas/v3/finalization-receipt.schema.json")
    for p in (forum / "receipts/lifecycle").glob("*.json"):
        validate_schema(read_json(p), forum / "schemas/v3/chat-lifecycle-receipt.schema.json")
    for p in (forum / "leases").glob("*.json"):
        validate_schema(read_json(p), forum / "schemas/v3/primary-singleton-lease.schema.json")

    # Dynamic loading and role-package integrity.
    role_results = {}
    for role in ROLE_ORDER:
        loaded = load_role(forum, role)
        pointer = registry["packages"][role]
        verify_role_package(loaded.package_path, pointer["sha256"], role)
        role_results[role] = loaded.package["role_manifest"]["package_id"]

    # Snapshot closure and clean restore.
    bundle = read_json(forum / "snapshot/SNAPSHOT_EXPORT_BUNDLE.json")
    snapshot_zip = forum / "snapshot" / bundle["parts"][0]["path"]
    if sha256_file(snapshot_zip) != bundle["parts"][0]["sha256"]:
        fail("snapshot part digest mismatch")
    restore = [restore_bootstrap_test(snapshot_zip, role) for role in ROLE_ORDER]
    if not all(x["result"] == "PASS" for x in restore):
        fail("clean restore/bootstrap failed")

    # The snapshot must contain the exact three ZIP bytes advertised by the registry.
    with zipfile.ZipFile(snapshot_zip) as zf:
        names = set(zf.namelist())
        for role in ROLE_ORDER:
            pointer = registry["packages"][role]
            member = "DuoOpen-AgentBus/shadow/reg3/" + pointer["path"]
            if member not in names:
                fail(f"snapshot missing role package: {role}")
            import hashlib
            data = zf.read(member)
            if hashlib.sha256(data).hexdigest() != pointer["sha256"]:
                fail(f"snapshot role package hash mismatch: {role}")

    # Negative path-escape test against actual verifier.
    with tempfile.TemporaryDirectory() as td:
        bad = Path(td) / "bad.zip"
        with zipfile.ZipFile(bad, "w") as z:
            z.writestr("../escape.txt", "no")
            z.writestr("PACKAGE_MANIFEST.json", '{"files":[]}')
            z.writestr("ROLE_MANIFEST.json", '{"role":"RESEARCH"}')
            z.writestr("ROLE_SPEC.md", "x")
            z.writestr("FINALIZATION_CONTRACT.json", '{}')
        try:
            verify_role_package(bad)
        except ValueError as e:
            if "unsafe zip member" not in str(e):
                fail(f"path escape failed for wrong reason: {e}")
        else:
            fail("unsafe ZIP path was accepted")

    report = read_json(forum / "tests/SHADOW_TEST_REPORT.json")
    if report.get("result") != "PASS":
        fail("shadow test report not PASS")
    if report.get("live_mutation_performed") is not False:
        fail("shadow report does not preserve non-mutation boundary")

    print(json.dumps({
        "result": "VALIDATION_OK",
        "roles": role_results,
        "snapshot_sha256": sha256_file(snapshot_zip),
        "restore": restore,
        "root_checksum_entries": len(sums.read_text(encoding="utf-8").splitlines()),
    }, indent=2))


if __name__ == "__main__":
    main()
