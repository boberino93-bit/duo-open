from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from shadow_runtime import (  # noqa: E402
    ROLE_ORDER,
    bootstrap_agent,
    finalize_work_unit,
    load_role,
    mirror_status,
    read_json,
    recovery_sweep,
    verify_primary_fence,
    verify_role_package,
    resolve_primary_lease,
)

ROOT = Path(__file__).resolve().parents[3]
FORUM = ROOT / "DuoOpen-AgentBus/shadow/reg3"


class ShadowRuntimeTests(unittest.TestCase):
    def test_dynamic_role_loading_exactly_three(self):
        self.assertEqual(set(read_json(FORUM / "role-registry/ROLE_PACKAGE_REGISTRY.json")["packages"]), set(ROLE_ORDER))
        for role in ROLE_ORDER:
            loaded = load_role(FORUM, role)
            self.assertEqual(loaded.package["role_manifest"]["role"], role)

    def test_bad_outer_hash_is_rejected(self):
        loaded = load_role(FORUM, "RESEARCH")
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            verify_role_package(loaded.package_path, "0" * 64, "RESEARCH")

    def test_zip_slip_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "bad.zip"
            with zipfile.ZipFile(p, "w") as z:
                z.writestr("../evil", "x")
                z.writestr("PACKAGE_MANIFEST.json", '{"files":[]}')
                z.writestr("ROLE_MANIFEST.json", '{"role":"RESEARCH"}')
                z.writestr("ROLE_SPEC.md", "x")
                z.writestr("FINALIZATION_CONTRACT.json", '{}')
            with self.assertRaisesRegex(ValueError, "unsafe zip member"):
                verify_role_package(p)

    def test_shadow_primary_never_receives_live_promotion_grant(self):
        with tempfile.TemporaryDirectory() as td:
            shadow = Path(td) / "forum"
            shutil.copytree(FORUM, shadow)
            receipt, perm = bootstrap_agent(
                shadow,
                "PRIMARY",
                "primary-test-isolated",
                {"READ_EVIDENCE", "WRITE_EVIDENCE", "PROMOTE_POLICY", "WRITE_CANONICAL_FORUM"},
                "2026-10-03T01:05:00Z",
            )
            self.assertNotIn("PROMOTE_POLICY", perm["grants"])
            self.assertIn("PROMOTE_POLICY", perm["denials"])
            self.assertIn("WRITE_CANONICAL_FORUM", perm["denials"])

    def test_primary_fence_rejects_stale_instance(self):
        lease = read_json(FORUM / "leases/primary-lease-shadow-1-claim.json")
        self.assertTrue(verify_primary_fence(lease, "primary-shadow-001", lease["fencing_token"]))
        self.assertFalse(verify_primary_fence(lease, "primary-shadow-stale", lease["fencing_token"]))
        self.assertFalse(verify_primary_fence(lease, "primary-shadow-001", "wrong"))

    def test_primary_lease_conflict_fails_closed(self):
        a = {"lease_event_id":"a","lease_epoch":4,"event":"CLAIM","state":"ACTIVE","agent_instance_id":"p1","fencing_token":"t1"}
        b = {"lease_event_id":"b","lease_epoch":4,"event":"CLAIM","state":"ACTIVE","agent_instance_id":"p2","fencing_token":"t2"}
        r = resolve_primary_lease([a,b])
        self.assertEqual(r["state"], "CONFLICT")
        self.assertIsNone(r["winner"])

    def test_primary_lease_unique_highest_epoch(self):
        a = {"lease_event_id":"a","lease_epoch":3,"event":"CLAIM","state":"ACTIVE","agent_instance_id":"p1","fencing_token":"t1"}
        b = {"lease_event_id":"b","lease_epoch":4,"event":"CLAIM","state":"ACTIVE","agent_instance_id":"p2","fencing_token":"t2"}
        r = resolve_primary_lease([a,b])
        self.assertEqual(r["state"], "UNIQUE_ACTIVE")
        self.assertEqual(r["winner"]["agent_instance_id"], "p2")

    def test_finalization_is_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            shadow = Path(td) / "forum"
            shutil.copytree(FORUM, shadow)
            payload = {"evidence": [{"x": 1}], "material_events": [{"x": 2}]}
            args = dict(
                forum_root=shadow,
                work_unit_id="wu-idempotency-test",
                agent_instance_id="research-shadow-001",
                bootstrap_receipt_ref="receipts/bootstrap/bootstrap-research-shadow-001.json",
                role_package_ref="reg3-research-reference-v2",
                forum_version_ref="forum-reg3-shadow-trial-001",
                permission_envelope_ref="permissions/perm-shadow-research-shadow-001.json",
                now_utc="2026-10-03T01:05:00Z",
                terminal_reason="SUCCESS",
                payload=payload,
            )
            a = finalize_work_unit(**args)
            b = finalize_work_unit(**args)
            self.assertEqual(a, b)
            self.assertTrue(a["required_writes_verified"])

    def test_required_write_failure_is_not_complete(self):
        receipt = next(
            read_json(p) for p in (FORUM / "receipts/finalization").glob("*.json")
            if read_json(p)["work_unit_id"] == "wu-research-shadow-write-failure-001"
        )
        self.assertFalse(receipt["required_writes_verified"])
        self.assertEqual(receipt["persistence_state"], "FAILED")
        lifecycle = read_json(FORUM / "receipts/lifecycle/lifecycle-research-archive-blocked-001.json")
        self.assertEqual(lifecycle["action_state"], "NOT_REQUESTED")
        self.assertFalse(lifecycle["required_writes_verified"])

    def test_recovery_sweep_sees_failed_staging(self):
        findings = recovery_sweep(FORUM)
        self.assertTrue(any(x["state"] == "ABANDONED_STAGING" for x in findings))

    def test_mirror_states(self):
        self.assertEqual(mirror_status("a", "a"), "FRESH")
        self.assertEqual(mirror_status("a", "b"), "STALE")
        self.assertEqual(mirror_status("a", None), "UNVERIFIED")
        self.assertEqual(mirror_status("a", "a", True), "CONFLICT")

    def test_financial_profile_does_not_change_role_package(self):
        with tempfile.TemporaryDirectory() as td:
            shadow = Path(td) / "forum"
            shutil.copytree(FORUM, shadow)
            before = load_role(shadow, "RESEARCH").package["sha256"]
            receipt, perm = bootstrap_agent(
                shadow,
                "RESEARCH",
                "research-financial-test",
                {"READ_EVIDENCE", "WRITE_EVIDENCE", "WRITE_RECOMMENDATION", "RUN_SANDBOX_TEST"},
                "2026-10-03T01:05:00Z",
                domain_profile_ref="profiles/financial-goal-planning.synthetic.json",
            )
            after = load_role(shadow, "RESEARCH").package["sha256"]
            self.assertEqual(before, after)
            self.assertEqual(receipt["domain_profile_ref"], "profiles/financial-goal-planning.synthetic.json")
            self.assertIn("EXECUTE_EXTERNAL_ACTION", perm["denials"])


if __name__ == "__main__":
    unittest.main()
