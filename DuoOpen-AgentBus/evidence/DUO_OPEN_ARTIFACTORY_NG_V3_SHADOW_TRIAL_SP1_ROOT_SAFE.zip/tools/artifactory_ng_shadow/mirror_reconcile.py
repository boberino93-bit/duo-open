#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from shadow_runtime import mirror_status, read_json, sha256_file  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser(description="REG/3 shadow mirror classifier / repair-plan generator")
    ap.add_argument("forum_root", type=Path)
    ap.add_argument("--remote-observation", type=Path)
    ap.add_argument("--out", type=Path)
    args = ap.parse_args()
    forum = args.forum_root.resolve()
    bundle = read_json(forum / "snapshot/SNAPSHOT_EXPORT_BUNDLE.json")
    expected = bundle["snapshot_root_sha256"]
    remote = read_json(args.remote_observation) if args.remote_observation else {}
    remote_digest = remote.get("snapshot_root_sha256")
    conflict = bool(remote.get("lineage_conflict", False))
    status = mirror_status(expected, remote_digest, conflict)
    plan = {
        "schema": "duoopen-artifactory-ng/mirror-reconciliation-plan/v1",
        "mode": "PLAN_ONLY",
        "expected_snapshot_id": bundle["snapshot_id"],
        "expected_snapshot_root_sha256": expected,
        "snapshot_part": bundle["parts"][0],
        "remote_observation": remote,
        "status": status,
        "authorized_to_mutate_remote": False,
        "actions_if_authorized": [],
        "postcondition": "Remote snapshot bytes/hash verified, then append a later BackupReceipt; never rewrite the already-hashed snapshot.",
    }
    if status == "FRESH":
        plan["actions_if_authorized"] = ["NO_UPLOAD", "VERIFY_REMOTE_COMMIT_AND_BYTES", "APPEND_BACKUP_RECEIPT_IF_NOT_ALREADY_PRESENT"]
    elif status == "STALE":
        plan["actions_if_authorized"] = ["UPLOAD_NEW_IMMUTABLE_SNAPSHOT_GENERATION", "VERIFY_REMOTE_BYTES", "APPEND_LATER_BACKUP_RECEIPT"]
    elif status == "UNVERIFIED":
        plan["actions_if_authorized"] = ["READ_REMOTE_MANIFEST_OR_TREAT_AS_MISSING", "UPLOAD_IF_MISSING", "VERIFY_REMOTE_BYTES", "APPEND_LATER_BACKUP_RECEIPT"]
    else:
        plan["actions_if_authorized"] = ["STOP", "MANUAL_LINEAGE_RECONCILIATION_REQUIRED", "DO_NOT_OVERWRITE"]
    text = json.dumps(plan, indent=2) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
