#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

try:
    import jsonschema
except Exception:  # pragma: no cover
    jsonschema = None

ROLE_ORDER = ("PRIMARY", "MANAGER_REVIEWER", "RESEARCH")


def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=False) + "\n", encoding="utf-8")


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def safe_join(root: Path, rel: str) -> Path:
    if not rel or os.path.isabs(rel):
        raise ValueError(f"unsafe path: {rel!r}")
    p = (root / rel).resolve()
    rr = root.resolve()
    if p != rr and rr not in p.parents:
        raise ValueError(f"path escapes root: {rel!r}")
    return p


def verify_zip_paths(zf: zipfile.ZipFile) -> None:
    for name in zf.namelist():
        normalized = name.replace("\\", "/")
        if normalized.startswith("/") or normalized.startswith("../") or "/../" in f"/{normalized}":
            raise ValueError(f"unsafe zip member: {name}")


def verify_role_package(path: Path, expected_sha256: str | None = None, expected_role: str | None = None) -> dict[str, Any]:
    outer = sha256_file(path)
    if expected_sha256 and outer != expected_sha256:
        raise ValueError(f"role package hash mismatch: expected {expected_sha256}, got {outer}")
    with zipfile.ZipFile(path) as zf:
        verify_zip_paths(zf)
        names = set(zf.namelist())
        required = {"PACKAGE_MANIFEST.json", "ROLE_MANIFEST.json", "ROLE_SPEC.md", "FINALIZATION_CONTRACT.json"}
        missing = sorted(required - names)
        if missing:
            raise ValueError(f"role package missing {missing}")
        pkg_manifest = json.loads(zf.read("PACKAGE_MANIFEST.json"))
        for entry in pkg_manifest.get("files", []):
            n = entry["path"]
            if n not in names:
                raise ValueError(f"manifest member missing: {n}")
            data = zf.read(n)
            if len(data) != entry["bytes"]:
                raise ValueError(f"size mismatch for {n}")
            if sha256_bytes(data) != entry["sha256"]:
                raise ValueError(f"hash mismatch for {n}")
        role_manifest = json.loads(zf.read("ROLE_MANIFEST.json"))
        if expected_role and role_manifest["role"] != expected_role:
            raise ValueError(f"role mismatch: expected {expected_role}, got {role_manifest['role']}")
        return {
            "sha256": outer,
            "bytes": path.stat().st_size,
            "package_manifest": pkg_manifest,
            "role_manifest": role_manifest,
            "role_spec": zf.read("ROLE_SPEC.md").decode("utf-8"),
            "permission_expectations": json.loads(zf.read("PERMISSION_EXPECTATIONS.json")),
            "bootstrap_sequence": json.loads(zf.read("BOOTSTRAP_SEQUENCE.json")),
            "finalization_contract": json.loads(zf.read("FINALIZATION_CONTRACT.json")),
            "chat_lifecycle_policy": json.loads(zf.read("CHAT_LIFECYCLE_POLICY.json")),
        }


def validate_schema(instance: dict[str, Any], schema_path: Path) -> None:
    if jsonschema is None:
        raise RuntimeError("jsonschema is required for schema validation")
    schema = read_json(schema_path)
    jsonschema.Draft202012Validator(schema).validate(instance)


@dataclass(frozen=True)
class LoadedRole:
    role: str
    package_path: Path
    registry: dict[str, Any]
    package: dict[str, Any]


def load_role(forum_root: Path, role: str) -> LoadedRole:
    if role not in ROLE_ORDER:
        raise ValueError(f"unknown role {role}")
    locator_path = forum_root / "bootstrap/BOOTSTRAP_LOCATOR.json"
    locator = read_json(locator_path)
    registry_path = safe_join(forum_root, locator["role_package_registry_ref"])
    actual_registry_sha = sha256_file(registry_path)
    if actual_registry_sha != locator["role_package_registry_sha256"]:
        raise ValueError("registry hash does not match stable locator")
    registry = read_json(registry_path)
    pointer = registry["packages"][role]
    package_path = safe_join(forum_root, pointer["path"])
    package = verify_role_package(package_path, pointer["sha256"], role)
    if package_path.stat().st_size != pointer["bytes"]:
        raise ValueError("registry package byte count mismatch")
    if package["role_manifest"]["package_id"] != pointer["package_id"]:
        raise ValueError("registry package id mismatch")
    return LoadedRole(role, package_path, registry, package)


def reconcile_permissions(
    forum_root: Path,
    loaded: LoadedRole,
    principal_id: str,
    actual_capabilities: Iterable[str],
    now_utc: str,
    forum_version_ref: str,
    domain_profile_ref: str,
) -> dict[str, Any]:
    expected = loaded.package["permission_expectations"]
    actual = set(actual_capabilities)
    wanted = set(expected.get("expected_capabilities", []))
    grants = sorted(actual & wanted)
    denials = set(expected.get("mandatory_denials", []))
    denials |= wanted - actual
    # Shadow trial never grants live authority merely because the package asks for it.
    denials |= {"WRITE_PRODUCTION", "COMMIT_GIT", "EXECUTE_EXTERNAL_ACTION"}
    if loaded.role != "PRIMARY":
        denials |= {"PROMOTE_POLICY", "ACTIVATE_ROLE_PACKAGE_SET", "WRITE_CANONICAL_FORUM"}
    else:
        # Primary semantics are demonstrated, but this reference trial is explicitly non-authoritative.
        denials |= {"PROMOTE_POLICY", "ACTIVATE_ROLE_PACKAGE_SET", "WRITE_CANONICAL_FORUM"}
        grants = [g for g in grants if g not in denials]
    envelope = {
        "schema": "reg-core/permission-envelope/v1",
        "permission_id": f"perm-shadow-{principal_id}",
        "principal_id": principal_id,
        "role": loaded.role,
        "project": "duo-open",
        "domain_profile_ref": domain_profile_ref,
        "effective_from_utc": now_utc,
        "forum_version_ref": forum_version_ref,
        "grants": grants,
        "denials": sorted(denials),
        "authority_basis_refs": [
            f"role-package://{loaded.package['role_manifest']['package_id']}",
            "shadow-trial://non-live-authority-boundary",
        ],
        "escalation_route": ["MANAGER_REVIEWER", "PRIMARY"] if loaded.role == "RESEARCH" else (["PRIMARY"] if loaded.role == "MANAGER_REVIEWER" else []),
        "data_limits": {"live_mutation": False, "public_export": False},
        "scope": {"project": "duo-open", "mode": "SHADOW_ONLY"},
        "predecessor_permission_id": None,
        "integrity": {"generated_by": "shadow_runtime.py"},
        "extensions": {"not_live_authority": True},
    }
    return envelope


def bootstrap_agent(
    forum_root: Path,
    role: str,
    agent_instance_id: str,
    actual_capabilities: Iterable[str],
    now_utc: str,
    domain_profile_ref: str = "profiles/duo-open-software.synthetic.json",
    board_cutoff_seen: str = "github:DuoOpen-AgentBus/messages@b7899bea781b0434044086ba1c1e906698dc349d",
) -> tuple[dict[str, Any], dict[str, Any]]:
    loaded = load_role(forum_root, role)
    forum_version = read_json(forum_root / "forum/FORUM_VERSION.json")
    perm = reconcile_permissions(
        forum_root,
        loaded,
        agent_instance_id,
        actual_capabilities,
        now_utc,
        forum_version["version_id"],
        domain_profile_ref,
    )
    perm_path = forum_root / f"permissions/{perm['permission_id']}.json"
    write_json(perm_path, perm)
    expected = set(loaded.package["permission_expectations"].get("expected_capabilities", []))
    missing = sorted(expected - set(actual_capabilities))
    compatibility = "EXACT" if not missing else "ADAPTED"
    receipt = {
        "schema": "reg-core/bootstrap-receipt/v1",
        "receipt_id": f"bootstrap-{agent_instance_id}",
        "agent_instance_id": agent_instance_id,
        "role": role,
        "timestamp_utc": now_utc,
        "locator_ref": "bootstrap/BOOTSTRAP_LOCATOR.json",
        "registry_ref": "role-registry/ROLE_PACKAGE_REGISTRY.json",
        "package_id": loaded.package["role_manifest"]["package_id"],
        "package_sha256": loaded.package["sha256"],
        "forum_version_ref": forum_version["version_id"],
        "domain_profile_ref": domain_profile_ref,
        "permission_envelope_ref": perm_path.relative_to(forum_root).as_posix(),
        "runtime_compatibility": compatibility,
        "reconstruction_report_ref": None,
        "capability_deltas": [f"missing:{x}" for x in missing] + ["shadow-only: canonical/live mutation deliberately denied"],
        "board_cutoff_seen": board_cutoff_seen,
        "integrity": {
            "registry_sha256": sha256_file(forum_root / "role-registry/ROLE_PACKAGE_REGISTRY.json"),
            "package_verified": True,
        },
    }
    write_json(forum_root / f"receipts/bootstrap/{receipt['receipt_id']}.json", receipt)
    return receipt, perm


def make_primary_lease(
    forum_root: Path,
    agent_instance_id: str,
    permission_envelope_ref: str,
    role_package_ref: str,
    forum_version_ref: str,
    epoch: int,
    now_utc: str,
    predecessor: str | None = None,
) -> dict[str, Any]:
    seed = f"shadow|{epoch}|{agent_instance_id}|{role_package_ref}|{forum_version_ref}".encode()
    token = sha256_bytes(seed)
    event = {
        "schema": "reg-core/primary-singleton-lease/v1",
        "lease_event_id": f"primary-lease-shadow-{epoch}-claim",
        "lease_epoch": epoch,
        "event": "CLAIM",
        "agent_instance_id": agent_instance_id,
        "role_package_ref": role_package_ref,
        "forum_version_ref": forum_version_ref,
        "permission_envelope_ref": permission_envelope_ref,
        "observed_predecessor_lease_ref": predecessor,
        "fencing_token": token,
        "timestamp_utc": now_utc,
        "lease_until_utc": None,
        "state": "ACTIVE",
        "causal_parents": [predecessor] if predecessor else [],
        "integrity": {"shadow_only": True, "does_not_grant_live_authority": True},
    }
    write_json(forum_root / f"leases/{event['lease_event_id']}.json", event)
    return event


def verify_primary_fence(lease: dict[str, Any], agent_instance_id: str, token: str) -> bool:
    return (
        lease.get("state") == "ACTIVE"
        and lease.get("agent_instance_id") == agent_instance_id
        and lease.get("fencing_token") == token
    )


def lifecycle_receipt(
    forum_root: Path,
    receipt_id: str,
    agent_instance_id: str,
    role: str,
    forum_version_ref: str,
    action: str,
    desired: bool,
    capability_state: str,
    action_state: str,
    required_writes_verified: bool,
    session_terminal: bool,
    finalization_receipt_ref: str | None = None,
    primary_lease_ref: str | None = None,
    note: str | None = None,
) -> dict[str, Any]:
    r = {
        "schema": "reg-core/chat-lifecycle-receipt/v1",
        "receipt_id": receipt_id,
        "agent_instance_id": agent_instance_id,
        "role": role,
        "timestamp_utc": "2026-10-03T01:05:00Z",
        "forum_version_ref": forum_version_ref,
        "finalization_receipt_ref": finalization_receipt_ref,
        "action": action,
        "desired": desired,
        "capability_state": capability_state,
        "action_state": action_state,
        "required_writes_verified": required_writes_verified,
        "session_terminal": session_terminal,
        "primary_lease_ref": primary_lease_ref,
        "evidence_refs": ["host/HOST_CAPABILITY_REPORT.json"],
        "note": note,
        "integrity": {"shadow_only": True},
    }
    write_json(forum_root / f"receipts/lifecycle/{receipt_id}.json", r)
    return r


def finalize_work_unit(
    forum_root: Path,
    work_unit_id: str,
    agent_instance_id: str,
    bootstrap_receipt_ref: str,
    role_package_ref: str,
    forum_version_ref: str,
    permission_envelope_ref: str,
    now_utc: str,
    terminal_reason: str,
    payload: dict[str, Any],
    attempt: int = 1,
    required_write_failure: bool = False,
) -> dict[str, Any]:
    cutoff_digest = "sha256:" + sha256_bytes(canonical_json_bytes(payload))
    receipt_id = f"finalize-{work_unit_id}-a{attempt}-{cutoff_digest.split(':',1)[1][:12]}"
    existing = forum_root / f"receipts/finalization/{receipt_id}.json"
    if existing.exists():
        return read_json(existing)

    txn_root = forum_root / "transactions" / work_unit_id
    staging = txn_root / f"attempt-{attempt}.staging"
    committed = txn_root / f"attempt-{attempt}.committed"
    if committed.exists():
        # A committed transaction without receipt is recoverable; do not make contradictory state.
        raise RuntimeError(f"committed transaction exists without expected receipt: {committed}")
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True, exist_ok=True)

    evidence_refs: list[str] = []
    material_refs: list[str] = []
    recommendation_refs: list[str] = []
    artifact_refs: list[str] = []
    for kind, target in (
        ("evidence", evidence_refs),
        ("material_events", material_refs),
        ("recommendations", recommendation_refs),
        ("artifacts", artifact_refs),
    ):
        for i, item in enumerate(payload.get(kind, []), start=1):
            p = staging / f"{kind}-{i:03d}.json"
            write_json(p, item if isinstance(item, dict) else {"value": item})
            target.append(p.relative_to(forum_root).as_posix().replace(".staging/", ".committed/"))

    required_verified = not required_write_failure
    persistence_state = "VERIFIED" if required_verified else "FAILED"
    receipt = {
        "schema": "reg-core/finalization-receipt/v1",
        "receipt_id": receipt_id,
        "work_unit_id": work_unit_id,
        "attempt": attempt,
        "cutoff_digest": cutoff_digest,
        "agent_instance_id": agent_instance_id,
        "bootstrap_receipt_ref": bootstrap_receipt_ref,
        "role_package_ref": role_package_ref,
        "forum_version_ref": forum_version_ref,
        "permission_envelope_ref": permission_envelope_ref,
        "timestamp_utc": now_utc,
        "terminal_reason": terminal_reason,
        "evidence_refs": evidence_refs,
        "material_event_refs": material_refs,
        "recommendation_refs": recommendation_refs,
        "artifact_refs": artifact_refs,
        "evaluation_refs": [],
        "unresolved_blockers": ["synthetic required-write failure"] if required_write_failure else payload.get("unresolved_blockers", []),
        "next_owner_refs": payload.get("next_owner_refs", []),
        "persistence_state": persistence_state,
        "required_writes_verified": required_verified,
        "recovery_ref": f"recovery/{work_unit_id}.json" if required_write_failure else None,
        "integrity": {"shadow_only": True, "idempotency_key": f"{work_unit_id}:{attempt}:{cutoff_digest}"},
    }

    if required_verified:
        os.replace(staging, committed)
        write_json(existing, receipt)
    else:
        recovery = {
            "work_unit_id": work_unit_id,
            "attempt": attempt,
            "staging_path": staging.relative_to(forum_root).as_posix(),
            "reason": "required write verification failed",
            "cutoff_digest": cutoff_digest,
        }
        write_json(forum_root / f"recovery/{work_unit_id}.json", recovery)
        write_json(existing, receipt)
    return receipt


def recovery_sweep(forum_root: Path) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    txroot = forum_root / "transactions"
    if not txroot.exists():
        return findings
    for p in sorted(txroot.rglob("*.staging")):
        rel = p.relative_to(forum_root).as_posix()
        findings.append({"path": rel, "state": "ABANDONED_STAGING", "action": "REQUIRES_REVIEW_OR_RETRY"})
    return findings


def mirror_status(expected_digest: str | None, remote_digest: str | None, lineage_conflict: bool = False) -> str:
    if lineage_conflict:
        return "CONFLICT"
    if not remote_digest:
        return "UNVERIFIED"
    if expected_digest == remote_digest:
        return "FRESH"
    return "STALE"


def merkleish_root(entries: list[tuple[str, str]]) -> str:
    material = "\n".join(f"{digest}  {path}" for path, digest in sorted(entries)).encode("utf-8")
    return sha256_bytes(material)


def build_snapshot(forum_root: Path, snapshot_zip: Path, now_utc: str) -> dict[str, Any]:
    # Snapshot payload deliberately excludes previous snapshot outputs to avoid recursion.
    excludes = {"snapshot", "tests", "transactions", "recovery"}
    files: list[Path] = []
    for p in forum_root.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(forum_root)
        if rel.parts and rel.parts[0] in excludes:
            continue
        files.append(p)
    entries = [(p.relative_to(forum_root).as_posix(), sha256_file(p)) for p in files]
    root_digest = merkleish_root(entries)
    snapshot_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(snapshot_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(files):
            rel = Path("DuoOpen-AgentBus/shadow/reg3") / p.relative_to(forum_root)
            zf.write(p, rel.as_posix())
    included = []
    registry = read_json(forum_root / "role-registry/ROLE_PACKAGE_REGISTRY.json")
    for role in ROLE_ORDER:
        included.append(dict(registry["packages"][role]))
    bundle = {
        "schema": "reg-core/snapshot-export-bundle/v1",
        "snapshot_id": "snapshot-reg3-shadow-trial-001",
        "snapshot_generation": "SG-shadow-trial-001",
        "created_utc": now_utc,
        "forum_cutoff": "github:DuoOpen-AgentBus/messages@b7899bea781b0434044086ba1c1e906698dc349d",
        "forum_version_ref": read_json(forum_root / "forum/FORUM_VERSION.json")["version_id"],
        "role_package_registry_ref": "role-registry/ROLE_PACKAGE_REGISTRY.json",
        "role_package_set_id": registry["package_set_id"],
        "included_role_packages": included,
        "object_count": len(files),
        "parts": [{"path": snapshot_zip.name, "sha256": sha256_file(snapshot_zip), "bytes": snapshot_zip.stat().st_size}],
        "snapshot_root_sha256": root_digest,
        "states": ["CAPTURED", "HASH_VERIFIED", "SCHEMA_VALID", "GRAPH_VALID", "PRIVACY_VALIDATED", "BOOTSTRAP_TESTED", "RESTORE_TESTED"],
        "backup_receipt_ref": None,
        "integrity": {"root_method": "sha256(sorted sha256+relative-path pairs); snapshot outputs excluded", "shadow_only": True},
    }
    write_json(forum_root / "snapshot/SNAPSHOT_EXPORT_BUNDLE.json", bundle)
    return bundle


def restore_bootstrap_test(snapshot_zip: Path, role: str = "RESEARCH") -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="reg3-restore-") as td:
        root = Path(td)
        with zipfile.ZipFile(snapshot_zip) as zf:
            verify_zip_paths(zf)
            zf.extractall(root)
        forum_root = root / "DuoOpen-AgentBus/shadow/reg3"
        loaded = load_role(forum_root, role)
        return {
            "role": role,
            "package_id": loaded.package["role_manifest"]["package_id"],
            "package_sha256": loaded.package["sha256"],
            "result": "PASS",
        }


def resolve_primary_lease(events: list[dict[str, Any]]) -> dict[str, Any]:
    """Conservative shadow resolver.

    It refuses to invent a winner when two ACTIVE claims share the highest epoch.
    A production implementation still needs a durable compare-and-swap/fencing backend.
    """
    active = [e for e in events if e.get("state") == "ACTIVE" and e.get("event") in {"CLAIM", "RENEW"}]
    if not active:
        return {"state": "NONE", "winner": None, "conflicts": []}
    top_epoch = max(int(e.get("lease_epoch", 0)) for e in active)
    top = [e for e in active if int(e.get("lease_epoch", 0)) == top_epoch]
    identities = {(e.get("agent_instance_id"), e.get("fencing_token")) for e in top}
    if len(identities) != 1:
        return {"state": "CONFLICT", "winner": None, "conflicts": [e.get("lease_event_id") for e in top]}
    return {"state": "UNIQUE_ACTIVE", "winner": top[0], "conflicts": []}
