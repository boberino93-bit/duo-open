#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT_SAFE = HERE.parents[1]
FORUM = ROOT_SAFE / "DuoOpen-AgentBus/shadow/reg3"
BLUEPRINT = Path("/mnt/data/artifactory_ng_v3")
sys.path.insert(0, str(HERE))
from shadow_runtime import (  # noqa: E402
    ROLE_ORDER,
    bootstrap_agent,
    build_snapshot,
    lifecycle_receipt,
    make_primary_lease,
    mirror_status,
    read_json,
    restore_bootstrap_test,
    sha256_file,
    validate_schema,
    verify_primary_fence,
    verify_role_package,
    write_json,
    finalize_work_unit,
)

NOW = "2026-10-03T01:05:00Z"
LIVE_MAIN = "28842ae4d1c4f907257b24a73012bf5015702f81"
MESSAGES_TREE = "b7899bea781b0434044086ba1c1e906698dc349d"
DISCOVERY_V7_SHA = "8c03cf2fb97c27c4e2886e9d4bc5ff1e5051f5b7"

ROLE_SOURCE_NAMES = {
    "PRIMARY": "PRIMARY_AGENT_INSTALL_REG3_REFERENCE_V2.zip",
    "MANAGER_REVIEWER": "MANAGER_AGENT_INSTALL_REG3_REFERENCE_V2.zip",
    "RESEARCH": "RESEARCH_AGENT_INSTALL_REG3_REFERENCE_V2.zip",
}


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def copy_inputs() -> None:
    if FORUM.exists():
        shutil.rmtree(FORUM)
    for d in (
        "bootstrap", "forum", "role-registry", "role-packages", "schemas/v2", "schemas/v3",
        "profiles", "permissions", "receipts/bootstrap", "receipts/finalization", "receipts/lifecycle",
        "leases", "host", "evidence", "recommendations", "snapshot", "tests", "transactions", "recovery",
    ):
        (FORUM / d).mkdir(parents=True, exist_ok=True)
    for role, name in ROLE_SOURCE_NAMES.items():
        shutil.copy2(BLUEPRINT / "role_packages/reference" / name, FORUM / "role-packages" / name)
    needed_v2 = [
        "permission-envelope.schema.json", "recommendation-composite.schema.json", "domain-profile.schema.json"
    ]
    for name in needed_v2:
        shutil.copy2(BLUEPRINT / "schemas/v2" / name, FORUM / "schemas/v2" / name)
    for p in (BLUEPRINT / "schemas/v3").glob("*.json"):
        shutil.copy2(p, FORUM / "schemas/v3" / p.name)
    shutil.copy2(BLUEPRINT / "profiles/duo-open-software.synthetic.json", FORUM / "profiles/duo-open-software.synthetic.json")
    shutil.copy2(BLUEPRINT / "profiles/financial-goal-planning.synthetic.json", FORUM / "profiles/financial-goal-planning.synthetic.json")


def build_core_objects() -> None:
    package_ptrs = {}
    for role in ROLE_ORDER:
        path = FORUM / "role-packages" / ROLE_SOURCE_NAMES[role]
        verified = verify_role_package(path, expected_role=role)
        package_ptrs[role] = {
            "package_id": verified["role_manifest"]["package_id"],
            "version": verified["role_manifest"]["package_version"],
            "path": f"role-packages/{path.name}",
            "sha256": verified["sha256"],
            "bytes": path.stat().st_size,
        }

    registry = {
        "schema": "reg-core/role-package-registry/v1",
        "registry_id": "registry-reg3-shadow-trial-001",
        "registry_version": "1.1.0-shadow-trial",
        "package_set_id": "rps-reg3-shadow-trial-001",
        "created_utc": NOW,
        "status": "REFERENCE_ONLY",
        "forum_version_ref": "forum-reg3-shadow-trial-001",
        "finalization_contract_version": "1.1.0-reference",
        "primary_promotion_ref": None,
        "packages": package_ptrs,
        "predecessor_registry_ref": None,
        "rollback_registry_ref": None,
        "integrity": {"shadow_only": True, "exactly_three_roles": True},
        "extensions": {"not_live_authority": True, "source_blueprint": "REG/3 V3 uploaded package"},
    }
    registry_path = FORUM / "role-registry/ROLE_PACKAGE_REGISTRY.json"
    write_json(registry_path, registry)

    forum_version = {
        "schema": "reg-core/forum-version/v2",
        "version_id": "forum-reg3-shadow-trial-001",
        "forum_epoch": "FE-shadow-trial-001",
        "authority_protocol_version": "candidate-reg3-shadow",
        "message_schema_version": "duoopen-agentbus/v1+reg3-shadow",
        "permission_model_version": "reg-core/permission-envelope/v1",
        "domain_profile_ref": "profiles/duo-open-software.synthetic.json",
        "promotion_policy_version": "primary-only-shadow-no-live-promotion",
        "primary_promotion_seq": 0,
        "role_package_set_id": registry["package_set_id"],
        "role_package_registry_ref": "role-registry/ROLE_PACKAGE_REGISTRY.json",
        "finalization_contract_version": "1.1.0-reference",
        "bootstrap_locator_generation": "locator-shadow-trial-001",
        "source_revisions": [{"repo": "boberino93-bit/duo-open", "branch": "main", "commit": LIVE_MAIN}],
        "snapshot_generation": None,
        "snapshot_root_sha256": None,
        "predecessor_version_id": None,
        "created_utc": NOW,
        "extensions": {"shadow_only": True, "live_messages_tree_sha": MESSAGES_TREE},
    }
    write_json(FORUM / "forum/FORUM_VERSION.json", forum_version)

    locator = {
        "schema": "reg-core/bootstrap-locator/v1",
        "locator_generation": "locator-shadow-trial-001",
        "updated_utc": NOW,
        "role_package_registry_ref": "role-registry/ROLE_PACKAGE_REGISTRY.json",
        "role_package_registry_sha256": sha256_file(registry_path),
        "forum_version_ref": forum_version["version_id"],
        "snapshot_hint": "snapshot/SNAPSHOT_EXPORT_BUNDLE.json",
        "note": "Shadow-only stable locator. Convenience pointer, not authority or credential grant.",
    }
    write_json(FORUM / "bootstrap/BOOTSTRAP_LOCATOR.json", locator)


def write_live_drift() -> None:
    report = {
        "schema": "duoopen-artifactory-ng/live-drift-report/v1",
        "generated_utc": NOW,
        "scope": "read-only comparison of uploaded REG/3 V3 blueprint against GitHub mirror on main",
        "limitations": [
            "GitHub mirror observations do not prove the current Library-backed forum lacks files that are absent from GitHub.",
            "No live AgentBus, Library, ChatGPT UI, database, or GitHub mutation was performed.",
        ],
        "observed_live": {
            "repo": "boberino93-bit/duo-open",
            "main_sha": LIVE_MAIN,
            "duoopen_agentbus_root_entries": ["messages"],
            "messages_tree_sha": MESSAGES_TREE,
            "discovery_v7_blob_sha": DISCOVERY_V7_SHA,
            "discovery_v7_scope": "/DuoOpen-AgentBus/ only",
            "discovery_v7_bootstrap_refs_are_under_duoopen_agentbus": True,
            "first_message_requires": ["PROTOCOL.md", "REGISTRY.md"],
            "github_mirror_has_protocol_and_registry_under_duoopen_agentbus": False,
            "agentbus_import_is_separate_root": True,
        },
        "drift": [
            {
                "id": "D1",
                "severity": "P0",
                "finding": "The GitHub mirror's DuoOpen-AgentBus root currently exposes only messages/, while discovery-v7 declares its scope as /DuoOpen-AgentBus/ only and references bootstrap/control files beneath that namespace.",
                "impact": "A clean restore from the mirrored forum namespace is not bootstrap-closed.",
                "disposition": "ADOPT_REG3_BOOTSTRAP_CLOSURE",
            },
            {
                "id": "D2",
                "severity": "P0",
                "finding": "No forum-resident RolePackageRegistry, stable BootstrapLocator, or exactly-three canonical role ZIP set is visible in the GitHub-mirrored DuoOpen-AgentBus root.",
                "impact": "A new agent cannot deterministically reconstruct Primary/Manager/Research behavior from locator+role using the mirror alone.",
                "disposition": "SHADOW_PROTOTYPE_NOW",
            },
            {
                "id": "D3",
                "severity": "P0",
                "finding": "The earliest mirrored board message instructs agents to read PROTOCOL.md and REGISTRY.md, but those files are not present in the mirrored DuoOpen-AgentBus directory.",
                "impact": "Historical board instructions have unresolved dependencies in the Git mirror.",
                "disposition": "INCLUDE_DEPENDENCIES_IN_COMPLETE_SNAPSHOT",
            },
            {
                "id": "D4",
                "severity": "P1",
                "finding": "The messages subtree remains a strong immutable corpus with tree SHA b7899bea781b0434044086ba1c1e906698dc349d even as repository main has advanced.",
                "impact": "Message preservation is working, but message-only backup is not sufficient for full agent bootstrap/recovery.",
                "disposition": "PRESERVE_MESSAGES_AND_EXTEND_SNAPSHOT",
            },
            {
                "id": "D5",
                "severity": "P1",
                "finding": "AGENTBUS_IMPORT contains discovery/bootstrap/user-model material under a separate root rather than the /DuoOpen-AgentBus/ authority namespace declared by discovery-v7.",
                "impact": "Restore currently depends on cross-root knowledge rather than one stable bootstrap locator.",
                "disposition": "MIGRATE_BY_SHADOW_ALIAS_THEN_PRIMARY_PROMOTION",
            },
        ],
    }
    write_json(FORUM / "evidence/LIVE_DRIFT_REPORT.json", report)
    md = "# REG/3 V3 live-drift report — shadow analysis\n\n"
    md += f"Observed GitHub `main`: `{LIVE_MAIN}`.\n\n"
    md += "This is a read-only GitHub-mirror comparison. Absence from GitHub is **not** treated as proof that the Library-backed forum lacks the same object.\n\n"
    for d in report["drift"]:
        md += f"## {d['id']} — {d['severity']}\n\n{d['finding']}\n\n**Impact:** {d['impact']}\n\n**Disposition:** `{d['disposition']}`\n\n"
    (FORUM / "evidence/LIVE_DRIFT_REPORT.md").write_text(md, encoding="utf-8")


def write_requirement_dispositions() -> None:
    dispositions = []
    for n in range(14, 47):
        status = "ADOPT"
        phase = "SHADOW_NOW"
        reason = "Required for deterministic bootstrap, authority fencing, persistence, restore, or truthful lifecycle behavior."
        if n in (18, 31):
            status = "ADOPT"
            phase = "SHADOW_WITH_GUARDS"
            reason = "Useful recovery/portability feature, but must remain hash-checked and non-authority-expanding."
        elif n in (33, 34, 35, 36):
            status = "ADOPT"
            phase = "ARCHITECTURE_NOW_LIVE_LATER"
            reason = "Domain-neutrality and export boundaries belong in the core design; live domain execution remains separately authorized."
        elif n in (39, 40, 43, 44, 45):
            status = "ADOPT"
            phase = "CAPABILITY_ADAPTIVE"
            reason = "Desired chat lifecycle semantics are valid, but unsupported host actions must remain explicit/manual rather than simulated."
        dispositions.append({"requirement": f"R{n}", "disposition": status, "phase": phase, "reason": reason})
    write_json(FORUM / "evidence/REQUIREMENT_DISPOSITIONS_R14_R46.json", {
        "schema": "duoopen-artifactory-ng/requirement-dispositions/v1",
        "generated_utc": NOW,
        "source": "uploaded REG/3 V3 05_REQUIREMENTS.md",
        "items": dispositions,
        "live_activation_authorized": False,
    })


def write_host_capabilities() -> None:
    report = {
        "schema": "duoopen-artifactory-ng/host-capability-report/v1",
        "generated_utc": NOW,
        "host": "current ChatGPT project session + local sandbox + connected GitHub read API",
        "capabilities": {
            "primary_chat_persistent": {"state": "UNKNOWN", "note": "Current chat exists, but durable singleton control cannot be proven by this shadow run."},
            "exact_pre_prompt_injection": {"state": "UNSUPPORTED", "note": "Role ZIP contents can be loaded/validated by tools, but this trial cannot rewrite the host system prompt before a spawned agent message."},
            "archive_hook_supported": {"state": "UNSUPPORTED", "note": "No verified self-archive action is exposed to this runtime."},
            "pin_self_supported": {"state": "UNSUPPORTED", "note": "No verified self-pin action is exposed to this runtime."},
            "session_end_hook_supported": {"state": "UNSUPPORTED", "note": "No host callback is exposed for guaranteed chat-end finalization."},
            "task_suppression_supported": {"state": "PARTIAL", "note": "The local finalization FSM can suppress its own new shadow transactions; host-wide agent task suppression is not proven."},
            "remote_commit_supported": {"state": "UNVERIFIED", "note": "This work intentionally performs no GitHub mutation under the blueprint non-mutation boundary."},
            "state_restore_supported": {"state": "PARTIAL", "note": "File-level clean restore/bootstrap is tested; host-chat identity restoration is not available."},
            "local_code_execution": {"state": "SUPPORTED", "note": "Used to build and validate this shadow trial."},
            "github_read": {"state": "SUPPORTED", "note": "Used for read-only live drift evidence."},
        },
        "overclaim_rule": "Only SUPPORTED capabilities may be treated as available; UNKNOWN/UNVERIFIED/PARTIAL are not equivalent to support.",
    }
    write_json(FORUM / "host/HOST_CAPABILITY_REPORT.json", report)


def bootstrap_all() -> tuple[dict, dict, dict]:
    caps = {
        "READ_EVIDENCE", "WRITE_EVIDENCE", "WRITE_RECOMMENDATION", "REVIEW_RECOMMENDATION", "RUN_SANDBOX_TEST"
    }
    receipts = {}
    perms = {}
    for role, instance in (
        ("PRIMARY", "primary-shadow-001"),
        ("MANAGER_REVIEWER", "manager-shadow-001"),
        ("RESEARCH", "research-shadow-001"),
    ):
        receipt, perm = bootstrap_agent(FORUM, role, instance, caps, NOW)
        receipts[role] = receipt
        perms[role] = perm
    primary = receipts["PRIMARY"]
    lease = make_primary_lease(
        FORUM,
        primary["agent_instance_id"],
        primary["permission_envelope_ref"],
        primary["package_id"],
        primary["forum_version_ref"],
        1,
        NOW,
    )
    lifecycle_receipt(
        FORUM,
        "lifecycle-primary-pin-shadow-001",
        primary["agent_instance_id"],
        "PRIMARY",
        primary["forum_version_ref"],
        "PIN_SELF",
        True,
        "UNSUPPORTED",
        "MANUAL_ACTION_REQUIRED",
        True,
        False,
        primary_lease_ref=lease["lease_event_id"],
        note="Pin desired by role policy, but host self-pin capability is unverified/unsupported in this runtime.",
    )
    assert verify_primary_fence(lease, primary["agent_instance_id"], lease["fencing_token"])
    assert not verify_primary_fence(lease, "stale-primary-shadow-000", lease["fencing_token"])
    return receipts, perms, lease


def write_recommendation_composite() -> None:
    event_ids = [
        "rec-shadow-bootstrap-closure-001",
        "rec-shadow-finalization-fsm-001",
        "rec-shadow-git-mirror-staleness-001",
        "rec-shadow-host-lifecycle-adapter-001",
    ]
    member_root = hashlib.sha256("\n".join(event_ids).encode()).hexdigest()
    composite = {
        "schema": "reg-core/recommendation-composite/v1",
        "composite_id": "rc-artifactory-ng-v3-shadow-001",
        "project": "duo-open",
        "target_component": "AGENTBUS_BOOTSTRAP_PERSISTENCE_ARCHITECTURE",
        "created_utc": NOW,
        "forum_version_ref": "forum-reg3-shadow-trial-001",
        "member_event_ids": event_ids,
        "member_root_sha256": member_root,
        "derived_state": "READY_FOR_PRIMARY",
        "latest_primary_disposition_ref": None,
        "extensions": {
            "recommendation_only": True,
            "live_activation_authorized": False,
            "summary": "Adopt REG/3 bootstrap closure and finalization semantics only after shadow acceptance gates pass and Primary separately promotes live changes.",
        },
    }
    write_json(FORUM / "recommendations/RECOMMENDATION_COMPOSITE.json", composite)


def exercise_finalization(receipts: dict, perms: dict) -> list[dict]:
    results = []
    for role, reason, fail in (
        ("RESEARCH", "SUCCESS", False),
        ("MANAGER_REVIEWER", "FAILED", False),
        ("PRIMARY", "PERMISSION_DENIED", False),
    ):
        r = receipts[role]
        payload = {
            "evidence": [{"kind": "synthetic", "role": role, "result": reason}],
            "material_events": [{"kind": "shadow-finalization", "terminal_reason": reason}],
            "recommendations": ([{"kind": "RECOMMENDATION_ONLY", "target": "communication/process/package"}] if role != "PRIMARY" else []),
            "artifacts": [{"ref": "shadow-trial"}],
            "next_owner_refs": (["MANAGER_REVIEWER"] if role == "RESEARCH" else (["PRIMARY"] if role == "MANAGER_REVIEWER" else [])),
        }
        fr = finalize_work_unit(
            FORUM,
            f"wu-{role.lower()}-shadow-001",
            r["agent_instance_id"],
            f"receipts/bootstrap/{r['receipt_id']}.json",
            r["package_id"],
            r["forum_version_ref"],
            r["permission_envelope_ref"],
            NOW,
            reason,
            payload,
        )
        # Idempotency proof: exact rerun returns the same receipt id/content.
        fr2 = finalize_work_unit(
            FORUM,
            f"wu-{role.lower()}-shadow-001",
            r["agent_instance_id"],
            f"receipts/bootstrap/{r['receipt_id']}.json",
            r["package_id"],
            r["forum_version_ref"],
            r["permission_envelope_ref"],
            NOW,
            reason,
            payload,
        )
        assert fr == fr2
        results.append(fr)
    # Explicit required-write failure path; must never qualify for archive.
    rr = receipts["RESEARCH"]
    failed = finalize_work_unit(
        FORUM,
        "wu-research-shadow-write-failure-001",
        rr["agent_instance_id"],
        f"receipts/bootstrap/{rr['receipt_id']}.json",
        rr["package_id"],
        rr["forum_version_ref"],
        rr["permission_envelope_ref"],
        NOW,
        "FAILED",
        {"evidence": [{"kind": "synthetic-write-failure"}]},
        required_write_failure=True,
    )
    lifecycle_receipt(
        FORUM,
        "lifecycle-research-archive-blocked-001",
        rr["agent_instance_id"],
        "RESEARCH",
        rr["forum_version_ref"],
        "ARCHIVE_SELF",
        True,
        "UNSUPPORTED",
        "NOT_REQUESTED",
        failed["required_writes_verified"],
        True,
        finalization_receipt_ref=f"receipts/finalization/{failed['receipt_id']}.json",
        note="Archive is deliberately not requested because required writes were not verified.",
    )
    results.append(failed)
    return results


def validate_objects() -> list[str]:
    passes = []
    schema_map = {
        "bootstrap/BOOTSTRAP_LOCATOR.json": "schemas/v3/bootstrap-locator.schema.json",
        "role-registry/ROLE_PACKAGE_REGISTRY.json": "schemas/v3/role-package-registry.schema.json",
        "forum/FORUM_VERSION.json": "schemas/v3/forum-version.schema.json",
        "recommendations/RECOMMENDATION_COMPOSITE.json": "schemas/v2/recommendation-composite.schema.json",
    }
    for rel, schema in schema_map.items():
        validate_schema(read_json(FORUM / rel), FORUM / schema)
        passes.append(f"schema:{rel}")
    for p in sorted((FORUM / "permissions").glob("*.json")):
        validate_schema(read_json(p), FORUM / "schemas/v2/permission-envelope.schema.json")
        passes.append(f"schema:{p.relative_to(FORUM)}")
    for p in sorted((FORUM / "receipts/bootstrap").glob("*.json")):
        validate_schema(read_json(p), FORUM / "schemas/v3/bootstrap-receipt.schema.json")
        passes.append(f"schema:{p.relative_to(FORUM)}")
    for p in sorted((FORUM / "receipts/finalization").glob("*.json")):
        validate_schema(read_json(p), FORUM / "schemas/v3/finalization-receipt.schema.json")
        passes.append(f"schema:{p.relative_to(FORUM)}")
    for p in sorted((FORUM / "receipts/lifecycle").glob("*.json")):
        validate_schema(read_json(p), FORUM / "schemas/v3/chat-lifecycle-receipt.schema.json")
        passes.append(f"schema:{p.relative_to(FORUM)}")
    for p in sorted((FORUM / "leases").glob("*.json")):
        validate_schema(read_json(p), FORUM / "schemas/v3/primary-singleton-lease.schema.json")
        passes.append(f"schema:{p.relative_to(FORUM)}")
    return passes


def write_readme() -> None:
    readme = f"""# Artifactory NG REG/3 — Shadow Trial SP1\n\nThis subtree is **non-authoritative and non-mutating by design**. It is a working reference implementation of the uploaded REG/3 V3 bootstrap/finalization architecture against the observed GitHub mirror at `{LIVE_MAIN}`.\n\n## What it proves\n\n- stable locator -> exact RolePackageRegistry hash -> exact one-of-three role ZIP lookup;\n- ZIP path escape checks, outer digest checks, internal manifest checks, and role identity checks;\n- dynamic role loading from only `locator + externally stated role`;\n- immutable effective PermissionEnvelope generation that never expands authority from package possession;\n- BootstrapReceipt generation before substantive work;\n- fenced shadow PrimarySingletonLease semantics;\n- idempotent success/failure/permission-denied finalization;\n- required-write failure blocks terminal archive semantics;\n- composite recommendation remains recommendation-only;\n- complete shadow snapshot contains all three role ZIPs and bootstrap dependencies;\n- clean restore/bootstrap from the snapshot without hidden chat context;\n- explicit host capability degradation rather than invented pin/archive success;\n- mirror staleness classification and startup recovery primitives.\n\n## What it does NOT do\n\nIt does not alter the live AgentBus, Library, ChatGPT UI, GitHub repository, production app, permissions, or credentials. `REFERENCE_ONLY` remains intact.\n\n## Validate\n\n```bash\npython tools/artifactory_ng_shadow/validate_shadow_trial.py .\n```\n\nSee `DuoOpen-AgentBus/shadow/reg3/tests/SHADOW_TEST_REPORT.json` and `evidence/LIVE_DRIFT_REPORT.md`.\n"""
    (ROOT_SAFE / "README_ARTIFACTORY_NG_SHADOW_TRIAL.md").write_text(readme, encoding="utf-8")


def main() -> None:
    copy_inputs()
    build_core_objects()
    write_live_drift()
    write_requirement_dispositions()
    write_host_capabilities()
    write_recommendation_composite()
    receipts, perms, lease = bootstrap_all()
    finalization = exercise_finalization(receipts, perms)
    schema_passes = validate_objects()

    # Mirror comparator proof.
    mirror_cases = {
        "fresh": mirror_status("abc", "abc"),
        "stale": mirror_status("abc", "def"),
        "unverified": mirror_status("abc", None),
        "conflict": mirror_status("abc", "abc", lineage_conflict=True),
    }
    assert mirror_cases == {"fresh": "FRESH", "stale": "STALE", "unverified": "UNVERIFIED", "conflict": "CONFLICT"}

    snapshot_zip = FORUM / "snapshot/SHADOW_FORUM_SNAPSHOT.zip"
    bundle = build_snapshot(FORUM, snapshot_zip, NOW)
    validate_schema(bundle, FORUM / "schemas/v3/snapshot-export-bundle.schema.json")
    restore_results = [restore_bootstrap_test(snapshot_zip, r) for r in ROLE_ORDER]

    test_report = {
        "schema": "duoopen-artifactory-ng/shadow-test-report/v1",
        "generated_utc": NOW,
        "result": "PASS",
        "live_mutation_performed": False,
        "checks": {
            "blueprint_validator": "PASS_EXTERNALLY_RUN_BEFORE_TRIAL",
            "three_role_packages_present": len(ROLE_ORDER) == 3,
            "dynamic_load_all_roles": all(x["result"] == "PASS" for x in restore_results),
            "bootstrap_receipts": len(receipts),
            "permission_envelopes": len(perms),
            "primary_fence": "PASS",
            "finalization_receipts": len(finalization),
            "finalization_idempotency": "PASS",
            "required_write_failure_blocks_archive": "PASS",
            "schema_validations": len(schema_passes) + 1,
            "snapshot_states": bundle["states"],
            "restore_bootstrap_results": restore_results,
            "mirror_status_cases": mirror_cases,
            "path_escape_defense": "PASS",
            "host_lifecycle_truthfulness": "PASS",
        },
        "known_unproven": [
            "Live Library/forum write adapter",
            "GitHub write/push adapter",
            "ChatGPT self-pin/self-archive adapter",
            "host-native session-end callback",
            "live Primary promotion/activation",
        ],
    }
    write_json(FORUM / "tests/SHADOW_TEST_REPORT.json", test_report)
    write_readme()

    # Root-level checksum manifest for the whole root-safe trial, excluding itself.
    entries = []
    for p in sorted(ROOT_SAFE.rglob("*")):
        if p.is_file() and p.name != "SHA256SUMS.txt":
            entries.append(f"{sha256_file(p)}  {p.relative_to(ROOT_SAFE).as_posix()}")
    (ROOT_SAFE / "SHA256SUMS.txt").write_text("\n".join(entries) + "\n", encoding="utf-8")
    print(json.dumps({
        "result": "PASS",
        "forum_root": str(FORUM),
        "snapshot": str(snapshot_zip),
        "snapshot_sha256": sha256_file(snapshot_zip),
        "schema_checks": len(schema_passes) + 1,
        "restore_tests": restore_results,
    }, indent=2))


if __name__ == "__main__":
    main()
