PURPOSE
R&D proposal for Shizuku/UserService privilege-loss and daemon-restart recovery in Duo Open on Galaxy Z Fold7.

BASELINE_SHA
45bb0d326899c0e08415928224cfea0ff58d2d4e

FINAL_CHECKED_MAIN_SHA
45bb0d326899c0e08415928224cfea0ff58d2d4e

FILES_INCLUDED
DUO_OPEN_SHIZUKU_RECOVERY_GEN2_RND_HANDOFF.txt
RECOVERY_DESIGN.txt
duoopen_shizuku_recovery_model.py
duoopen_shizuku_recovery_model_results.txt
BASELINE-SHA.txt
FINAL-MAIN-SHA.txt
SHA256SUMS.txt

HOW_TO_REPRODUCE_TESTS
python duoopen_shizuku_recovery_model.py
Expected TOTAL=9/9.

INTEGRATION_INTENT
Manual architectural integration by primary only. No repository writes are authorized by this package.

KNOWN_RISKS
Fold7 hardware-state persistence after abrupt Shizuku/UserService death is not device-confirmed. Recovery must never use raw physical OFF and must freshly validate topology before logical reset.

PRODUCTION_STATUS=R&D ONLY
