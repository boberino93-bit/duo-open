from dataclasses import dataclass
from enum import Enum, auto

class State(Enum):
    OPEN_INNER=auto(); CLOSING_INTENT=auto(); COVER_PREWARMING=auto(); COVER_READY_HIDDEN=auto(); COVER_VISUAL=auto(); INNER_HANDOFF=auto(); NATIVE_COVER=auto(); PRIVILEGE_RECOVERY=auto()

@dataclass
class CurrentApp:
    state: State
    privilege_ready: bool = True
    readiness_ready: bool = True
    mirror_requested: bool = False

    @property
    def visual_mirror_active(self):
        # Mirrors current Fold7ContinuityCoordinator getter.
        return self.mirror_requested and self.state == State.COVER_VISUAL

    def on_privileged_unavailable(self):
        # Mirrors current coordinator semantics relevant to this model:
        # invalidate readiness/session bookkeeping, but do not demote controller
        # state or clear mirrorRequested.
        self.privilege_ready = False
        self.readiness_ready = False

    def on_privileged_ready(self):
        self.privilege_ready = True
        # COVER_READY_HIDDEN / COVER_VISUAL are not forced through prewarm again.

    def hinge(self, angle: float):
        if self.state == State.COVER_READY_HIDDEN and angle <= 135:
            self.state = State.COVER_VISUAL
            self.mirror_requested = True

@dataclass
class CurrentShell:
    lease_state: str = "IDLE"
    physical_cover_normal: bool = False
    logical_cover_forced_on: bool = False
    live_mirror: bool = False

    def prewarm(self):
        self.lease_state = "HELD"
        self.physical_cover_normal = True
        self.logical_cover_forced_on = True

    def destroy(self):
        # Current SHIZUKU_DESTROY explicitly stops live mirror, then exits.
        self.live_mirror = False
        # No cover lease release/reconcile is performed before state is lost.
        return {
            "physical_cover_normal": self.physical_cover_normal,
            "logical_cover_forced_on": self.logical_cover_forced_on,
        }

    @classmethod
    def restart(cls, hardware):
        # New DuoShellService constructs a fresh in-memory Fold7CoverPanelLease.
        x = cls()
        x.physical_cover_normal = hardware["physical_cover_normal"]
        x.logical_cover_forced_on = hardware["logical_cover_forced_on"]
        return x

    def reconcile(self):
        # Current new daemon begins IDLE; Fold7CoverPanelLease.onTopology(IDLE)
        # emits no action, so orphan external mutation is not represented.
        return []

@dataclass
class Gen2App:
    state: State
    privilege_ready: bool = True
    readiness_ready: bool = True
    mirror_requested: bool = False
    privilege_epoch: int = 1

    @property
    def visual_mirror_active(self):
        return (self.privilege_ready and self.readiness_ready and
                self.mirror_requested and self.state == State.COVER_VISUAL)

    def on_privileged_unavailable(self):
        self.privilege_epoch += 1
        self.privilege_ready = False
        self.readiness_ready = False
        self.mirror_requested = False
        self.state = State.PRIVILEGE_RECOVERY

    def on_privileged_ready(self):
        self.privilege_ready = True
        # Remain fenced until shell recovery and fresh readiness succeed.

    def recovery_complete(self):
        self.readiness_ready = False
        self.state = State.CLOSING_INTENT

    def fresh_prewarm_ready(self):
        assert self.privilege_ready
        self.readiness_ready = True
        self.state = State.COVER_READY_HIDDEN

    def hinge(self, angle: float):
        if (self.state == State.COVER_READY_HIDDEN and self.privilege_ready and
                self.readiness_ready and angle <= 135):
            self.state = State.COVER_VISUAL
            self.mirror_requested = True

@dataclass
class Gen2Shell:
    lease_state: str = "IDLE"
    physical_cover_normal: bool = False
    logical_cover_forced_on: bool = False
    recovery_required: bool = False

    def prewarm(self):
        if self.recovery_required or self.lease_state == "UNKNOWN_RECOVERY":
            return False
        self.lease_state = "HELD"
        self.physical_cover_normal = True
        self.logical_cover_forced_on = True
        return True

    def graceful_destroy(self, safe_secondary_cover_route: bool, native_cover: bool=False):
        if native_cover:
            self.lease_state = "IDLE"
            return True
        if self.lease_state == "HELD" and safe_secondary_cover_route:
            # Framework logical reset; never raw physical OFF.
            self.logical_cover_forced_on = False
            self.lease_state = "IDLE"
            return True
        return self.lease_state == "IDLE"

    @classmethod
    def cold_start(cls, hardware):
        x = cls()
        x.physical_cover_normal = hardware["physical_cover_normal"]
        x.logical_cover_forced_on = hardware["logical_cover_forced_on"]
        x.lease_state = "UNKNOWN_RECOVERY"
        x.recovery_required = True
        return x

    def recover(self, safe_secondary_cover_route: bool, native_cover: bool=False):
        if native_cover:
            self.lease_state = "IDLE"; self.recovery_required = False
            return True
        if safe_secondary_cover_route:
            self.logical_cover_forced_on = False
            self.lease_state = "IDLE"; self.recovery_required = False
            return True
        return False


def run():
    results=[]
    def check(name, cond):
        results.append((name, bool(cond)))

    # Current failure 1: ready-hidden survives privilege loss and can promote visual.
    a=CurrentApp(State.COVER_READY_HIDDEN)
    a.on_privileged_unavailable(); a.on_privileged_ready(); a.hinge(130)
    check("CURRENT exposes visual without re-proved readiness", a.state == State.COVER_VISUAL and not a.readiness_ready)

    # Current failure 2: visualMirrorActive does not imply live privilege.
    a=CurrentApp(State.COVER_VISUAL, mirror_requested=True)
    a.on_privileged_unavailable()
    check("CURRENT visualMirrorActive remains true after privilege loss", a.visual_mirror_active and not a.privilege_ready)

    # Current failure 3: daemon destroy loses cover lease memory but not modeled hardware mutation.
    s=CurrentShell(); s.prewarm(); hw=s.destroy(); s2=CurrentShell.restart(hw)
    check("CURRENT restart orphan: new lease IDLE while cover mutation persists", s2.lease_state=="IDLE" and s2.logical_cover_forced_on)

    # Current failure 4: ordinary reconcile from IDLE cannot represent/release the orphan.
    check("CURRENT new-daemon reconcile emits no recovery action", s2.reconcile()==[] and s2.logical_cover_forced_on)

    # Proposed invariant 1: privilege loss revokes visual authority immediately.
    g=Gen2App(State.COVER_VISUAL, mirror_requested=True)
    g.on_privileged_unavailable()
    check("GEN2 privilege loss revokes visual authority", not g.visual_mirror_active and g.state==State.PRIVILEGE_RECOVERY)

    # Proposed invariant 2: reconnect alone cannot jump back to visible.
    g.on_privileged_ready(); g.hinge(120)
    check("GEN2 reconnect is fenced until recovery/readiness", g.state==State.PRIVILEGE_RECOVERY and not g.mirror_requested)

    # Proposed invariant 3: fresh prewarm/readiness is required before visible demand.
    g.recovery_complete(); g.fresh_prewarm_ready(); g.hinge(130)
    check("GEN2 fresh readiness permits visual only after recovery", g.visual_mirror_active)

    # Proposed invariant 4: cold-start shell blocks prewarm until UNKNOWN_RECOVERY resolves.
    orphan={"physical_cover_normal":True,"logical_cover_forced_on":True}
    gs=Gen2Shell.cold_start(orphan)
    blocked = not gs.prewarm()
    recovered = gs.recover(safe_secondary_cover_route=True)
    check("GEN2 shell recovery fence blocks mutation then normalizes safe route", blocked and recovered and gs.lease_state=="IDLE" and not gs.logical_cover_forced_on)

    # Proposed invariant 5: graceful destroy tries logical ownership reset, no raw OFF.
    gs=Gen2Shell(); gs.prewarm(); ok=gs.graceful_destroy(safe_secondary_cover_route=True)
    check("GEN2 graceful destroy drains cover lease with logical reset", ok and gs.lease_state=="IDLE" and not gs.logical_cover_forced_on)

    for name, ok in results:
        print(("PASS" if ok else "FAIL")+"\t"+name)
    print(f"TOTAL={sum(ok for _,ok in results)}/{len(results)}")
    assert all(ok for _,ok in results)

if __name__=='__main__':
    run()
