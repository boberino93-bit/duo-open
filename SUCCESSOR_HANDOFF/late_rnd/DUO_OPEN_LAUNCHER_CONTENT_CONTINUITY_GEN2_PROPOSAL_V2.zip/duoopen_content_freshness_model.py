from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
import random

# MODELED ONLY. This is deliberately not a production recommendation.
MODELED_VISIBLE_FRESHNESS_BUDGET_MS = 600
BASELINE_FRAME_MAX_AGE_MS = 10_000


class Purpose(Enum):
    PRIME = auto()
    VISUAL_REFRESH = auto()


class Path(Enum):
    FROZEN = auto()
    LIVE = auto()
    NATIVE = auto()
    WAIT_REFRESH = auto()


@dataclass(frozen=True)
class Cycle:
    service_epoch: int
    close_cycle_id: int


@dataclass(frozen=True)
class Frame:
    cycle: Cycle
    capture_sequence: int
    purpose: Purpose
    context_revision: int
    captured_ms: int
    width: int = 1968
    height: int = 2184


class Gen2Arbiter:
    """Pure source-arbitration model, not Android production code.

    Invariants:
    - a frozen frame is visible only for the active cycle;
    - it must match the current content-context revision;
    - it must satisfy a modeled freshness budget;
    - starting a newer refresh fences older completions;
    - if current pixels cannot be proven via a fresh snapshot, prefer live pixels;
    - if neither current frozen nor live is available, fall back to native rather
      than knowingly showing stale content.
    """

    def __init__(self, cycle: Cycle):
        self.cycle = cycle
        self.current_context_revision = 0
        self.next_capture_sequence = 0
        self.newest_started_sequence = 0
        self.latest: Frame | None = None

    def content_changed(self) -> None:
        self.current_context_revision += 1
        # Known-old pixels are no longer eligible for visible frozen output.
        if self.latest and self.latest.context_revision != self.current_context_revision:
            self.latest = None

    def begin_capture(self, purpose: Purpose) -> tuple[int, int]:
        self.next_capture_sequence += 1
        seq = self.next_capture_sequence
        self.newest_started_sequence = seq
        # Snapshot the content revision at request start. Completion is rejected if
        # the content changed before the pixels became authoritative.
        return seq, self.current_context_revision

    def complete_capture(
        self,
        sequence: int,
        purpose: Purpose,
        request_context_revision: int,
        captured_ms: int,
        cycle: Cycle | None = None,
    ) -> bool:
        cycle = cycle or self.cycle
        if cycle != self.cycle:
            return False
        if sequence != self.newest_started_sequence:
            return False
        if request_context_revision != self.current_context_revision:
            return False
        self.latest = Frame(
            cycle=cycle,
            capture_sequence=sequence,
            purpose=purpose,
            context_revision=request_context_revision,
            captured_ms=captured_ms,
        )
        return True

    def decide(self, now_ms: int, live_available: bool, refresh_in_flight: bool = False) -> Path:
        f = self.latest
        if f is not None:
            age = now_ms - f.captured_ms
            if (
                f.cycle == self.cycle
                and f.context_revision == self.current_context_revision
                and f.capture_sequence == self.newest_started_sequence
                and 0 <= age <= MODELED_VISIBLE_FRESHNESS_BUDGET_MS
            ):
                return Path.FROZEN
        if refresh_in_flight:
            return Path.WAIT_REFRESH
        if live_available:
            return Path.LIVE
        return Path.NATIVE


def baseline_decide(frame: Frame | None, active_cycle: Cycle, now_ms: int, live_available: bool) -> Path:
    """Behavioral reduction of current main's frozen-first eligibility.

    The current source checks exact cycle, geometry and max age, then prefers a
    frozen frame. It does not check content semantic identity/revision.
    """
    if frame is not None:
        age = now_ms - frame.captured_ms
        if (
            frame.cycle == active_cycle
            and frame.width == 1968
            and frame.height == 2184
            and 0 <= age <= BASELINE_FRAME_MAX_AGE_MS
        ):
            return Path.FROZEN
    return Path.LIVE if live_available else Path.NATIVE


def require(cond: bool, name: str) -> None:
    if not cond:
        raise AssertionError(name)


def unit_tests() -> list[str]:
    passed: list[str] = []

    def ok(name: str, cond: bool):
        require(cond, name)
        passed.append(name)

    c = Cycle(1, 1)

    # 1. Fresh prime can be used on a fast close with unchanged content.
    a = Gen2Arbiter(c)
    seq, rev = a.begin_capture(Purpose.PRIME)
    ok("fresh-prime-completes", a.complete_capture(seq, Purpose.PRIME, rev, 100))
    ok("fresh-prime-visible", a.decide(400, live_available=True) == Path.FROZEN)

    # 2. App switch after prime: current-main reduction still selects old frozen pixels.
    stale = Frame(c, 1, Purpose.PRIME, context_revision=0, captured_ms=100)
    ok("baseline-app-switch-still-frozen", baseline_decide(stale, c, 1000, True) == Path.FROZEN)
    a = Gen2Arbiter(c)
    seq, rev = a.begin_capture(Purpose.PRIME)
    a.complete_capture(seq, Purpose.PRIME, rev, 100)
    a.content_changed()
    ok("gen2-app-switch-refuses-old-frozen", a.decide(1000, True) == Path.LIVE)

    # 3. Launcher page change is the same content-freshness race.
    a = Gen2Arbiter(c)
    seq, rev = a.begin_capture(Purpose.PRIME)
    a.complete_capture(seq, Purpose.PRIME, rev, 120)
    a.content_changed()
    ok("gen2-launcher-page-change-refuses-old-frozen", a.decide(350, True) == Path.LIVE)

    # 4. A visible-demand refresh restores deterministic frozen output.
    a = Gen2Arbiter(c)
    seq, rev = a.begin_capture(Purpose.PRIME)
    a.complete_capture(seq, Purpose.PRIME, rev, 0)
    a.content_changed()
    seq2, rev2 = a.begin_capture(Purpose.VISUAL_REFRESH)
    ok("refresh-completes", a.complete_capture(seq2, Purpose.VISUAL_REFRESH, rev2, 900))
    ok("refresh-becomes-visible-frozen", a.decide(1000, True) == Path.FROZEN)

    # 5. If content changes while refresh is in flight, its completion is stale.
    a = Gen2Arbiter(c)
    seq, rev = a.begin_capture(Purpose.VISUAL_REFRESH)
    a.content_changed()
    ok("refresh-completion-rejected-after-context-change", not a.complete_capture(seq, Purpose.VISUAL_REFRESH, rev, 200))
    ok("stale-refresh-falls-back-live", a.decide(300, True) == Path.LIVE)

    # 6. If current frozen proof fails and live is unavailable, prefer native over known-stale pixels.
    a = Gen2Arbiter(c)
    seq, rev = a.begin_capture(Purpose.PRIME)
    a.complete_capture(seq, Purpose.PRIME, rev, 100)
    a.content_changed()
    ok("known-stale-no-live-falls-back-native", a.decide(300, False) == Path.NATIVE)

    # 7. Age alone fences an unchanged prime after the modeled budget.
    a = Gen2Arbiter(c)
    seq, rev = a.begin_capture(Purpose.PRIME)
    a.complete_capture(seq, Purpose.PRIME, rev, 0)
    ok("modeled-age-budget-fences-old-prime", a.decide(MODELED_VISIBLE_FRESHNESS_BUDGET_MS + 1, True) == Path.LIVE)

    # 8. Cross-cycle content never binds.
    a = Gen2Arbiter(c)
    seq, rev = a.begin_capture(Purpose.PRIME)
    other = Cycle(1, 2)
    ok("cross-cycle-completion-rejected", not a.complete_capture(seq, Purpose.PRIME, rev, 100, cycle=other))

    # 9. Newer started capture fences an older completion, even with same context.
    a = Gen2Arbiter(c)
    s1, r1 = a.begin_capture(Purpose.PRIME)
    s2, r2 = a.begin_capture(Purpose.VISUAL_REFRESH)
    ok("older-completion-rejected-after-newer-start", not a.complete_capture(s1, Purpose.PRIME, r1, 100))
    ok("newer-completion-accepted", a.complete_capture(s2, Purpose.VISUAL_REFRESH, r2, 120))

    # 10. Refresh-in-flight exposes explicit WAIT rather than accidentally resurrecting an old frame.
    a = Gen2Arbiter(c)
    seq, rev = a.begin_capture(Purpose.PRIME)
    a.complete_capture(seq, Purpose.PRIME, rev, 0)
    a.content_changed()
    a.begin_capture(Purpose.VISUAL_REFRESH)
    ok("refresh-in-flight-does-not-resurrect-stale", a.decide(500, True, refresh_in_flight=True) == Path.WAIT_REFRESH)

    return passed


def adversarial(seed: int = 0xD00F017, events: int = 100_000) -> dict[str, int]:
    rng = random.Random(seed)
    cycle = Cycle(7, 1)
    a = Gen2Arbiter(cycle)
    now = 0
    live = True
    request_meta: dict[int, tuple[Purpose, int, Cycle]] = {}
    counts = {"events": events, "content_changes": 0, "captures_started": 0, "captures_accepted": 0,
              "captures_rejected": 0, "frozen_decisions": 0, "live_decisions": 0, "native_decisions": 0}

    for _ in range(events):
        now += rng.randint(0, 18)
        op = rng.randrange(100)

        if op < 14:
            a.content_changed()
            counts["content_changes"] += 1
        elif op < 37:
            purpose = Purpose.PRIME if rng.random() < 0.45 else Purpose.VISUAL_REFRESH
            seq, rev = a.begin_capture(purpose)
            request_meta[seq] = (purpose, rev, a.cycle)
            counts["captures_started"] += 1
        elif op < 55 and request_meta:
            seq = rng.choice(list(request_meta))
            purpose, rev, req_cycle = request_meta.pop(seq)
            # Sometimes complete under a stale cycle to exercise cycle fencing.
            completion_cycle = req_cycle if rng.random() > 0.04 else Cycle(req_cycle.service_epoch, req_cycle.close_cycle_id + 1)
            accepted = a.complete_capture(seq, purpose, rev, now, cycle=completion_cycle)
            counts["captures_accepted" if accepted else "captures_rejected"] += 1
        elif op < 59:
            # New close-cycle/reversal boundary. Outstanding work is intentionally stale.
            cycle = Cycle(cycle.service_epoch, cycle.close_cycle_id + 1)
            a = Gen2Arbiter(cycle)
            request_meta.clear()
        elif op < 65:
            live = not live
        else:
            path = a.decide(now, live_available=live, refresh_in_flight=bool(request_meta))
            if path == Path.FROZEN:
                counts["frozen_decisions"] += 1
                f = a.latest
                require(f is not None, "frozen requires frame")
                require(f.cycle == a.cycle, "frozen current-cycle invariant")
                require(f.context_revision == a.current_context_revision, "frozen current-content invariant")
                age = now - f.captured_ms
                require(0 <= age <= MODELED_VISIBLE_FRESHNESS_BUDGET_MS, "frozen freshness invariant")
                require(f.capture_sequence == a.newest_started_sequence, "frozen newest-started invariant")
            elif path == Path.LIVE:
                counts["live_decisions"] += 1
            elif path == Path.NATIVE:
                counts["native_decisions"] += 1

    return counts


if __name__ == "__main__":
    tests = unit_tests()
    stats = adversarial()
    print(f"UNIT_TESTS_PASS={len(tests)}")
    for name in tests:
        print(f"PASS {name}")
    print("ADVERSARIAL_PASS=1")
    print(f"MODELED_VISIBLE_FRESHNESS_BUDGET_MS={MODELED_VISIBLE_FRESHNESS_BUDGET_MS} (MODELED ONLY, NOT PRODUCTION GUIDANCE)")
    for k, v in stats.items():
        print(f"{k}={v}")
