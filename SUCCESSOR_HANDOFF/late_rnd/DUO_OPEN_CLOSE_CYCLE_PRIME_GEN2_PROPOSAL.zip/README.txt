PURPOSE
R&D proposal for service-stable close-cycle continuity-prime ownership and newest-started capture fencing on Samsung Galaxy Z Fold7 Duo Open transitions.

BASELINE_SHA
45bb0d326899c0e08415928224cfea0ff58d2d4e

FINAL_CHECKED_MAIN_SHA
45bb0d326899c0e08415928224cfea0ff58d2d4e

FILES_INCLUDED
- Fold7ContinuityPrimeOwnerGen2.kt
- CloseCyclePrimeGen2Test.kt
- TEST_OUTPUT.txt
- DUO_OPEN_CLOSE_CYCLE_PRIME_GEN2_RND_HANDOFF.txt
- README.txt
- BASELINE-SHA.txt
- FINAL-MAIN-SHA.txt
- SHA256SUMS.txt

HOW_TO_REPRODUCE_TESTS
kotlinc Fold7ContinuityPrimeOwnerGen2.kt CloseCyclePrimeGen2Test.kt -include-runtime -d close-cycle-prime-gen2-tests.jar
java -jar close-cycle-prime-gen2-tests.jar
Expected: RESULT passed=14 failed=0 total=14

INTEGRATION_INTENT
Primary-only manual integration. Move prime authority out of mutable PanelEngine into a service-stable exact close-cycle owner; independently fence Fold7ContinuityFrameStore publication against the newest started capture attempt.

KNOWN_RISKS
Android integration, retry timing, bitmap lifecycle, Samsung remap timing, and Fold7 field behavior remain unvalidated. Parallel state-rd arbitration evidence was reconciled before package freeze; no competing owner design should be implemented. Do not treat this package as production-ready or installable.

PRODUCTION_STATUS=R&D ONLY
