package duoopen.rnd

data class CloseCycle(
    val serviceEpoch: Long,
    val closeCycleId: Long,
)

data class PrimeAttempt(
    val serviceEpoch: Long,
    val closeCycleId: Long,
    val attemptSequence: Long,
    val sourceEpoch: Long,
)

/**
 * Pure R&D model for cycle-scoped continuity-prime ownership.
 *
 * The owner survives logical-display / PanelEngine replacement. A source is
 * only a capability used by the current attempt; it is not the authority.
 */
class Fold7ContinuityPrimeOwnerGen2 {
    enum class State {
        NO_CYCLE,
        ELIGIBLE,
        IN_FLIGHT,
        RETRYABLE,
        READY,
        FALLBACK_ALLOWED,
    }

    private var cycle: CloseCycle? = null
    private var nextAttemptSequence = 0L
    private var activeAttempt: PrimeAttempt? = null
    private var state: State = State.NO_CYCLE

    val currentState: State get() = state
    val currentAttempt: PrimeAttempt? get() = activeAttempt

    fun beginCycle(newCycle: CloseCycle) {
        if (cycle == newCycle) return
        cycle = newCycle
        nextAttemptSequence = 0L
        activeAttempt = null
        state = State.ELIGIBLE
    }

    fun invalidateCycle(expected: CloseCycle): Boolean {
        if (cycle != expected) return false
        cycle = null
        activeAttempt = null
        state = State.NO_CYCLE
        return true
    }

    fun tryBegin(expected: CloseCycle, sourceEpoch: Long): PrimeAttempt? {
        if (cycle != expected) return null
        if (sourceEpoch <= 0L) return null
        if (state != State.ELIGIBLE && state != State.RETRYABLE) return null

        return PrimeAttempt(
            serviceEpoch = expected.serviceEpoch,
            closeCycleId = expected.closeCycleId,
            attemptSequence = ++nextAttemptSequence,
            sourceEpoch = sourceEpoch,
        ).also {
            activeAttempt = it
            state = State.IN_FLIGHT
        }
    }

    fun isCurrent(attempt: PrimeAttempt): Boolean =
        state == State.IN_FLIGHT &&
            activeAttempt == attempt &&
            cycle?.serviceEpoch == attempt.serviceEpoch &&
            cycle?.closeCycleId == attempt.closeCycleId

    /** Explicit source loss/cancellation. Replacement source does not gain authority automatically. */
    fun abandon(attempt: PrimeAttempt): Boolean {
        if (!isCurrent(attempt)) return false
        activeAttempt = null
        state = State.RETRYABLE
        return true
    }

    fun fail(attempt: PrimeAttempt): Boolean {
        if (!isCurrent(attempt)) return false
        activeAttempt = null
        state = State.RETRYABLE
        return true
    }

    fun complete(attempt: PrimeAttempt): Boolean {
        if (!isCurrent(attempt)) return false
        activeAttempt = null
        state = State.READY
        return true
    }

    /**
     * Explicitly gives up prime ownership for this cycle so ordinary continuity
     * capture may provide fallback content. This is a policy decision, not an
     * accidental consequence of engine replacement.
     */
    fun allowGenericFallback(expected: CloseCycle): Boolean {
        if (cycle != expected) return false
        if (state == State.IN_FLIGHT || state == State.READY || state == State.NO_CYCLE) return false
        activeAttempt = null
        state = State.FALLBACK_ALLOWED
        return true
    }

    fun blocksGenericCapture(expected: CloseCycle): Boolean =
        cycle == expected && state != State.FALLBACK_ALLOWED
}

/**
 * Reduced frame-store model with start-order fencing.
 * Any newer started capture invalidates older tickets, regardless of publish order.
 */
class Fold7ContinuityFrameStoreGen2<T> {
    data class Ticket(
        val cycle: CloseCycle,
        val captureSequence: Long,
    )

    data class Lease<T>(
        val cycle: CloseCycle,
        val captureSequence: Long,
        val payload: T,
    )

    private var cycle: CloseCycle? = null
    private var nextCaptureSequence = 0L
    private var newestStartedCaptureSequence = 0L
    private var latest: Lease<T>? = null

    fun beginCycle(newCycle: CloseCycle) {
        if (cycle == newCycle) return
        cycle = newCycle
        nextCaptureSequence = 0L
        newestStartedCaptureSequence = 0L
        latest = null
    }

    fun invalidateCycle(expected: CloseCycle): Boolean {
        if (cycle != expected) return false
        cycle = null
        latest = null
        newestStartedCaptureSequence = 0L
        return true
    }

    fun beginCapture(expected: CloseCycle): Ticket? {
        if (cycle != expected) return null
        latest = null
        val seq = ++nextCaptureSequence
        newestStartedCaptureSequence = seq
        return Ticket(expected, seq)
    }

    fun publish(ticket: Ticket, payload: T): Lease<T>? {
        if (cycle != ticket.cycle) return null
        if (ticket.captureSequence != newestStartedCaptureSequence) return null
        return Lease(ticket.cycle, ticket.captureSequence, payload).also { latest = it }
    }

    fun current(expected: CloseCycle): Lease<T>? =
        latest?.takeIf { cycle == expected && it.cycle == expected }
}
