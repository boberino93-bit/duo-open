package duoopen.rnd

import kotlin.random.Random

private class BaselineFrameStore<T> {
    data class Ticket(val cycle: CloseCycle, val captureSequence: Long)
    data class Lease<T>(val cycle: CloseCycle, val captureSequence: Long, val payload: T)

    private var cycle: CloseCycle? = null
    private var nextCaptureSequence = 0L
    private var latest: Lease<T>? = null

    fun beginCycle(c: CloseCycle) { cycle = c; nextCaptureSequence = 0L; latest = null }
    fun beginCapture(c: CloseCycle): Ticket? {
        if (cycle != c) return null
        latest = null
        return Ticket(c, ++nextCaptureSequence)
    }
    fun publish(ticket: Ticket, payload: T): Lease<T>? {
        if (cycle != ticket.cycle) return null
        val current = latest
        if (current != null && ticket.captureSequence <= current.captureSequence) return null
        return Lease(ticket.cycle, ticket.captureSequence, payload).also { latest = it }
    }
    fun current(c: CloseCycle): Lease<T>? = latest?.takeIf { cycle == c }
}

private class BaselineEngine(val sourceEpoch: Long) {
    private var primedCycleId = -1L
    fun prime(cycle: CloseCycle, store: BaselineFrameStore<String>): BaselineFrameStore.Ticket? {
        if (primedCycleId == cycle.closeCycleId) return null
        val ticket = store.beginCapture(cycle) ?: return null
        primedCycleId = cycle.closeCycleId
        return ticket
    }
    fun destroy() { /* production destroy does not invalidate prime eligibility/coroutine */ }
}

private var passed = 0
private var failed = 0

private fun test(name: String, block: () -> Unit) {
    try {
        block()
        println("PASS $name")
        passed++
    } catch (t: Throwable) {
        println("FAIL $name :: ${t.message}")
        failed++
    }
}

private fun checkTrue(value: Boolean, msg: String) { if (!value) error(msg) }
private fun checkFalse(value: Boolean, msg: String) = checkTrue(!value, msg)
private fun <T> checkEq(expected: T, actual: T, msg: String) { if (expected != actual) error("$msg expected=$expected actual=$actual") }

fun main() {
    val cycle1 = CloseCycle(serviceEpoch = 7, closeCycleId = 1)

    test("baseline replacement engine can issue second prime same cycle") {
        val store = BaselineFrameStore<String>().also { it.beginCycle(cycle1) }
        val old = BaselineEngine(101)
        val replacement = BaselineEngine(102)
        val t1 = old.prime(cycle1, store)
        old.destroy()
        val t2 = replacement.prime(cycle1, store)
        checkTrue(t1 != null, "old prime missing")
        checkTrue(t2 != null, "replacement should reproduce duplicate-prime defect")
        checkEq(1L, t1!!.captureSequence, "old seq")
        checkEq(2L, t2!!.captureSequence, "new seq")
    }

    test("baseline stale old capture can publish after newer capture started") {
        val store = BaselineFrameStore<String>().also { it.beginCycle(cycle1) }
        val t1 = store.beginCapture(cycle1)!!
        val t2 = store.beginCapture(cycle1)!!
        val oldLease = store.publish(t1, "OLD")
        checkTrue(oldLease != null, "baseline should accept stale older publish before newer publishes")
        checkEq("OLD", store.current(cycle1)!!.payload, "stale frame became current")
        // Simulate newer attempt failure: no publish(t2). Old stale frame remains current.
        checkEq("OLD", store.current(cycle1)!!.payload, "failed newer attempt resurrects/retains older completion")
        checkEq(2L, t2.captureSequence, "newer start existed")
    }

    test("baseline generic accessibility ticket can publish after later Shizuku prime begins") {
        val store = BaselineFrameStore<String>().also { it.beginCycle(cycle1) }
        // Generic Accessibility capture is admitted before the engine's prime guard is set.
        val generic = store.beginCapture(cycle1)!!
        // Privilege becomes available and a later Shizuku prime starts on the same cycle.
        val prime = store.beginCapture(cycle1)!!
        val genericLease = store.publish(generic, "GENERIC_ACCESSIBILITY")
        checkTrue(genericLease != null, "baseline should accept older generic callback after prime start")
        checkEq("GENERIC_ACCESSIBILITY", store.current(cycle1)!!.payload, "generic frame became current")
        checkEq(2L, prime.captureSequence, "newer Shizuku prime had already started")
        // If the later prime fails, the older generic frame remains exposed in the baseline model.
        checkEq("GENERIC_ACCESSIBILITY", store.current(cycle1)!!.payload, "failed prime leaves older generic frame current")
    }

    test("owner allows only one in-flight attempt regardless of source") {
        val owner = Fold7ContinuityPrimeOwnerGen2()
        owner.beginCycle(cycle1)
        val a1 = owner.tryBegin(cycle1, sourceEpoch = 101)!!
        checkTrue(owner.isCurrent(a1), "a1 current")
        checkEq(null, owner.tryBegin(cycle1, sourceEpoch = 102), "replacement source must not auto-gain authority")
    }

    test("explicit abandon allows exact retry with higher attempt sequence") {
        val owner = Fold7ContinuityPrimeOwnerGen2()
        owner.beginCycle(cycle1)
        val a1 = owner.tryBegin(cycle1, 101)!!
        checkTrue(owner.abandon(a1), "abandon current")
        val a2 = owner.tryBegin(cycle1, 102)!!
        checkEq(2L, a2.attemptSequence, "retry sequence")
        checkEq(102L, a2.sourceEpoch, "replacement source")
    }

    test("stale abandoned callback cannot complete owner") {
        val owner = Fold7ContinuityPrimeOwnerGen2()
        owner.beginCycle(cycle1)
        val a1 = owner.tryBegin(cycle1, 101)!!
        owner.abandon(a1)
        val a2 = owner.tryBegin(cycle1, 102)!!
        checkFalse(owner.complete(a1), "stale a1 completion must be inert")
        checkTrue(owner.isCurrent(a2), "a2 remains current")
    }

    test("frame store rejects older publish once newer capture started") {
        val store = Fold7ContinuityFrameStoreGen2<String>().also { it.beginCycle(cycle1) }
        val t1 = store.beginCapture(cycle1)!!
        val t2 = store.beginCapture(cycle1)!!
        checkEq(null, store.publish(t1, "OLD"), "old publish rejected by start-order fence")
        checkEq(null, store.current(cycle1), "no stale frame exposed")
        checkTrue(store.publish(t2, "NEW") != null, "new publish accepted")
        checkEq("NEW", store.current(cycle1)!!.payload, "new frame current")
    }

    test("double fence rejects old callback before and at frame store") {
        val owner = Fold7ContinuityPrimeOwnerGen2()
        val store = Fold7ContinuityFrameStoreGen2<String>()
        owner.beginCycle(cycle1); store.beginCycle(cycle1)
        val a1 = owner.tryBegin(cycle1, 101)!!
        val t1 = store.beginCapture(cycle1)!!
        owner.abandon(a1)
        val a2 = owner.tryBegin(cycle1, 102)!!
        val t2 = store.beginCapture(cycle1)!!
        checkFalse(owner.isCurrent(a1), "old owner token stale")
        checkEq(null, store.publish(t1, "OLD"), "old frame ticket stale")
        checkTrue(owner.isCurrent(a2), "new owner token current")
        val lease = store.publish(t2, "NEW")!!
        checkTrue(owner.complete(a2), "new owner completes")
        checkEq("NEW", lease.payload, "new frame")
        checkEq(Fold7ContinuityPrimeOwnerGen2.State.READY, owner.currentState, "owner ready")
    }

    test("ready state prevents duplicate same-cycle prime") {
        val owner = Fold7ContinuityPrimeOwnerGen2()
        owner.beginCycle(cycle1)
        val a1 = owner.tryBegin(cycle1, 101)!!
        checkTrue(owner.complete(a1), "complete")
        checkEq(null, owner.tryBegin(cycle1, 102), "no duplicate after ready")
        checkTrue(owner.blocksGenericCapture(cycle1), "generic capture remains suppressed after authoritative prime")
    }

    test("failed prime requires explicit retry or explicit generic fallback") {
        val owner = Fold7ContinuityPrimeOwnerGen2()
        owner.beginCycle(cycle1)
        val a1 = owner.tryBegin(cycle1, 101)!!
        checkTrue(owner.fail(a1), "fail current")
        checkEq(Fold7ContinuityPrimeOwnerGen2.State.RETRYABLE, owner.currentState, "retryable")
        checkTrue(owner.blocksGenericCapture(cycle1), "fallback cannot race implicitly")
        checkTrue(owner.allowGenericFallback(cycle1), "explicit fallback release")
        checkFalse(owner.blocksGenericCapture(cycle1), "generic capture allowed only after explicit release")
        checkEq(null, owner.tryBegin(cycle1, 102), "terminal fallback mode prevents later prime race")
    }

    test("cycle invalidation makes old callback inert") {
        val owner = Fold7ContinuityPrimeOwnerGen2()
        val store = Fold7ContinuityFrameStoreGen2<String>()
        owner.beginCycle(cycle1); store.beginCycle(cycle1)
        val a1 = owner.tryBegin(cycle1, 101)!!
        val t1 = store.beginCapture(cycle1)!!
        checkTrue(owner.invalidateCycle(cycle1), "owner invalidated")
        checkTrue(store.invalidateCycle(cycle1), "store invalidated")
        checkFalse(owner.complete(a1), "old completion rejected")
        checkEq(null, store.publish(t1, "OLD"), "old publish rejected")
    }

    test("new cycle has independent attempt sequence and rejects prior tokens") {
        val owner = Fold7ContinuityPrimeOwnerGen2()
        val cycle2 = CloseCycle(serviceEpoch = 7, closeCycleId = 2)
        owner.beginCycle(cycle1)
        val a1 = owner.tryBegin(cycle1, 101)!!
        owner.beginCycle(cycle2)
        checkFalse(owner.isCurrent(a1), "old cycle token stale")
        val a2 = owner.tryBegin(cycle2, 103)!!
        checkEq(1L, a2.attemptSequence, "attempt sequence resets per exact cycle")
    }

    test("service epoch rollover rejects old-cycle identity") {
        val owner = Fold7ContinuityPrimeOwnerGen2()
        val old = CloseCycle(serviceEpoch = 7, closeCycleId = 1)
        val fresh = CloseCycle(serviceEpoch = 8, closeCycleId = 1)
        owner.beginCycle(old)
        val a1 = owner.tryBegin(old, 101)!!
        owner.beginCycle(fresh)
        checkFalse(owner.isCurrent(a1), "old service token stale")
        checkEq(null, owner.tryBegin(old, 102), "old cycle not current")
        checkTrue(owner.tryBegin(fresh, 201) != null, "fresh service can prime")
    }

    test("100k randomized stale/duplicate/remap events preserve owner invariants") {
        val random = Random(0xD00F7)
        val owner = Fold7ContinuityPrimeOwnerGen2()
        var serviceEpoch = 11L
        var cycleId = 1L
        var cycle = CloseCycle(serviceEpoch, cycleId)
        owner.beginCycle(cycle)
        val historical = mutableListOf<PrimeAttempt>()
        var sourceEpoch = 1000L

        repeat(100_000) {
            when (random.nextInt(9)) {
                0 -> owner.tryBegin(cycle, ++sourceEpoch)?.let { historical += it }
                1 -> owner.currentAttempt?.let { owner.fail(it) }
                2 -> owner.currentAttempt?.let { owner.abandon(it) }
                3 -> owner.currentAttempt?.let { owner.complete(it) }
                4 -> if (owner.currentState != Fold7ContinuityPrimeOwnerGen2.State.IN_FLIGHT && owner.currentState != Fold7ContinuityPrimeOwnerGen2.State.READY) owner.allowGenericFallback(cycle)
                5 -> if (historical.isNotEmpty()) owner.complete(historical[random.nextInt(historical.size)])
                6 -> {
                    owner.invalidateCycle(cycle)
                    cycle = CloseCycle(serviceEpoch, ++cycleId)
                    owner.beginCycle(cycle)
                }
                7 -> {
                    serviceEpoch++
                    cycleId = 1L
                    cycle = CloseCycle(serviceEpoch, cycleId)
                    owner.beginCycle(cycle)
                }
                8 -> { /* duplicate read-only event */ owner.blocksGenericCapture(cycle) }
            }

            val active = owner.currentAttempt
            if (owner.currentState == Fold7ContinuityPrimeOwnerGen2.State.IN_FLIGHT) {
                checkTrue(active != null, "IN_FLIGHT must have token")
                checkEq(cycle.serviceEpoch, active!!.serviceEpoch, "active service")
                checkEq(cycle.closeCycleId, active.closeCycleId, "active cycle")
            } else {
                checkEq(null, active, "non-IN_FLIGHT must not retain token")
            }
        }
    }

    println("RESULT passed=$passed failed=$failed total=${passed + failed}")
    if (failed != 0) error("test failures=$failed")
}
