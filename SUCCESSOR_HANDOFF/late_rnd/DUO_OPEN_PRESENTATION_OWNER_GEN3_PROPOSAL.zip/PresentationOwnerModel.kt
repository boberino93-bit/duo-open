import kotlin.random.Random

enum class RenderPath { FROZEN_VIEW, LIVE_MIRROR }
enum class Evidence { NONE, DRAWN, FRAME_COMMITTED, TRANSACTION_COMMITTED, PRESENTED_CALLBACK, PRESENT_FENCE }
enum class Stage { REQUESTED, HOST_READY, SUBMITTED, PRESENTED, INVALIDATED, FAILED }

data class LegacyIdentity(
    val serviceEpoch: Long,
    val closeCycleId: Long,
    val contentLeaseId: Long,
    val hostEpoch: Long,
    val attemptSequence: Long,
    val renderPath: RenderPath,
)

class LegacyHostLease {
    private var hostEpoch = 0L
    private var nextAttempt = 0L
    fun openHost(): Long = ++hostEpoch
    fun begin(serviceEpoch: Long, cycle: Long, content: Long, path: RenderPath): LegacyIdentity =
        LegacyIdentity(serviceEpoch, cycle, content, hostEpoch, ++nextAttempt, path)
}

data class Identity(
    val serviceEpoch: Long,
    val closeCycleId: Long,
    val transitionGeneration: Long,
    val visualAttemptId: Long,
    val hostLeaseId: Long,
    val contentLeaseId: Long,
    val attemptSequence: Long,
    val renderPath: RenderPath,
)

data class Snapshot(
    val id: Identity,
    val stage: Stage,
    val evidence: Evidence,
    val actualPresentNs: Long? = null,
)

class PresentationOwner(private val serviceEpoch: Long) {
    private var nextHostLeaseId = 0L
    private var nextAttemptSequence = 0L
    private var current: Snapshot? = null

    fun allocateHostLease(): Long = ++nextHostLeaseId

    fun begin(
        closeCycleId: Long,
        transitionGeneration: Long,
        visualAttemptId: Long,
        hostLeaseId: Long,
        contentLeaseId: Long,
        renderPath: RenderPath,
    ): Identity {
        val id = Identity(
            serviceEpoch,
            closeCycleId,
            transitionGeneration,
            visualAttemptId,
            hostLeaseId,
            contentLeaseId,
            ++nextAttemptSequence,
            renderPath,
        )
        current = Snapshot(id, Stage.REQUESTED, Evidence.NONE)
        return id
    }

    fun hostReady(id: Identity): Boolean = update(id) { copy(stage = Stage.HOST_READY) }
    fun drawn(id: Identity): Boolean = update(id) { copy(evidence = maxEvidence(evidence, Evidence.DRAWN)) }
    fun frameCommitted(id: Identity): Boolean = update(id) {
        copy(stage = if (stage == Stage.REQUESTED) Stage.SUBMITTED else stage,
             evidence = maxEvidence(evidence, Evidence.FRAME_COMMITTED))
    }
    fun transactionCommitted(id: Identity): Boolean = update(id) {
        copy(stage = Stage.SUBMITTED,
             evidence = maxEvidence(evidence, Evidence.TRANSACTION_COMMITTED))
    }

    // Android API 35 contract: completed listener fires when transaction is presented.
    fun transactionCompleted(id: Identity, presentFenceNs: Long? = null): Boolean = update(id) {
        copy(
            stage = Stage.PRESENTED,
            evidence = if (presentFenceNs != null) Evidence.PRESENT_FENCE else Evidence.PRESENTED_CALLBACK,
            actualPresentNs = presentFenceNs ?: actualPresentNs,
        )
    }

    // Proposed frozen-view proof: a draw-synchronized SurfaceControl transaction completion.
    fun frozenDrawTransactionCompleted(id: Identity, presentFenceNs: Long? = null): Boolean {
        if (id.renderPath != RenderPath.FROZEN_VIEW) return false
        return transactionCompleted(id, presentFenceNs)
    }

    fun fail(id: Identity): Boolean = update(id) { copy(stage = Stage.FAILED) }

    fun invalidate(expected: Identity? = null) {
        val cur = current ?: return
        if (expected != null && cur.id != expected) return
        current = cur.copy(stage = Stage.INVALIDATED)
    }

    fun snapshot(): Snapshot? = current
    fun isPresentedCurrent(): Boolean = current?.stage == Stage.PRESENTED

    private fun update(id: Identity, op: Snapshot.() -> Snapshot): Boolean {
        val cur = current ?: return false
        if (cur.id != id || cur.stage in setOf(Stage.INVALIDATED, Stage.FAILED)) return false
        current = cur.op()
        return true
    }

    private fun maxEvidence(a: Evidence, b: Evidence): Evidence = if (a.ordinal >= b.ordinal) a else b
}

private class TestRunner {
    private var passed = 0
    private var total = 0
    fun test(name: String, block: () -> Unit) {
        total++
        try {
            block()
            passed++
            println("PASS $name")
        } catch (t: Throwable) {
            println("FAIL $name: ${t.message}")
            throw t
        }
    }
    fun done() = println("RESULT=$passed/$total")
}

fun main() {
    val t = TestRunner()

    t.test("legacy_intent_can_claim_visual_active_without_host_or_present") {
        val controllerCoverVisual = true
        val mirrorRequested = true
        val hostExists = false
        val physicallyPresented = false
        val legacyVisualMirrorActive = mirrorRequested && controllerCoverVisual
        check(legacyVisualMirrorActive)
        check(!hostExists && !physicallyPresented)
    }

    t.test("legacy_frozen_identity_collides_across_new_host_objects") {
        val a = LegacyHostLease(); a.openHost()
        val b = LegacyHostLease(); b.openHost()
        val ia = a.begin(1, 7, 99, RenderPath.FROZEN_VIEW)
        val ib = b.begin(1, 7, 99, RenderPath.FROZEN_VIEW)
        check(ia == ib)
    }

    t.test("gen3_demand_is_not_presented") {
        val o = PresentationOwner(1)
        val id = o.begin(7, 12, 3, o.allocateHostLease(), 99, RenderPath.FROZEN_VIEW)
        check(!o.isPresentedCurrent())
        check(o.snapshot()!!.id == id)
    }

    t.test("service_stable_host_lease_prevents_remap_collision") {
        val o = PresentationOwner(1)
        val h1 = o.allocateHostLease()
        val a = o.begin(7, 12, 3, h1, 99, RenderPath.FROZEN_VIEW)
        val h2 = o.allocateHostLease()
        val b = o.begin(7, 12, 3, h2, 99, RenderPath.FROZEN_VIEW)
        check(a != b)
        check(a.hostLeaseId != b.hostLeaseId)
    }

    t.test("stale_callback_after_remap_is_inert") {
        val o = PresentationOwner(1)
        val a = o.begin(7, 12, 3, o.allocateHostLease(), 99, RenderPath.FROZEN_VIEW)
        val b = o.begin(7, 12, 3, o.allocateHostLease(), 99, RenderPath.FROZEN_VIEW)
        check(!o.frameCommitted(a))
        check(o.frameCommitted(b))
        check(o.snapshot()!!.id == b)
    }

    t.test("frame_commit_does_not_assert_visibility") {
        val o = PresentationOwner(1)
        val id = o.begin(7, 12, 3, o.allocateHostLease(), 99, RenderPath.FROZEN_VIEW)
        o.hostReady(id); o.drawn(id); o.frameCommitted(id)
        check(!o.isPresentedCurrent())
        check(o.snapshot()!!.evidence == Evidence.FRAME_COMMITTED)
    }

    t.test("transaction_commit_does_not_assert_visibility") {
        val o = PresentationOwner(1)
        val id = o.begin(7, 12, 3, o.allocateHostLease(), 44, RenderPath.LIVE_MIRROR)
        o.transactionCommitted(id)
        check(!o.isPresentedCurrent())
        check(o.snapshot()!!.evidence == Evidence.TRANSACTION_COMMITTED)
    }

    t.test("completed_callback_is_presentation_evidence_without_fence") {
        val o = PresentationOwner(1)
        val id = o.begin(7, 12, 3, o.allocateHostLease(), 44, RenderPath.LIVE_MIRROR)
        o.transactionCommitted(id)
        check(o.transactionCompleted(id, null))
        check(o.isPresentedCurrent())
        check(o.snapshot()!!.evidence == Evidence.PRESENTED_CALLBACK)
        check(o.snapshot()!!.actualPresentNs == null)
    }

    t.test("present_fence_upgrades_timestamp_quality") {
        val o = PresentationOwner(1)
        val id = o.begin(7, 12, 3, o.allocateHostLease(), 44, RenderPath.LIVE_MIRROR)
        check(o.transactionCompleted(id, 123456789L))
        check(o.snapshot()!!.evidence == Evidence.PRESENT_FENCE)
        check(o.snapshot()!!.actualPresentNs == 123456789L)
    }

    t.test("frozen_draw_synced_transaction_can_confirm_present") {
        val o = PresentationOwner(1)
        val id = o.begin(7, 12, 3, o.allocateHostLease(), 99, RenderPath.FROZEN_VIEW)
        o.frameCommitted(id)
        check(o.frozenDrawTransactionCompleted(id, null))
        check(o.isPresentedCurrent())
        check(o.snapshot()!!.evidence == Evidence.PRESENTED_CALLBACK)
    }

    t.test("reversal_invalidates_late_present") {
        val o = PresentationOwner(1)
        val id = o.begin(7, 12, 3, o.allocateHostLease(), 44, RenderPath.LIVE_MIRROR)
        o.invalidate(id)
        check(!o.transactionCompleted(id, 1000L))
        check(!o.isPresentedCurrent())
    }

    t.test("new_attempt_rejects_old_present") {
        val o = PresentationOwner(1)
        val a = o.begin(7, 12, 3, o.allocateHostLease(), 44, RenderPath.LIVE_MIRROR)
        val b = o.begin(7, 13, 4, o.allocateHostLease(), 45, RenderPath.LIVE_MIRROR)
        check(!o.transactionCompleted(a, 111L))
        check(o.transactionCompleted(b, 222L))
        check(o.snapshot()!!.actualPresentNs == 222L)
    }

    t.test("100k_event_adversarial_stream_preserves_current_identity") {
        val rnd = Random(0xD00F7)
        val o = PresentationOwner(9)
        var current: Identity? = null
        repeat(100_000) {
            when (rnd.nextInt(8)) {
                0 -> current = o.begin(
                    closeCycleId = rnd.nextLong(1, 500),
                    transitionGeneration = rnd.nextLong(1, 10_000),
                    visualAttemptId = rnd.nextLong(1, 10_000),
                    hostLeaseId = o.allocateHostLease(),
                    contentLeaseId = rnd.nextLong(1, 10_000),
                    renderPath = if (rnd.nextBoolean()) RenderPath.FROZEN_VIEW else RenderPath.LIVE_MIRROR,
                )
                1 -> current?.let { o.hostReady(it) }
                2 -> current?.let { o.frameCommitted(it) }
                3 -> current?.let { o.transactionCommitted(it) }
                4 -> current?.let { o.transactionCompleted(it, if (rnd.nextBoolean()) rnd.nextLong(1, Long.MAX_VALUE) else null) }
                5 -> current?.let { o.invalidate(it) }
                6 -> {
                    // Deliberately synthesize stale callback identity by cloning current with older attempt id.
                    current?.let { cur ->
                        val stale = cur.copy(attemptSequence = (cur.attemptSequence - 1).coerceAtLeast(0))
                        check(!o.transactionCompleted(stale, 1L))
                    }
                }
                7 -> current?.let { o.drawn(it) }
            }
            val snap = o.snapshot()
            if (snap != null && snap.stage == Stage.PRESENTED) {
                check(snap.evidence == Evidence.PRESENTED_CALLBACK || snap.evidence == Evidence.PRESENT_FENCE)
            }
        }
    }

    t.done()
}
