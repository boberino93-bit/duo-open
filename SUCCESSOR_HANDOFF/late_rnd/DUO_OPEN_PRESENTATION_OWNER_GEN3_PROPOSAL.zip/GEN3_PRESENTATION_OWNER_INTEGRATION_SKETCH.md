# Gen3 P1.2 Presentation Owner — Integration Sketch

This is an R&D integration sketch, not a production patch.

## Core identity

```kotlin
data class PresentationIdentity(
    val serviceEpoch: Long,
    val closeCycleId: Long,
    val transitionGeneration: Long,
    val visualAttemptId: Long,
    val hostLeaseId: Long,
    val contentLeaseId: Long,
    val presentationAttemptSequence: Long,
    val renderPath: RenderPath,
)
```

`hostLeaseId` and `presentationAttemptSequence` are allocated by one service-stable owner. They never restart when a `DisplayMirrorHost` is recreated.

## State/evidence

```kotlin
enum class Stage { IDLE, REQUESTED, HOST_READY, SUBMITTED, PRESENTED, FAILED, INVALIDATED }
enum class Evidence {
    NONE,
    DRAWN,
    FRAME_COMMITTED,
    TRANSACTION_COMMITTED,
    PRESENTED_CALLBACK,
    PRESENT_FENCE,
}
```

Only `PRESENTED_CALLBACK` and `PRESENT_FENCE` may produce `Stage.PRESENTED`.

## Live mirror

- transaction committed callback: `SUBMITTED / TRANSACTION_COMMITTED`
- transaction completed callback: `PRESENTED / PRESENTED_CALLBACK`
- valid present fence: upgrade to `PRESENT_FENCE` and store `signalTime`

Do not require a valid fence to acknowledge a completed callback as presented; use the fence for stronger timestamp quality.

## Frozen View

`registerFrameCommitCallback` remains non-terminal. Prototype a draw-synchronized `SurfaceControl.Transaction` completion tied to the host root/current draw to obtain actual presentation evidence. If that cannot be proven on Fold7, do not label the frame physically presented.

## Ordering

1. Exact CoverVisualLease demand becomes current.
2. Allocate service-stable host lease before constructing host.
3. Bind exact content and begin presentation attempt.
4. Capture exact identity in every asynchronous callback.
5. On remap/reversal/new content/new visual attempt, invalidate old identity before resource release.
6. Only the exact current attempt may become presented.

## Do not

- infer identity by timing proximity;
- use logical display ID as physical identity;
- let host-local counters become cross-host identity;
- wait synchronously on fences;
- change hinge thresholds to mask failed presentation;
- revive autonomous cover `PanelEngine` as implicit fallback.
