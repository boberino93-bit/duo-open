#!/usr/bin/env python3
"""Duo Open app-process restart recovery model.

Evidence target:
  current main 45bb0d326899c0e08415928224cfea0ff58d2d4e
Reconciled future state:
  primary staged DUO_OPEN_GEN3_PHASE1_AUTHORITY_V2.zip

This is a reduced ownership model, not an Android timing simulator.
It tests what may be *claimed/armed* after a fresh app/accessibility process
binds to a daemon Shizuku UserService that survived with a cover lease.
"""
from dataclasses import dataclass
from enum import Enum, auto
import random

class LeaseState(Enum):
    IDLE = auto()
    HELD = auto()

class Posture(Enum):
    OPEN_INNER = auto()
    NATIVE_COVER = auto()
    MID_TRANSITION = auto()

class RecoveryPhase(Enum):
    RECOVERING = auto()
    WAIT_FRESH_EDGE = auto()
    READY = auto()

@dataclass(frozen=True)
class Lease:
    state: LeaseState
    shell_session: int
    lease_id: int
    lease_epoch: int
    owner_generation: int
    physical_id: int
    owner_service_epoch: int | None = None
    owner_close_cycle_id: int | None = None


def held(owner_epoch=111, cycle=4, generation=12, legacy=False):
    return Lease(LeaseState.HELD, 9001, 7, 4, generation, 123456,
                 None if legacy else owner_epoch,
                 None if legacy else cycle)

def idle():
    return Lease(LeaseState.IDLE, 9001, 0, 0, -1, -1, None, None)

@dataclass
class CurrentMainFreshProcess:
    """Current V3 behavior on main: accepted lease identity has no serviceEpoch."""
    new_service_epoch: int
    accepted: Lease | None = None
    render_armed: bool = False
    active_close_cycle: bool = False

    def first_ready_reconcile(self, shell: Lease):
        # app has no acceptedSnapshot -> sends shellSession=0; shell treats 0 as wildcard
        if shell.shell_session <= 0:
            return
        if shell.state is LeaseState.IDLE:
            self.accepted = shell
            return
        if shell.lease_id > 0 and shell.lease_epoch > 0 and shell.owner_generation >= 0 and shell.physical_id >= 0:
            # current main token structurally accepts it but cannot distinguish old app service
            self.accepted = Lease(shell.state, shell.shell_session, shell.lease_id,
                                  shell.lease_epoch, shell.owner_generation,
                                  shell.physical_id, None, None)

    def arm(self):
        self.active_close_cycle = False  # fresh Fold7Gen2Kernel
        self.render_armed = True          # continuity.arm()
        # hideMirror does not release Fold7CoverPanelLease

@dataclass
class Phase1V2FreshProcess:
    """Primary's staged exact-CAS Phase1 V2: identity is fixed, startup gate is not."""
    new_service_epoch: int
    accepted: Lease | None = None
    render_armed: bool = False
    active_close_cycle: bool = False

    def first_ready_reconcile(self, shell: Lease):
        # Startup flow was not changed by Phase1 V2. A structurally valid HELD
        # snapshot remains acceptable even if its ownerServiceEpoch is old.
        if shell.shell_session > 0:
            self.accepted = shell

    def arm(self):
        self.active_close_cycle = False
        self.render_armed = True

    def owns_new_cycle_without_cas(self, new_cycle_id=1, generation=1):
        t=self.accepted
        return bool(t and t.state is LeaseState.HELD and
                    t.owner_service_epoch == self.new_service_epoch and
                    t.owner_close_cycle_id == new_cycle_id and
                    t.owner_generation == generation)

    def foreign_held_resident(self):
        t=self.accepted
        return bool(t and t.state is LeaseState.HELD and
                    t.owner_service_epoch != self.new_service_epoch and
                    not self.active_close_cycle)

@dataclass
class ProposedRecoveryGate:
    new_service_epoch: int
    phase: RecoveryPhase = RecoveryPhase.RECOVERING
    observed: Lease | None = None
    render_armed: bool = False
    cleanup_required: bool = False

    def first_ready_snapshot(self, shell: Lease, posture: Posture):
        self.observed = shell
        if shell.state is LeaseState.HELD:
            foreign = (shell.owner_service_epoch is None or
                       shell.owner_service_epoch != self.new_service_epoch)
            if foreign:
                self.cleanup_required = True
                self.render_armed = False
                self.phase = RecoveryPhase.RECOVERING
                return
        self._finish_bootstrap(posture)

    def cleanup_result(self, idle_now: bool, posture: Posture):
        if not self.cleanup_required or not idle_now:
            return
        self.cleanup_required = False
        self.observed = idle()
        self._finish_bootstrap(posture)

    def _finish_bootstrap(self, posture: Posture):
        if self.cleanup_required:
            return
        if posture is Posture.MID_TRANSITION:
            # Prior semantic attempt provenance is gone with the dead app process.
            self.phase = RecoveryPhase.WAIT_FRESH_EDGE
            self.render_armed = False
        else:
            self.phase = RecoveryPhase.READY
            self.render_armed = True

    def fresh_semantic_edge(self):
        if self.phase is RecoveryPhase.WAIT_FRESH_EDGE and not self.cleanup_required:
            self.phase = RecoveryPhase.READY
            self.render_armed = True


def deterministic():
    tests=[]
    old=held(owner_epoch=111)

    c=CurrentMainFreshProcess(222); c.first_ready_reconcile(old); c.arm()
    tests.append(("current main accepts daemon-surviving HELD lease", c.accepted is not None and c.accepted.state is LeaseState.HELD))
    tests.append(("current main loses prior service identity", c.accepted is not None and c.accepted.owner_service_epoch is None))
    tests.append(("current main arms with no local close cycle", c.render_armed and not c.active_close_cycle))

    p=Phase1V2FreshProcess(222); p.first_ready_reconcile(old); p.arm()
    tests.append(("Phase1 V2 preserves old ownerServiceEpoch", p.accepted is not None and p.accepted.owner_service_epoch == 111))
    tests.append(("Phase1 V2 does not misclaim old lease as new cycle without CAS", not p.owns_new_cycle_without_cas()))
    tests.append(("Phase1 V2 still leaves foreign HELD resident through arm", p.foreign_held_resident() and p.render_armed))

    g=ProposedRecoveryGate(222); g.first_ready_snapshot(old, Posture.OPEN_INNER)
    tests.append(("recovery gate classifies old epoch HELD as foreign", g.cleanup_required and not g.render_armed))
    g.cleanup_result(True, Posture.OPEN_INNER)
    tests.append(("recovery gate arms stable open only after cleanup", g.phase is RecoveryPhase.READY and g.render_armed))

    g2=ProposedRecoveryGate(222); g2.first_ready_snapshot(held(legacy=True), Posture.NATIVE_COVER)
    tests.append(("recovery gate treats legacy no-epoch HELD as foreign", g2.cleanup_required and not g2.render_armed))
    g2.cleanup_result(True, Posture.NATIVE_COVER)
    tests.append(("recovery gate recovers at stable native cover", g2.phase is RecoveryPhase.READY and g2.render_armed))

    g3=ProposedRecoveryGate(222); g3.first_ready_snapshot(idle(), Posture.MID_TRANSITION)
    tests.append(("recovery gate refuses ambiguous mid-transition join", g3.phase is RecoveryPhase.WAIT_FRESH_EDGE and not g3.render_armed))
    g3.fresh_semantic_edge()
    tests.append(("fresh semantic edge authorizes new-process continuity", g3.phase is RecoveryPhase.READY and g3.render_armed))

    g4=ProposedRecoveryGate(222); g4.first_ready_snapshot(old, Posture.OPEN_INNER); g4.cleanup_result(False, Posture.OPEN_INNER)
    tests.append(("cleanup failure stays fail-closed", g4.phase is RecoveryPhase.RECOVERING and g4.cleanup_required and not g4.render_armed))
    return tests


def adversarial(seed=0xD00F7, n=100_000):
    rng=random.Random(seed)
    phase1_resident=0
    gate_fail=0
    for _ in range(n):
        new=rng.randrange(2, 10_000_000)
        old=rng.randrange(1, 10_000_000)
        while old==new:
            old=rng.randrange(1, 10_000_000)
        posture=rng.choice(list(Posture))
        shell=rng.choice([held(old), held(legacy=True), idle()])

        p=Phase1V2FreshProcess(new); p.first_ready_reconcile(shell); p.arm()
        if p.foreign_held_resident():
            phase1_resident += 1

        g=ProposedRecoveryGate(new); g.first_ready_snapshot(shell, posture)
        if shell.state is LeaseState.HELD:
            if not g.cleanup_required or g.render_armed or g.phase is not RecoveryPhase.RECOVERING:
                gate_fail += 1
        elif posture is Posture.MID_TRANSITION:
            if g.render_armed or g.phase is not RecoveryPhase.WAIT_FRESH_EDGE:
                gate_fail += 1
        else:
            if not g.render_armed or g.phase is not RecoveryPhase.READY:
                gate_fail += 1
    return phase1_resident, gate_fail

if __name__ == '__main__':
    tests=deterministic()
    for name,ok in tests:
        print(("PASS" if ok else "FAIL")+": "+name)
    print(f"DETERMINISTIC: {sum(ok for _,ok in tests)}/{len(tests)}")
    resident,fail=adversarial()
    print("ADVERSARIAL seed=0xD00F7 iterations=100000 "
          f"phase1_foreign_held_resident={resident} proposed_invariant_failures={fail}")
    raise SystemExit(0 if all(ok for _,ok in tests) and fail==0 else 1)
