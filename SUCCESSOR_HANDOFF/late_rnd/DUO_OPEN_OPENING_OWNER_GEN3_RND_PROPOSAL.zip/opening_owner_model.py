from __future__ import annotations
from dataclasses import dataclass
import random

OPENING_STATES = {"OPENING_FROM_CLOSED", "INNER_HANDOFF"}

@dataclass(frozen=True)
class Attempt:
    service_epoch: int
    opening_cycle_id: int
    attempt_sequence: int

@dataclass(frozen=True)
class Binding:
    attempt: Attempt
    host_epoch: int

class Baseline:
    """Reduced source-faithful model of FoldOverlayService opening booleans."""
    def __init__(self):
        self.state = "NATIVE_COVER"
        self.privileged = True
        self.latched = False
        self.started = False
        self.cover_host: int | None = None
        self.active_host: int | None = None
        self.starts: list[int] = []
        self.ends: list[int] = []

    def opening_edge(self):
        if self.state == "NATIVE_COVER":
            self.state = "OPENING_FROM_CLOSED"
            self.latched = True
            self.started = False
        self.reconcile()

    def set_state(self, state: str):
        self.state = state
        self.reconcile()

    def set_privileged(self, ready: bool):
        self.privileged = ready
        self.reconcile()

    def host(self, host_epoch: int | None):
        # syncDisplays destroys/removes old engine and can create a replacement.
        if self.active_host is not None and self.active_host != host_epoch:
            self.ends.append(self.active_host)
            self.active_host = None
        self.cover_host = host_epoch
        self.reconcile()

    def reconcile(self):
        if not self.privileged or self.state not in OPENING_STATES:
            self.latched = False
            self.started = False
            if self.active_host is not None:
                self.ends.append(self.active_host)
                self.active_host = None

        # Current source explicitly clears the semantic latch if no cover engine.
        if self.latched and self.cover_host is None:
            self.latched = False
            self.started = False

        if self.latched and self.cover_host is not None:
            if not self.started:
                self.starts.append(self.cover_host)
                self.active_host = self.cover_host
                self.started = True
        else:
            if self.active_host is not None:
                self.ends.append(self.active_host)
                self.active_host = None

class Proposed:
    """Stable opening-attempt owner independent of mutable PanelEngine identity."""
    def __init__(self):
        self.service_epoch = 1
        self.next_cycle = 0
        self.next_attempt = 0
        self.intent: Attempt | None = None
        self.visible_demand = False
        self.state = "NATIVE_COVER"
        self.privileged = True
        self.cover_host: int | None = None
        self.binding: Binding | None = None
        self.starts: list[Binding] = []
        self.stops: list[Binding] = []

    def _new_attempt(self):
        self.next_cycle += 1
        self.next_attempt += 1
        self.intent = Attempt(self.service_epoch, self.next_cycle, self.next_attempt)
        self.visible_demand = True

    def opening_edge(self):
        if self.state == "NATIVE_COVER" and self.privileged:
            self.state = "OPENING_FROM_CLOSED"
            self._new_attempt()
        self.reconcile()

    def set_state(self, state: str):
        self.state = state
        if state not in OPENING_STATES:
            self.cancel("state-exit")
        else:
            self.reconcile()

    def set_privileged(self, ready: bool):
        self.privileged = ready
        if not ready:
            self.cancel("privilege-loss")
        else:
            self.reconcile()

    def host(self, host_epoch: int | None):
        self.cover_host = host_epoch
        self.reconcile()

    def cancel(self, reason: str):
        if self.binding is not None:
            self.stops.append(self.binding)
        self.binding = None
        self.intent = None
        self.visible_demand = False

    def timeout(self, attempt: Attempt):
        # Exact callback fence: an old timeout cannot cancel a newer attempt.
        if self.intent == attempt:
            self.cancel("timeout")

    def service_restart(self):
        self.cancel("restart")
        self.service_epoch += 1
        self.state = "NATIVE_COVER"
        self.cover_host = None

    def reconcile(self):
        if not self.privileged or self.state not in OPENING_STATES or not self.visible_demand or self.intent is None:
            if self.binding is not None:
                self.stops.append(self.binding)
                self.binding = None
            return

        if self.cover_host is None:
            # Host loss does NOT consume/cancel the accepted semantic attempt.
            if self.binding is not None:
                self.stops.append(self.binding)
                self.binding = None
            return

        desired = Binding(self.intent, self.cover_host)
        if self.binding == desired:
            return
        if self.binding is not None:
            self.stops.append(self.binding)
        self.binding = desired
        self.starts.append(desired)


def check(name, fn):
    try:
        fn()
        print(f"PASS {name}")
        return True
    except AssertionError as e:
        print(f"FAIL {name}: {e}")
        return False


def t_baseline_remap_loses_visual():
    b=Baseline(); b.host(1); b.opening_edge(); assert b.active_host==1
    # Same semantic opening attempt, physical cover role moves to replacement engine.
    b.host(2)
    assert b.latched is True
    assert b.started is True
    assert b.active_host is None, (b.active_host,b.starts,b.ends)
    assert b.starts == [1]


def t_proposed_remap_rebinds():
    p=Proposed(); p.host(1); p.opening_edge(); first=p.binding; assert first and first.host_epoch==1
    p.host(2); assert p.binding and p.binding.host_epoch==2
    assert p.binding.attempt==first.attempt
    assert [x.host_epoch for x in p.starts]==[1,2]


def t_baseline_transient_route_gap_consumes_attempt():
    b=Baseline(); b.host(1); b.opening_edge(); b.host(None)
    assert b.latched is False
    b.host(2)
    assert b.active_host is None and b.starts==[1]


def t_proposed_transient_route_gap_preserves_attempt():
    p=Proposed(); p.host(1); p.opening_edge(); a=p.intent; p.host(None)
    assert p.intent==a and p.binding is None
    p.host(2); assert p.binding and p.binding.host_epoch==2 and p.binding.attempt==a


def t_duplicate_reconcile_idempotent():
    p=Proposed(); p.host(7); p.opening_edge(); n=len(p.starts)
    for _ in range(20): p.reconcile()
    assert len(p.starts)==n


def t_old_timeout_cannot_cancel_new_cycle():
    p=Proposed(); p.host(1); p.opening_edge(); old=p.intent
    p.set_state("OPEN_INNER")
    p.state="NATIVE_COVER"; p.host(1); p.opening_edge(); new=p.intent
    assert old != new
    p.timeout(old)
    assert p.intent==new and p.binding and p.binding.attempt==new


def t_current_timeout_cancels_exact_attempt():
    p=Proposed(); p.host(1); p.opening_edge(); a=p.intent; assert a
    p.timeout(a); assert p.intent is None and p.binding is None


def t_host_loss_stops_old_before_rebind():
    p=Proposed(); p.host(1); p.opening_edge(); old=p.binding
    p.host(None); assert old in p.stops and p.binding is None
    p.host(3); assert p.binding and p.binding.host_epoch==3


def t_privilege_loss_cancels():
    p=Proposed(); p.host(1); p.opening_edge(); p.set_privileged(False)
    assert p.intent is None and p.binding is None


def t_state_exit_cancels():
    p=Proposed(); p.host(1); p.opening_edge(); p.set_state("OPEN_INNER")
    assert p.intent is None and p.binding is None


def t_service_epoch_fences_old_timeout():
    p=Proposed(); p.host(1); p.opening_edge(); old=p.intent
    p.service_restart(); p.host(2); p.opening_edge(); new=p.intent
    assert old and new and old.service_epoch != new.service_epoch
    p.timeout(old); assert p.intent==new


def t_fuzz(seed=0xD00F7, n=100_000):
    rng=random.Random(seed); p=Proposed(); host_counter=0; old_attempts=[]
    for _ in range(n):
        e=rng.randrange(10)
        if e==0:
            if p.state!="NATIVE_COVER": p.set_state("NATIVE_COVER")
            p.opening_edge()
            if p.intent: old_attempts.append(p.intent)
        elif e==1:
            host_counter+=1; p.host(host_counter)
        elif e==2:
            p.host(None)
        elif e==3:
            p.set_state("INNER_HANDOFF")
        elif e==4:
            p.set_state("OPEN_INNER")
        elif e==5:
            p.set_privileged(False)
        elif e==6:
            p.set_privileged(True)
        elif e==7:
            if old_attempts: p.timeout(rng.choice(old_attempts))
        elif e==8:
            p.reconcile()
        else:
            p.service_restart()

        if p.binding is not None:
            assert p.intent is not None
            assert p.binding.attempt == p.intent
            assert p.cover_host == p.binding.host_epoch
            assert p.visible_demand and p.privileged and p.state in OPENING_STATES
        if p.intent is None:
            assert p.binding is None


def main():
    tests=[
        ("baseline_remap_loses_visual",t_baseline_remap_loses_visual),
        ("proposed_remap_rebinds",t_proposed_remap_rebinds),
        ("baseline_transient_route_gap_consumes_attempt",t_baseline_transient_route_gap_consumes_attempt),
        ("proposed_transient_route_gap_preserves_attempt",t_proposed_transient_route_gap_preserves_attempt),
        ("duplicate_reconcile_idempotent",t_duplicate_reconcile_idempotent),
        ("old_timeout_cannot_cancel_new_cycle",t_old_timeout_cannot_cancel_new_cycle),
        ("current_timeout_cancels_exact_attempt",t_current_timeout_cancels_exact_attempt),
        ("host_loss_stops_old_before_rebind",t_host_loss_stops_old_before_rebind),
        ("privilege_loss_cancels",t_privilege_loss_cancels),
        ("state_exit_cancels",t_state_exit_cancels),
        ("service_epoch_fences_old_timeout",t_service_epoch_fences_old_timeout),
        ("fuzz_100k",t_fuzz),
    ]
    ok=sum(check(n,f) for n,f in tests)
    print(f"RESULT passed={ok} failed={len(tests)-ok} total={len(tests)}")
    raise SystemExit(0 if ok==len(tests) else 1)

if __name__=='__main__': main()
