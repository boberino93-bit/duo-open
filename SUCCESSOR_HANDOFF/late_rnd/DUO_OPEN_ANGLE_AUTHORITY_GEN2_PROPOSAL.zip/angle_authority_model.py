from __future__ import annotations
from dataclasses import dataclass
from enum import Enum, auto
import random


class Source(Enum):
    NONE = auto()
    PRECISE = auto()
    PUBLIC = auto()
    SYNTHETIC_ENDPOINT = auto()


@dataclass(frozen=True)
class Sample:
    source: Source
    session: int
    sequence: int
    angle: float
    source_uptime_ms: int
    receive_uptime_ms: int


class BaselineAuthority:
    """Source-faithful reduction of HingeAngleSource externalActive semantics."""
    EXTERNAL_STALE_MS = 3000

    def __init__(self):
        self.external_active = False
        self.external_last_receive_ms = -10**12
        self.angle = None
        self.source = Source.NONE

    def precise(self, sample: Sample):
        # Mirrors feedExternal(): freshness is stamped at consumer receipt time.
        self.external_active = True
        self.external_last_receive_ms = sample.receive_uptime_ms
        self.angle = sample.angle
        self.source = sample.source
        return True

    def public(self, angle: float, now_ms: int):
        if self.external_active:
            if now_ms - self.external_last_receive_ms < self.EXTERNAL_STALE_MS:
                return False
            self.external_active = False
        self.angle = angle
        self.source = Source.PUBLIC
        return True

    def clear_external(self):
        self.external_active = False


class Gen2AngleAuthority:
    """Proposed source-stamped authority lease; pure model, not production code."""

    def __init__(self, max_precise_age_ms: int = 96):
        self.max_precise_age_ms = max_precise_age_ms
        self.current_session = 0
        self.last_precise_sequence = 0
        self.precise_valid_until_source_ms = -10**12
        self.angle = None
        self.source = Source.NONE
        self.dropped_stale = 0
        self.dropped_session = 0
        self.dropped_sequence = 0
        self.pending_public = None  # (angle, source_ms)

    def start_precise_session(self, session: int):
        self.current_session = session
        self.last_precise_sequence = 0
        self.precise_valid_until_source_ms = -10**12

    def stop_precise_session(self, session: int):
        if session == self.current_session:
            self.current_session += 1  # invalidate late callbacks from old session
            self.last_precise_sequence = 0
            self.precise_valid_until_source_ms = -10**12
            if self.source in (Source.PRECISE, Source.SYNTHETIC_ENDPOINT):
                self.source = Source.NONE

    def precise(self, sample: Sample):
        if sample.session != self.current_session:
            self.dropped_session += 1
            return False
        if sample.sequence <= self.last_precise_sequence:
            self.dropped_sequence += 1
            return False
        age = sample.receive_uptime_ms - sample.source_uptime_ms
        if age < 0 or age > self.max_precise_age_ms:
            self.dropped_stale += 1
            return False
        self.last_precise_sequence = sample.sequence
        self.precise_valid_until_source_ms = sample.source_uptime_ms + self.max_precise_age_ms
        self.angle = sample.angle
        self.source = sample.source
        return True

    def public(self, angle: float, now_ms: int):
        # Preserve the latest public event even while precise authority is alive.
        # On Fold7 the fallback sensor may be on-change/coarse; throwing this event
        # away can leave no later callback to recover from a silent precise feed.
        self.pending_public = (angle, now_ms)
        if now_ms <= self.precise_valid_until_source_ms:
            return False
        self.angle = angle
        self.source = Source.PUBLIC
        self.pending_public = None
        return True

    def expire_precise(self, now_ms: int, public_max_age_ms: int = 3000):
        if now_ms <= self.precise_valid_until_source_ms:
            return False
        if self.pending_public is None:
            return False
        angle, source_ms = self.pending_public
        if now_ms - source_ms > public_max_age_ms:
            self.pending_public = None
            return False
        self.angle = angle
        self.source = Source.PUBLIC
        self.pending_public = None
        return True


def sample(source, session, seq, angle, src, recv):
    return Sample(source, session, seq, angle, src, recv)


def scenario_delayed_current_precise():
    b = BaselineAuthority()
    g = Gen2AngleAuthority(96)
    g.start_precise_session(1)
    stale = sample(Source.PRECISE, 1, 1, 8.0, 0, 500)
    b_ok = b.precise(stale)
    g_ok = g.precise(stale)
    b_pub = b.public(90.0, 550)
    g_pub = g.public(90.0, 550)
    assert b_ok and not g_ok
    assert not b_pub and g_pub
    assert b.angle == 8.0 and g.angle == 90.0


def scenario_fresh_precise_wins():
    b = BaselineAuthority()
    g = Gen2AngleAuthority(96)
    g.start_precise_session(7)
    fresh = sample(Source.PRECISE, 7, 1, 42.0, 1000, 1010)
    assert b.precise(fresh)
    assert g.precise(fresh)
    assert not b.public(90.0, 1020)
    assert not g.public(90.0, 1020)
    assert b.angle == g.angle == 42.0


def scenario_public_fallback_after_source_lease_expires():
    b = BaselineAuthority()
    g = Gen2AngleAuthority(96)
    g.start_precise_session(1)
    s = sample(Source.PRECISE, 1, 1, 10.0, 1000, 1010)
    b.precise(s); g.precise(s)
    # 250ms later: precise source is no longer fresh by its 96 ms acquisition SLA,
    # but baseline still suppresses public sensor for nearly three seconds.
    assert not b.public(90.0, 1250)
    assert g.public(90.0, 1250)
    assert g.angle == 90.0



def scenario_suppressed_on_change_event_is_not_lost():
    b = BaselineAuthority()
    g = Gen2AngleAuthority(96)
    g.start_precise_session(1)
    fresh = sample(Source.PRECISE, 1, 1, 5.0, 0, 5)
    b.precise(fresh); g.precise(fresh)
    # The public/coarse sensor reports once while precise authority is still alive.
    # Baseline drops it before even recording a fallback candidate.
    assert not b.public(90.0, 50)
    assert not g.public(90.0, 50)
    # Precise feed then dies silently and the hinge stays still. The baseline
    # clear only drops the boolean, so there is no callback to repair angle=5.
    b.clear_external()
    assert b.angle == 5.0
    # Proposed authority expires the precise lease and promotes the buffered
    # public event without requiring another physical hinge movement.
    assert g.expire_precise(100)
    assert g.angle == 90.0 and g.source == Source.PUBLIC


def scenario_old_session_rejected():
    g = Gen2AngleAuthority(96)
    g.start_precise_session(4)
    assert g.precise(sample(Source.PRECISE, 4, 1, 3.0, 100, 105))
    g.stop_precise_session(4)
    g.start_precise_session(6)
    assert not g.precise(sample(Source.PRECISE, 4, 2, 7.0, 110, 115))
    assert g.dropped_session == 1


def scenario_duplicate_sequence_rejected():
    g = Gen2AngleAuthority(96)
    g.start_precise_session(1)
    assert g.precise(sample(Source.PRECISE, 1, 1, 5.0, 100, 101))
    assert not g.precise(sample(Source.PRECISE, 1, 1, 8.0, 102, 103))
    assert g.angle == 5.0


def scenario_synthetic_endpoint_is_session_scoped():
    g = Gen2AngleAuthority(96)
    g.start_precise_session(2)
    assert g.precise(sample(Source.SYNTHETIC_ENDPOINT, 2, 1, 0.0, 100, 101))
    g.stop_precise_session(2)
    g.start_precise_session(4)
    assert not g.precise(sample(Source.SYNTHETIC_ENDPOINT, 2, 2, 180.0, 110, 111))


def scenario_negative_age_rejected():
    g = Gen2AngleAuthority(96)
    g.start_precise_session(1)
    assert not g.precise(sample(Source.PRECISE, 1, 1, 10.0, 200, 190))


def scenario_boundary_age():
    g = Gen2AngleAuthority(96)
    g.start_precise_session(1)
    assert g.precise(sample(Source.PRECISE, 1, 1, 15.0, 1000, 1096))
    # Lease expires from source time, not receive time.
    assert not g.public(90.0, 1096)
    assert g.public(90.0, 1097)


def scenario_monotonic_latest_precise():
    g = Gen2AngleAuthority(96)
    g.start_precise_session(1)
    for seq, angle in enumerate((1.0, 2.0, 3.0, 4.0), start=1):
        assert g.precise(sample(Source.PRECISE, 1, seq, angle, 1000+seq*8, 1001+seq*8))
    assert g.angle == 4.0


def scenario_random_adversarial(seed=731, n=100_000):
    rnd = random.Random(seed)
    g = Gen2AngleAuthority(96)
    session = 1
    g.start_precise_session(session)
    accepted_seq = 0
    for i in range(n):
        kind = rnd.randrange(10)
        now = i * 3 + 1000
        if kind == 0:
            old = session
            g.stop_precise_session(old)
            session += 2
            g.start_precise_session(session)
            accepted_seq = 0
        elif kind < 7:
            # Mix fresh, delayed, old-session, duplicate/out-of-order precise samples.
            candidate_session = session if rnd.random() > 0.12 else max(1, session - 2)
            if rnd.random() < 0.15 and accepted_seq:
                seq = accepted_seq
            else:
                seq = accepted_seq + 1
            lag = rnd.choice([0, 2, 8, 40, 96, 97, 150, 500])
            src = now - lag
            s = sample(Source.PRECISE, candidate_session, seq, float(rnd.randrange(181)), src, now)
            ok = g.precise(s)
            if ok:
                assert candidate_session == session
                assert seq > accepted_seq
                assert 0 <= now - src <= 96
                accepted_seq = seq
        else:
            prior = g.angle
            ok = g.public(float(rnd.choice([0, 90, 180])), now)
            if now <= g.precise_valid_until_source_ms:
                assert not ok and g.angle == prior
    assert g.dropped_stale + g.dropped_session + g.dropped_sequence > 0


def run():
    cases = [
        scenario_delayed_current_precise,
        scenario_fresh_precise_wins,
        scenario_public_fallback_after_source_lease_expires,
        scenario_suppressed_on_change_event_is_not_lost,
        scenario_old_session_rejected,
        scenario_duplicate_sequence_rejected,
        scenario_synthetic_endpoint_is_session_scoped,
        scenario_negative_age_rejected,
        scenario_boundary_age,
        scenario_monotonic_latest_precise,
        scenario_random_adversarial,
    ]
    for fn in cases:
        fn()
        print(f"PASS {fn.__name__}")
    print(f"PASS {len(cases)}/{len(cases)} scenarios")


if __name__ == '__main__':
    run()
