package duoopen.rnd.terminalhandoff

import kotlin.random.Random

private fun assertThat(condition: Boolean, message: String) {
    if (!condition) error(message)
}

private fun id(cycle: Long = 1, generation: Long = 10, host: Long = 7, attempt: Long = 4) =
    TerminalNativeHandoffOwner.Identity(
        serviceEpoch = 99,
        closeCycleId = cycle,
        transitionGeneration = generation,
        hostLeaseId = host,
        visualAttemptId = attempt,
    )

private fun currentMainImmediateReleaseRisk(nativeCover: Boolean, angleDeg: Float): Boolean =
    nativeCover && angleDeg <= 12f

private fun testBaselineGapExists() {
    val nativeTopologyArrivesBeforeDestinationPresent = true
    val currentMainReleases = currentMainImmediateReleaseRisk(true, 4f)
    assertThat(nativeTopologyArrivesBeforeDestinationPresent && currentMainReleases,
        "baseline should expose a release-before-destination-present ordering")
}

private fun testLogicalNativeDoesNotRelease() {
    val o = TerminalNativeHandoffOwner(requiredPresentedBarriers = 2)
    val identity = id()
    o.beginVisual(identity)
    val r = o.observeNativeTopology(identity, nativeCover = true, angleDeg = 4f)
    assertThat(o.state == TerminalNativeHandoffOwner.State.NATIVE_PENDING, "must retain visual")
    assertThat(r.commands.single() is TerminalNativeHandoffOwner.Command.PresentBarrier, "barrier required")
}

private fun testTwoBarriersThenFadeThenRelease() {
    val o = TerminalNativeHandoffOwner(requiredPresentedBarriers = 2)
    val identity = id()
    o.beginVisual(identity)
    val token = (o.observeNativeTopology(identity, true, 4f).commands.single()
        as TerminalNativeHandoffOwner.Command.PresentBarrier).token

    val first = o.onBarrierPresented(token, 1)
    assertThat(o.state == TerminalNativeHandoffOwner.State.NATIVE_PENDING, "one barrier insufficient")
    assertThat(first.commands.single() is TerminalNativeHandoffOwner.Command.PresentBarrier, "second barrier requested")

    val second = o.onBarrierPresented(token, 2)
    assertThat(o.state == TerminalNativeHandoffOwner.State.FADING, "barriers should enter fade")
    assertThat(second.commands.single() is TerminalNativeHandoffOwner.Command.FadeOverlayToNative, "fade required")

    val done = o.onFadePresented(token)
    assertThat(o.state == TerminalNativeHandoffOwner.State.RELEASED_CLEAN, "fade presentation gates clean release")
    val release = done.commands.single() as TerminalNativeHandoffOwner.Command.ReleaseDuoVisualAndSecondary
    assertThat(!release.degraded, "normal release must be clean")
}

private fun testStaleBarrierCannotReleaseNewCycle() {
    val o = TerminalNativeHandoffOwner(1)
    val oldId = id(cycle = 1)
    o.beginVisual(oldId)
    val oldToken = (o.observeNativeTopology(oldId, true, 2f).commands.single()
        as TerminalNativeHandoffOwner.Command.PresentBarrier).token

    val newId = id(cycle = 2, generation = 20, attempt = 9)
    o.beginVisual(newId)
    o.observeNativeTopology(newId, true, 2f)

    assertThat(!o.onBarrierPresented(oldToken, 1).accepted, "stale cycle barrier must be inert")
    assertThat(o.state == TerminalNativeHandoffOwner.State.NATIVE_PENDING, "new cycle must remain owned")
}

private fun testHostReplacementMakesOldTokenInert() {
    val o = TerminalNativeHandoffOwner(1)
    val first = id(host = 7)
    o.beginVisual(first)
    val token = (o.observeNativeTopology(first, true, 2f).commands.single()
        as TerminalNativeHandoffOwner.Command.PresentBarrier).token

    val replacement = id(host = 8, attempt = 5)
    o.beginVisual(replacement)
    assertThat(!o.onBarrierPresented(token, 1).accepted, "old host callback must be inert")
}

private fun testTopologyFlapCancelsLanding() {
    val o = TerminalNativeHandoffOwner(2)
    val identity = id()
    o.beginVisual(identity)
    val token = (o.observeNativeTopology(identity, true, 3f).commands.single()
        as TerminalNativeHandoffOwner.Command.PresentBarrier).token
    o.onBarrierPresented(token, 1)
    o.observeNativeTopology(identity, nativeCover = false, angleDeg = 3f)

    assertThat(o.state == TerminalNativeHandoffOwner.State.VISUAL_ACTIVE, "topology flap must return visual ownership")
    assertThat(!o.onBarrierPresented(token, 2).accepted, "cancelled token must be stale")
}

private fun testOpeningReversalCancelsLanding() {
    val o = TerminalNativeHandoffOwner(1)
    val identity = id()
    o.beginVisual(identity)
    val token = (o.observeNativeTopology(identity, true, 2f).commands.single()
        as TerminalNativeHandoffOwner.Command.PresentBarrier).token
    o.openingReversal(identity)
    assertThat(o.state == TerminalNativeHandoffOwner.State.VISUAL_ACTIVE, "reversal must cancel handoff")
    assertThat(!o.onBarrierPresented(token, 1).accepted, "late terminal callback after reversal must be inert")
}

private fun testDuplicateBarrierIsIdempotentlyRejected() {
    val o = TerminalNativeHandoffOwner(2)
    val identity = id()
    o.beginVisual(identity)
    val token = (o.observeNativeTopology(identity, true, 2f).commands.single()
        as TerminalNativeHandoffOwner.Command.PresentBarrier).token
    assertThat(o.onBarrierPresented(token, 1).accepted, "first accepted")
    assertThat(!o.onBarrierPresented(token, 1).accepted, "duplicate ordinal rejected")
    assertThat(o.presentedBarrierCount == 1, "duplicate must not advance evidence")
}

private fun testFadeCannotReleaseBeforeLandingBarriers() {
    val o = TerminalNativeHandoffOwner(2)
    val identity = id()
    o.beginVisual(identity)
    val token = (o.observeNativeTopology(identity, true, 1f).commands.single()
        as TerminalNativeHandoffOwner.Command.PresentBarrier).token

    val premature = o.onFadePresented(token)
    assertThat(!premature.accepted, "fade completion before landing barriers must be rejected")
    assertThat(o.state == TerminalNativeHandoffOwner.State.NATIVE_PENDING, "Duo visual must remain retained")
}

private fun testTimeoutIsExplicitlyDegraded() {
    val o = TerminalNativeHandoffOwner(2)
    val identity = id()
    o.beginVisual(identity)
    val token = (o.observeNativeTopology(identity, true, 1f).commands.single()
        as TerminalNativeHandoffOwner.Command.PresentBarrier).token
    val timed = o.onWatchdogTimeout(token)
    assertThat(o.state == TerminalNativeHandoffOwner.State.RELEASED_DEGRADED_TIMEOUT, "timeout should have separate terminal state")
    val release = timed.commands.single() as TerminalNativeHandoffOwner.Command.ReleaseDuoVisualAndSecondary
    assertThat(release.degraded, "timeout release must remain labeled degraded")
}

private fun testRandomizedAdversarialStream() {
    val random = Random(0xD007)
    val o = TerminalNativeHandoffOwner(requiredPresentedBarriers = 2)
    var cycle = 0L
    var identity = id(cycle = ++cycle)
    o.beginVisual(identity)
    var currentToken: TerminalNativeHandoffOwner.Token? = null

    repeat(100_000) { step ->
        when (random.nextInt(10)) {
            0 -> {
                identity = id(cycle = ++cycle, generation = 10 + cycle, host = 7 + (cycle % 3), attempt = 4 + cycle)
                o.beginVisual(identity)
                currentToken = null
            }
            1, 2 -> {
                val r = o.observeNativeTopology(identity, true, random.nextDouble(0.0, 12.0).toFloat())
                val c = r.commands.firstOrNull()
                if (c is TerminalNativeHandoffOwner.Command.PresentBarrier) currentToken = c.token
            }
            3 -> o.observeNativeTopology(identity, false, 5f)
            4 -> o.openingReversal(identity)
            5, 6 -> currentToken?.let { token ->
                val ordinal = if (random.nextBoolean()) o.presentedBarrierCount + 1 else random.nextInt(1, 4)
                val r = o.onBarrierPresented(token, ordinal)
                val c = r.commands.firstOrNull()
                if (c is TerminalNativeHandoffOwner.Command.PresentBarrier) currentToken = c.token
            }
            7 -> currentToken?.let { token ->
                val beforeBarriers = o.presentedBarrierCount
                val beforeNativeStable = o.nativeTopologyStable
                val r = o.onFadePresented(token)
                val cleanRelease = r.commands.filterIsInstance<TerminalNativeHandoffOwner.Command.ReleaseDuoVisualAndSecondary>()
                    .firstOrNull { !it.degraded }
                if (cleanRelease != null) {
                    assertThat(beforeNativeStable, "clean release requires native topology at emission step=$step")
                    assertThat(beforeBarriers >= 2, "clean release requires barrier evidence at emission step=$step")
                    assertThat(o.state == TerminalNativeHandoffOwner.State.RELEASED_CLEAN, "clean release state mismatch at step=$step")
                }
            }
            8 -> currentToken?.let { token ->
                if (random.nextInt(20) == 0) {
                    val r = o.onWatchdogTimeout(token)
                    val degradedRelease = r.commands.filterIsInstance<TerminalNativeHandoffOwner.Command.ReleaseDuoVisualAndSecondary>()
                        .firstOrNull { it.degraded }
                    if (degradedRelease != null) {
                        assertThat(o.state == TerminalNativeHandoffOwner.State.RELEASED_DEGRADED_TIMEOUT, "timeout release must stay degraded at step=$step")
                    }
                }
            }
            9 -> {
                // Deliberately synthesize stale callback identity.
                val stale = TerminalNativeHandoffOwner.Token(
                    id(cycle = (cycle - 1).coerceAtLeast(0), generation = 1, host = 1, attempt = 1),
                    handoffSequence = 1,
                )
                o.onBarrierPresented(stale, 1)
                o.onFadePresented(stale)
            }
        }

    }
}

fun main() {
    val tests = listOf(
        ::testBaselineGapExists,
        ::testLogicalNativeDoesNotRelease,
        ::testTwoBarriersThenFadeThenRelease,
        ::testStaleBarrierCannotReleaseNewCycle,
        ::testHostReplacementMakesOldTokenInert,
        ::testTopologyFlapCancelsLanding,
        ::testOpeningReversalCancelsLanding,
        ::testDuplicateBarrierIsIdempotentlyRejected,
        ::testFadeCannotReleaseBeforeLandingBarriers,
        ::testTimeoutIsExplicitlyDegraded,
        ::testRandomizedAdversarialStream,
    )
    var passed = 0
    for (test in tests) {
        test()
        passed++
        println("PASS ${test.name}")
    }
    println("PASS_COUNT=$passed/${tests.size}")
    println("RANDOM_EVENTS=100000")
}
