package duoopen.rnd.terminalhandoff

/**
 * Pure model for a Gen2 terminal cover handoff.
 *
 * It intentionally models only the ownership barrier between an already-visible
 * Duo cover visual and Samsung/native cover steady-state. Android side effects
 * (SurfaceControl transactions, present fences, host detach, privileged lease
 * release) are represented as Commands emitted by this owner.
 */
class TerminalNativeHandoffOwner(
    private val requiredPresentedBarriers: Int = 2,
) {
    init {
        require(requiredPresentedBarriers >= 1)
    }

    data class Identity(
        val serviceEpoch: Long,
        val closeCycleId: Long,
        val transitionGeneration: Long,
        val hostLeaseId: Long,
        val visualAttemptId: Long,
    )

    data class Token(
        val identity: Identity,
        val handoffSequence: Long,
    )

    enum class State {
        IDLE,
        VISUAL_ACTIVE,
        NATIVE_PENDING,
        FADING,
        RELEASED_CLEAN,
        RELEASED_DEGRADED_TIMEOUT,
    }

    sealed interface Command {
        data class PresentBarrier(val token: Token, val ordinal: Int) : Command
        data class FadeOverlayToNative(val token: Token) : Command
        data class ReleaseDuoVisualAndSecondary(val token: Token, val degraded: Boolean) : Command
    }

    data class Result(
        val accepted: Boolean,
        val reason: String,
        val commands: List<Command> = emptyList(),
    )

    var state: State = State.IDLE
        private set

    var currentIdentity: Identity? = null
        private set

    var currentToken: Token? = null
        private set

    var nativeTopologyStable: Boolean = false
        private set

    var presentedBarrierCount: Int = 0
        private set

    private var nextHandoffSequence = 0L

    fun beginVisual(identity: Identity): Result {
        currentIdentity = identity
        currentToken = null
        nativeTopologyStable = false
        presentedBarrierCount = 0
        state = State.VISUAL_ACTIVE
        return Result(true, "visual-active")
    }

    /**
     * Logical/default native-cover topology is an admission signal only.
     * It MUST NOT directly release Duo's terminal visual.
     */
    fun observeNativeTopology(
        identity: Identity,
        nativeCover: Boolean,
        angleDeg: Float,
        maxNativeAngleDeg: Float = 12f,
    ): Result {
        if (identity != currentIdentity) return Result(false, "stale-identity")

        if (!nativeCover || !angleDeg.isFinite() || angleDeg > maxNativeAngleDeg) {
            return nativeTopologyLost(identity, "not-native-or-angle")
        }

        nativeTopologyStable = true

        return when (state) {
            State.VISUAL_ACTIVE -> {
                val token = Token(identity, ++nextHandoffSequence)
                currentToken = token
                presentedBarrierCount = 0
                state = State.NATIVE_PENDING
                Result(
                    true,
                    "native-admitted-retain-duo",
                    listOf(Command.PresentBarrier(token, ordinal = 1)),
                )
            }

            State.NATIVE_PENDING,
            State.FADING -> Result(true, "native-still-stable")

            State.RELEASED_CLEAN,
            State.RELEASED_DEGRADED_TIMEOUT -> Result(true, "already-released")

            State.IDLE -> Result(false, "no-active-visual")
        }
    }

    fun onBarrierPresented(token: Token, ordinal: Int): Result {
        if (!owns(token)) return Result(false, "stale-token")
        if (state != State.NATIVE_PENDING) return Result(false, "wrong-state:$state")
        if (!nativeTopologyStable) return Result(false, "native-not-stable")
        val expected = presentedBarrierCount + 1
        if (ordinal != expected) return Result(false, "unexpected-barrier:$ordinal expected=$expected")

        presentedBarrierCount++
        if (presentedBarrierCount < requiredPresentedBarriers) {
            return Result(
                true,
                "barrier-presented:$presentedBarrierCount",
                listOf(Command.PresentBarrier(token, ordinal = presentedBarrierCount + 1)),
            )
        }

        state = State.FADING
        return Result(
            true,
            "landing-barriers-satisfied",
            listOf(Command.FadeOverlayToNative(token)),
        )
    }

    /** Final clean release happens only after the alpha/fade transaction itself presented. */
    fun onFadePresented(token: Token): Result {
        if (!owns(token)) return Result(false, "stale-token")
        if (state != State.FADING) return Result(false, "wrong-state:$state")
        if (!nativeTopologyStable) return Result(false, "native-not-stable")

        state = State.RELEASED_CLEAN
        return Result(
            true,
            "clean-release-after-presented-fade",
            listOf(Command.ReleaseDuoVisualAndSecondary(token, degraded = false)),
        )
    }

    /**
     * A topology flap or opening reversal cancels the landing attempt. The
     * current visual remains authoritative; stale barrier/fade callbacks die by token.
     */
    fun nativeTopologyLost(identity: Identity, reason: String = "topology-lost"): Result {
        if (identity != currentIdentity) return Result(false, "stale-identity")
        nativeTopologyStable = false
        if (state == State.NATIVE_PENDING || state == State.FADING) {
            currentToken = null
            presentedBarrierCount = 0
            state = State.VISUAL_ACTIVE
            return Result(true, "handoff-cancelled:$reason")
        }
        return Result(true, "native-not-held:$reason")
    }

    fun openingReversal(identity: Identity): Result =
        nativeTopologyLost(identity, "opening-reversal")

    /**
     * Bounded fail-open escape hatch. Integration chooses/tunes the watchdog
     * from Fold7 device measurements. It is intentionally not a clean release.
     */
    fun onWatchdogTimeout(token: Token): Result {
        if (!owns(token)) return Result(false, "stale-token")
        if (!nativeTopologyStable) return Result(false, "native-not-stable")
        if (state != State.NATIVE_PENDING && state != State.FADING) {
            return Result(false, "wrong-state:$state")
        }

        state = State.RELEASED_DEGRADED_TIMEOUT
        return Result(
            true,
            "degraded-timeout-release",
            listOf(Command.ReleaseDuoVisualAndSecondary(token, degraded = true)),
        )
    }

    private fun owns(token: Token): Boolean =
        token == currentToken && token.identity == currentIdentity
}
