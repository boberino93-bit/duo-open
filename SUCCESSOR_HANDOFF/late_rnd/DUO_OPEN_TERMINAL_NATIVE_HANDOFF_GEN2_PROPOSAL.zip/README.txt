Duo Open Gen3 R&D proposal: terminal native-cover handoff / landing lease

This package is R&D ONLY. It does not authorize or contain production deployment changes.
It models the boundary between an already-visible Duo cover visual and Samsung/native cover steady state.

Baseline repository:
  boberino93-bit/duo-open
  45bb0d326899c0e08415928224cfea0ff58d2d4e

Core proposal:
  Treat native/default cover topology as admission to a pending terminal handoff, not proof that native content has presented.
  Retain Duo's terminal visual across a small number of presentation-completed barriers, then present a fade-to-native transaction.
  Only after that fade is presented may the visual host, close-cycle content, and privileged secondary lease be released cleanly.

Important limitation:
  An overlay transaction completion proves that transaction was presented. It does not prove Samsung Launcher/SystemUI produced a fresh matching buffer beneath it. This is a compositor landing window, not native-content provenance proof.

Contents:
  TerminalNativeHandoffModel.kt
  TerminalNativeHandoffModelTest.kt
  TEST_OUTPUT_INITIAL_FAIL.txt
  TEST_OUTPUT.txt
  DUO_OPEN_TERMINAL_NATIVE_HANDOFF_GEN2_RND_HANDOFF.txt
  BASELINE-SHA.txt
  FINAL-MAIN-SHA.txt
  SHA256SUMS.txt
