DUO OPEN GEN3 TERMINAL HANDOFF BUDGET R&D BUNDLE

Files:
- DUO_OPEN_TERMINAL_HANDOFF_BUDGET_GEN3_RND_HANDOFF.txt : full findings/design/validation handoff
- SOURCE_EVIDENCE.txt : current-main and official Android evidence ledger
- terminal_handoff_budget_model.py : pure timing/evidence guard model
- TEST_RESULTS.txt : fixed + 100k adversarial model output
- SHA256SUMS.txt : generated after FINAL_MAIN_SHA revalidation

Authority: R&D only. No production changes are contained or authorized.
