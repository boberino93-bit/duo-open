#!/usr/bin/env python3
"""Pure model for Duo Open terminal native-cover handoff timing/evidence semantics.

R&D only. No Android/device integration and no production writes.

The key distinction is intentional:
- route/default/power facts are topology evidence;
- View frame-commit is submission evidence;
- a SurfaceControl transaction-completed callback is exact evidence for THAT transaction;
- none of those public app-visible signals proves that another process's native Samsung
  cover content has itself been presented.

A terminal guard may therefore release early only on an exact native-content evidence
source if one is later discovered/implemented. Otherwise it releases on a bounded,
refresh-relative deadline. Proxy evidence can be logged but cannot release the guard.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
import math
import random


class Evidence(Enum):
    ROUTE_OBSERVED = auto()
    VIEW_FRAME_COMMIT = auto()
    DUO_TRANSACTION_PRESENTED = auto()
    NATIVE_CONTENT_PRESENTED = auto()


@dataclass(frozen=True)
class Owner:
    service_epoch: int
    close_cycle_id: int
    handoff_sequence: int


class TerminalHandoffGuard:
    """Exact owner + bounded fallback.

    grace_frames is an experiment parameter, not a production-proven constant.
    1/2/3-frame sweeps should be run on physical Fold7 hardware; 2 is a useful
    starting candidate because it allows one complete compositor opportunity after
    an arbitrarily-phased route observation while keeping the hold bounded.
    """

    def __init__(self, grace_frames: int = 2, max_frames: int = 3):
        if grace_frames < 1:
            raise ValueError("grace_frames must be >= 1")
        if max_frames < 1:
            raise ValueError("max_frames must be >= 1")
        self.grace_frames = min(grace_frames, max_frames)
        self.max_frames = max_frames
        self.owner: Owner | None = None
        self.started_ns: int | None = None
        self.deadline_ns: int | None = None
        self.released = False
        self.release_reason: str | None = None
        self.release_ns: int | None = None

    @staticmethod
    def refresh_period_ns(refresh_hz: float) -> int:
        if not math.isfinite(refresh_hz) or refresh_hz <= 0:
            raise ValueError("refresh_hz must be finite and > 0")
        return math.ceil(1_000_000_000 / refresh_hz)

    def begin(self, owner: Owner, now_ns: int, refresh_hz: float) -> None:
        period = self.refresh_period_ns(refresh_hz)
        self.owner = owner
        self.started_ns = now_ns
        self.deadline_ns = now_ns + self.grace_frames * period
        self.released = False
        self.release_reason = None
        self.release_ns = None

    def observe(self, owner: Owner, evidence: Evidence, now_ns: int) -> bool:
        if self.released or owner != self.owner:
            return False

        # Only a signal explicitly tied to native destination content may end the
        # guard early. Public app-owned callbacks are not cross-process proof.
        if evidence is Evidence.NATIVE_CONTENT_PRESENTED:
            self._release("exact-native-presented", now_ns)
            return True
        return False

    def tick(self, now_ns: int) -> bool:
        if self.released or self.owner is None or self.deadline_ns is None:
            return False
        if now_ns >= self.deadline_ns:
            self._release("bounded-deadline", self.deadline_ns)
            return True
        return False

    def cancel(self, owner: Owner, now_ns: int, reason: str) -> bool:
        if self.released or owner != self.owner:
            return False
        self._release(f"cancel:{reason}", now_ns)
        return True

    def _release(self, reason: str, at_ns: int) -> None:
        self.released = True
        self.release_reason = reason
        self.release_ns = at_ns


def fixed_tests() -> list[str]:
    passed: list[str] = []

    # Public proxy evidence is deliberately insufficient.
    g = TerminalHandoffGuard(grace_frames=2)
    owner = Owner(1, 10, 1)
    g.begin(owner, 0, 120.0)
    assert not g.observe(owner, Evidence.ROUTE_OBSERVED, 1_000_000)
    assert not g.observe(owner, Evidence.VIEW_FRAME_COMMIT, 2_000_000)
    assert not g.observe(owner, Evidence.DUO_TRANSACTION_PRESENTED, 3_000_000)
    assert not g.released
    passed.append("proxy evidence cannot release")

    # Exact-native evidence, if ever available, can end the hold immediately.
    assert g.observe(owner, Evidence.NATIVE_CONTENT_PRESENTED, 4_000_000)
    assert g.release_reason == "exact-native-presented"
    passed.append("exact native evidence releases")

    # Refresh-relative deadline is deterministic and bounded.
    g = TerminalHandoffGuard(grace_frames=2)
    owner = Owner(2, 20, 1)
    g.begin(owner, 100, 120.0)
    expected = 100 + 2 * math.ceil(1_000_000_000 / 120.0)
    assert g.deadline_ns == expected
    assert not g.tick(expected - 1)
    assert g.tick(expected)
    assert g.release_ns == expected
    passed.append("120Hz two-frame deadline bounded")

    # Same rule scales to destination refresh rate rather than fixed milliseconds.
    g = TerminalHandoffGuard(grace_frames=2)
    g.begin(Owner(2, 21, 1), 0, 60.0)
    assert g.deadline_ns == 2 * math.ceil(1_000_000_000 / 60.0)
    passed.append("60Hz deadline scales with refresh")

    # Old-cycle evidence cannot release a replacement owner.
    g = TerminalHandoffGuard(grace_frames=2)
    old = Owner(3, 30, 1)
    new = Owner(3, 31, 2)
    g.begin(old, 0, 120.0)
    g.begin(new, 1_000_000, 120.0)
    assert not g.observe(old, Evidence.NATIVE_CONTENT_PRESENTED, 2_000_000)
    assert not g.released
    passed.append("stale prior owner rejected")

    # Cancellation is explicit for semantic reversal / privilege loss / shutdown.
    assert g.cancel(new, 3_000_000, "authority-loss")
    assert g.release_reason == "cancel:authority-loss"
    passed.append("current owner cancellation explicit")

    # Counterexample showing why an app-owned present callback cannot be used as
    # proof of native landing. This is a logical/API-contract counterexample, not
    # a measured Fold7 latency distribution.
    route_ns = 0
    duo_present_ns = 4_000_000
    native_present_ns = 20_000_000
    premature_gap_ns = native_present_ns - duo_present_ns
    assert route_ns < duo_present_ns < native_present_ns
    assert premature_gap_ns == 16_000_000
    passed.append("proxy-release counterexample remains possible")

    # 1/2/3 frame experiment matrix values for common Fold7-relevant rates.
    expected_ms = {
        60: (16.667, 33.333, 50.000),
        90: (11.111, 22.222, 33.333),
        120: (8.333, 16.667, 25.000),
    }
    for hz, values in expected_ms.items():
        p = 1000.0 / hz
        actual = tuple(round(p * n, 3) for n in (1, 2, 3))
        assert actual == values
    passed.append("1/2/3-frame sweep matrix stable")

    return passed


def adversarial_test(iterations: int = 100_000, seed: int = 0xD00F7) -> None:
    rng = random.Random(seed)
    for _ in range(iterations):
        grace = rng.choice((1, 2, 3))
        hz = rng.choice((60.0, 90.0, 120.0))
        g = TerminalHandoffGuard(grace_frames=grace, max_frames=3)
        current = Owner(rng.randint(1, 10), rng.randint(1, 100_000), 1)
        now = rng.randint(0, 1_000_000_000)
        g.begin(current, now, hz)

        for _ in range(rng.randint(2, 20)):
            event_time = now + rng.randint(0, 100_000_000)
            op = rng.choice(
                (
                    "route",
                    "frame_commit",
                    "duo_present",
                    "exact_native",
                    "stale_exact",
                    "tick",
                    "replace",
                    "cancel",
                )
            )

            if op == "route":
                before = g.released
                g.observe(current, Evidence.ROUTE_OBSERVED, event_time)
                assert g.released == before
            elif op == "frame_commit":
                before = g.released
                g.observe(current, Evidence.VIEW_FRAME_COMMIT, event_time)
                assert g.released == before
            elif op == "duo_present":
                before = g.released
                g.observe(current, Evidence.DUO_TRANSACTION_PRESENTED, event_time)
                assert g.released == before
            elif op == "exact_native" and not g.released:
                assert g.observe(current, Evidence.NATIVE_CONTENT_PRESENTED, event_time)
                assert g.release_reason == "exact-native-presented"
            elif op == "stale_exact":
                stale = Owner(current.service_epoch, max(0, current.close_cycle_id - 1), 0)
                before = (g.released, g.release_reason, g.release_ns)
                assert not g.observe(stale, Evidence.NATIVE_CONTENT_PRESENTED, event_time)
                assert (g.released, g.release_reason, g.release_ns) == before
            elif op == "tick":
                deadline = g.deadline_ns
                g.tick(event_time)
                if not g.released and deadline is not None:
                    assert event_time < deadline
            elif op == "replace":
                current = Owner(
                    current.service_epoch,
                    current.close_cycle_id + 1,
                    current.handoff_sequence + 1,
                )
                now = event_time
                g.begin(current, now, hz)
                assert not g.released
            elif op == "cancel" and not g.released:
                assert g.cancel(current, event_time, "semantic-or-authority")
                assert g.release_reason.startswith("cancel:")

            if g.released:
                assert g.release_reason is not None
                assert g.release_reason.startswith(
                    ("exact-native-presented", "bounded-deadline", "cancel:")
                )


def main() -> None:
    passed = fixed_tests()
    adversarial_test()
    print(f"fixed_tests={len(passed)}/{len(passed)}")
    for name in passed:
        print(f"PASS {name}")
    print("adversarial=PASS iterations=100000 seed=0xD00F7")
    print("experiment_matrix_ms:")
    for hz in (60, 90, 120):
        p = 1000.0 / hz
        print(f"  {hz}Hz: 1f={p:.3f} 2f={2*p:.3f} 3f={3*p:.3f}")


if __name__ == "__main__":
    main()
