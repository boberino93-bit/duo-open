from dataclasses import dataclass
import random

@dataclass(frozen=True)
class Evidence:
    service_epoch: int
    open_cycle_id: int
    route_epoch: int
    attempt_sequence: int
    captured_uptime_ms: int

class Baseline:
    def __init__(self):
        self.cover_visual = True
        self.inner_active = False
        self.angle = 0.0
        self.inner_evidence = False

    def sample(self, angle: float, inner_active: bool):
        self.angle = angle
        self.inner_active = inner_active
        # Current controller + service semantics reduced from main:
        # OPEN_INNER at >=172 + innerActive; OPEN_INNER removes opening latch/visual.
        if angle >= 172.0 and inner_active:
            self.cover_visual = False

class Gen2Owner:
    """Reduced terminal-opening handoff owner.

    Geometry/controller state may request OPEN_INNER, but the cover visual is
    released as a success handoff only when current-cycle current-route inner
    destination evidence exists. Loss of the cover route is a fail-open safety
    degradation: Duo cannot retain a cover visual on a route that no longer exists.
    """
    def __init__(self, service_epoch: int = 1):
        self.service_epoch = service_epoch
        self.next_cycle = 0
        self.open_cycle_id = 0
        self.route_epoch = 0
        self.cycle_started_ms = 0
        self.active = False
        self.cover_visual = False
        self.cover_route_available = False
        self.controller_wants_open = False
        self.best_evidence_seq = -1
        self.evidence_ready = False
        self.release_reason = None

    def begin_open(self, now_ms: int, cover_route_available: bool = True):
        self.next_cycle += 1
        self.open_cycle_id = self.next_cycle
        self.route_epoch += 1
        self.cycle_started_ms = now_ms
        self.active = True
        self.cover_visual = True
        self.cover_route_available = cover_route_available
        self.controller_wants_open = False
        self.best_evidence_seq = -1
        self.evidence_ready = False
        self.release_reason = None
        return self.open_cycle_id, self.route_epoch

    def controller_open_inner(self):
        if not self.active:
            return
        self.controller_wants_open = True
        self._reconcile()

    def route_remap(self, cover_route_available: bool = True):
        if not self.active:
            return
        self.route_epoch += 1
        self.cover_route_available = cover_route_available
        self.best_evidence_seq = -1
        self.evidence_ready = False
        self._reconcile()

    def set_cover_route_available(self, value: bool):
        if not self.active:
            return
        self.cover_route_available = value
        self._reconcile()

    def publish_evidence(self, ev: Evidence) -> bool:
        if not self.active:
            return False
        if ev.service_epoch != self.service_epoch:
            return False
        if ev.open_cycle_id != self.open_cycle_id:
            return False
        if ev.route_epoch != self.route_epoch:
            return False
        if ev.captured_uptime_ms < self.cycle_started_ms:
            return False
        if ev.attempt_sequence < self.best_evidence_seq:
            return False
        self.best_evidence_seq = ev.attempt_sequence
        self.evidence_ready = True
        self._reconcile()
        return True

    def capture_failed(self):
        # Failure is not readiness. Keep existing current-route evidence if one was
        # already proven; otherwise remain unready. Never use a timeout as success.
        self._reconcile()

    def watchdog_expired(self):
        # Preserve the existing bounded self-heal concept, but classify it as an
        # explicit degraded handoff rather than pretending readiness was proven.
        if self.active and self.cover_visual:
            self._release("watchdog-no-proof")

    def reversal(self):
        # End this opening attempt. A later opening gets a new cycle identity.
        self.active = False
        self.cover_visual = False
        self.controller_wants_open = False
        self.evidence_ready = False
        self.release_reason = "reversal"

    def service_restart(self, new_epoch: int):
        self.service_epoch = new_epoch
        self.active = False
        self.cover_visual = False
        self.evidence_ready = False
        self.release_reason = "service-restart"

    def _release(self, reason: str):
        # Terminal completion: once authority is handed away, later callbacks
        # cannot mutate the completed opening attempt.
        self.cover_visual = False
        self.release_reason = reason
        self.active = False

    def _reconcile(self):
        if not self.active or not self.cover_visual:
            return
        if not self.cover_route_available:
            self._release("cover-route-lost")
            return
        if self.controller_wants_open and self.evidence_ready:
            self._release("inner-ready")


def ev(owner: Gen2Owner, seq=1, t=None, *, cycle=None, route=None, epoch=None):
    return Evidence(
        service_epoch=owner.service_epoch if epoch is None else epoch,
        open_cycle_id=owner.open_cycle_id if cycle is None else cycle,
        route_epoch=owner.route_epoch if route is None else route,
        attempt_sequence=seq,
        captured_uptime_ms=(owner.cycle_started_ms + 1) if t is None else t,
    )


def run_tests():
    tests = []
    def test(name):
        def deco(fn):
            tests.append((name, fn)); return fn
        return deco

    @test("baseline_releases_on_topology_without_pixel_evidence")
    def _():
        b = Baseline(); b.sample(172.0, True)
        assert b.cover_visual is False and b.inner_evidence is False

    @test("gen2_holds_when_controller_open_but_inner_unproven")
    def _():
        o=Gen2Owner(); o.begin_open(100); o.controller_open_inner()
        assert o.cover_visual is True and o.release_reason is None

    @test("gen2_releases_after_current_inner_evidence")
    def _():
        o=Gen2Owner(); o.begin_open(100); o.controller_open_inner()
        assert o.publish_evidence(ev(o,1,110)); assert o.cover_visual is False
        assert o.release_reason == "inner-ready"

    @test("evidence_before_controller_open_is_retained_for_later_release")
    def _():
        o=Gen2Owner(); o.begin_open(100); assert o.publish_evidence(ev(o,1,105))
        assert o.cover_visual is True; o.controller_open_inner()
        assert o.cover_visual is False and o.release_reason == "inner-ready"

    @test("prior_cycle_evidence_is_rejected")
    def _():
        o=Gen2Owner(); c1,_=o.begin_open(100); old=ev(o,1,110)
        o.reversal(); o.begin_open(200); o.controller_open_inner()
        assert old.open_cycle_id == c1 and not o.publish_evidence(old)
        assert o.cover_visual is True

    @test("route_remap_invalidates_old_inner_evidence")
    def _():
        o=Gen2Owner(); o.begin_open(100); old=ev(o,1,110)
        o.route_remap(True); o.controller_open_inner()
        assert not o.publish_evidence(old); assert o.cover_visual is True
        assert o.publish_evidence(ev(o,2,120)); assert o.cover_visual is False

    @test("pre_cycle_capture_is_rejected")
    def _():
        o=Gen2Owner(); o.begin_open(100); o.controller_open_inner()
        assert not o.publish_evidence(ev(o,1,99)); assert o.cover_visual is True

    @test("old_service_epoch_is_rejected")
    def _():
        o=Gen2Owner(service_epoch=7); o.begin_open(100); o.controller_open_inner()
        assert not o.publish_evidence(ev(o,1,110,epoch=6)); assert o.cover_visual is True

    @test("capture_failure_is_not_success")
    def _():
        o=Gen2Owner(); o.begin_open(100); o.controller_open_inner(); o.capture_failed()
        assert o.cover_visual is True and o.release_reason is None

    @test("cover_route_loss_is_safe_fail_open")
    def _():
        o=Gen2Owner(); o.begin_open(100); o.controller_open_inner(); o.set_cover_route_available(False)
        assert o.cover_visual is False and o.release_reason == "cover-route-lost"

    @test("duplicate_current_evidence_is_idempotent")
    def _():
        o=Gen2Owner(); o.begin_open(100); x=ev(o,1,110)
        assert o.publish_evidence(x); assert o.publish_evidence(x)
        o.controller_open_inner(); assert o.release_reason == "inner-ready"

    @test("lower_sequence_cannot_replace_newer_evidence")
    def _():
        o=Gen2Owner(); o.begin_open(100)
        assert o.publish_evidence(ev(o,5,120)); assert not o.publish_evidence(ev(o,4,121))

    @test("secure_uncapturable_path_does_not_fake_readiness")
    def _():
        o=Gen2Owner(); o.begin_open(100); o.controller_open_inner(); o.capture_failed()
        assert o.cover_visual is True
        o.set_cover_route_available(False)
        assert o.cover_visual is False and o.release_reason == "cover-route-lost"

    @test("reversal_kills_old_attempt_and_late_evidence")
    def _():
        o=Gen2Owner(); o.begin_open(100); late=ev(o,1,150); o.reversal()
        assert not o.publish_evidence(late); assert o.release_reason == "reversal"

    @test("watchdog_release_is_degraded_not_readiness_success")
    def _():
        o=Gen2Owner(); o.begin_open(100); o.controller_open_inner(); o.watchdog_expired()
        assert o.cover_visual is False and o.release_reason == "watchdog-no-proof"
        assert o.evidence_ready is False

    passed=0
    for name,fn in tests:
        fn(); print(f"PASS {name}"); passed+=1

    # Fixed-seed adversarial stream. Invariant: a successful readiness handoff
    # while the cover route still exists must have current-cycle evidence.
    rng=random.Random(0xF017)
    o=Gen2Owner(service_epoch=11)
    ops=100_000
    for step in range(ops):
        action=rng.randrange(10)
        if action==0 or not o.active:
            o.begin_open(step*3+1, cover_route_available=True)
        elif action==1:
            o.controller_open_inner()
        elif action==2:
            o.route_remap(True)
        elif action==3:
            o.publish_evidence(ev(o, rng.randrange(1,50), o.cycle_started_ms+rng.randrange(0,50)))
        elif action==4:
            # stale cycle
            o.publish_evidence(ev(o, 60, o.cycle_started_ms+1, cycle=max(0,o.open_cycle_id-1)))
        elif action==5:
            o.capture_failed()
        elif action==6:
            o.reversal()
        elif action==7:
            o.set_cover_route_available(False)
        elif action==8:
            # stale route
            o.publish_evidence(ev(o, 70, o.cycle_started_ms+1, route=max(0,o.route_epoch-1)))
        else:
            o.watchdog_expired()

        if o.release_reason == "inner-ready":
            assert o.controller_wants_open
            assert o.evidence_ready
            assert o.best_evidence_seq >= 0
        if o.active and o.controller_wants_open and o.cover_route_available and not o.evidence_ready:
            assert o.cover_visual, (step, o.__dict__)

    print(f"PASS fuzz_{ops}_operations")
    print(f"RESULT passed={passed + 1} failed=0 total={passed + 1}")

if __name__ == '__main__':
    run_tests()
